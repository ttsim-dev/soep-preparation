# Writeup sources (line-numbered)


===== FILE: 2026-06-23-wealth-imputation-pro-review-writeup.md =====
   1	# Provisional 2022 SOEP household-wealth imputation — method & empirics for outside review
   2	
   3	## 0. What this is and what it is not
   4	
   5	A **provisional, donor-based proxy** for 2022 household net wealth in the German
   6	Socio-Economic Panel (SOEP), built as a stopgap until the DIW releases the officially
   7	imputed 2022 wealth module. It produces, for each 2022 household, a point estimate and a
   8	central interval for net overall wealth.
   9	
  10	It is **explicitly not** the official DIW product and **not** a valid multiple-imputation
  11	(MI) inference: it uses a single wealth implicate, applies no SOEP survey weights, and
  12	its intervals reflect donor/draw spread, not a proper posterior. The review should judge
  13	it as a *predictive proxy with uncertainty bands*, and tell us where its construction is
  14	statistically unsound, where the code diverges from the description below, and which of
  15	the listed approximations are first-order threats to the headline results.
  16	
  17	`@pro: Given the stated goal (a usable 2022 proxy, not MI), which of the approximations in §9 are first-order and which are second-order? Rank them.`
  18	
  19	## 1. Data
  20	
  21	SOEP-Core, version V41. The SOEP wealth module is fielded every five years; we use waves
  22	**2002, 2007, 2012, 2017** as the training waves and impute **2022** (the wealth module
  23	for 2022 is not yet released in imputed form).
  24	
  25	V41 ships a **reduced** household wealth file (`hwealth`) and person wealth file
  26	(`pwealth`). The separable wealth components present are: owner-occupied property (gross
  27	and net of mortgage), financial assets, private insurances, vehicles, consumer debt.
  28	**Business assets and other real estate are not separable** — they exist only inside the
  29	official net-wealth totals.
  30	
  31	Two official total columns matter:
  32	
  33	- `hh_net_overall_wealth_a` (SOEP `w011h`): net overall wealth, populated in **every**
  34	  wealth wave 2002–2017.
  35	- `hh_net_overall_wealth_including_vehicles_and_student_loans_a` (SOEP `n011h`): an
  36	  augmented total (adds vehicles and student loans), populated **only from 2017**.
  37	
  38	The imputation **targets `n011h`** (vehicle-inclusive, because vehicles are a modelled
  39	component). The descriptive distribution/mobility analysis **ranks on `w011h`** (the only
  40	cross-wave-consistent total). The imputed 2022 leg of the analysis is on the `n011h`
  41	concept; the difference (vehicles + student loans) is treated as negligible for ranking.
  42	
  43	`@pro: The imputation total (n011h) exists only in 2017 among training waves, so the residual model (§7) is fit on a single wave. Is anything about the residual fit or its 2017→2022 extrapolation invalid because of this single-wave support?`
  44	
  45	## 2. Components and their bias-free construction
  46	
  47	Five components are modelled, with this sign convention for the net total (assets `+`,
  48	liabilities `−`):
  49	
  50	| component | source | sign |
  51	|---|---|---|
  52	| owner-occupied property (net of mortgage) | household `hwealth` | + |
  53	| financial assets | household `hwealth` | + |
  54	| vehicles | household `hwealth` | + |
  55	| private pension / insurances | summed over members from person `pwealth` | + |
  56	| consumer debt | summed over members from person `pwealth` | − |
  57	
  58	The three **joint** components (property, financial, vehicles) are taken from the
  59	DIW-aggregated **household** file, which already resolves ownership shares correctly.
  60	This avoids a bias we hit earlier: the person-level wealth variables repeat the *full*
  61	joint value on each co-owner's row, so summing person rows double-counts couples. The two
  62	**person-direct** components (insurances, consumer debt) have no ownership share, so a
  63	plain sum over household members is unbiased — these are summed from person `pwealth`.
  64	
  65	`@pro: Verify the claim that summing person-direct components (insurances, consumer debt) over members is unbiased while joint components would be double-counted. Is the asymmetry correctly reflected in the code (impute.py _household_person_direct vs the hwealth columns)?`
  66	
  67	## 3. Feature matrix
  68	
  69	Per household head (the oldest member, `select_household_heads`):
  70	
  71	- ~18 covariates: age, gender, household size, children, federal state, income after
  72	  tax, education, employment/occupation/marital status, self-employment, retirement,
  73	  gross labour income, tenure, migration background, dwelling ownership, living space,
  74	  building year.
  75	- Continuous covariates enter directly; categoricals are **one-hot encoded** with a
  76	  `CategoricalEncoder` fit on the training waves and applied to recipients.
  77	- **Lagged wealth**: each head's own prior-wave person wealth (5 `pwealth` implicate-`a`
  78	  columns) is merged on `p_id` and added as continuous predictors.
  79	
  80	## 4. Per-component model (two-part) and the draw
  81	
  82	For each component, on the training waves:
  83	
  84	1. **Ownership** — `OwnershipModel`: `sklearn` `LogisticRegression` on the design matrix
  85	   predicting `P(value > 0)`.
  86	2. **Amount** — `AmountModel`: `LinearRegression` on `asinh(y / s)` where `s` is the
  87	   median strictly-positive amount (`component_scale`); `predict` inverts the asinh to
  88	   return euros. This variance-stabilises the heavy right tail.
  89	3. **Donor deflation** — cross-wave donors are scaled to 2022 by an asset-class index:
  90	   MSCI World → financial, BIS house-price index → property, REX bond index → pension.
  91	   Vehicles and consumer debt are **not** deflated (depreciating / nominal).
  92	4. **Draw** — `value_generator.draw_component`: draw ownership ~ Bernoulli(`P(owns)`);
  93	   if owner, draw an amount by **predictive mean matching** (PMM): find the `k` donors
  94	   whose *predicted* amount is nearest the recipient's predicted amount, draw one
  95	   donor's *observed* value uniformly. Ownership share = 1 for these household-level
  96	   components.
  97	
  98	`@pro: PMM matches on the asinh-amount prediction but draws the observed euro donor value. With donors deflated by an asset index (step 3), is the match metric (predicted) consistent with the drawn quantity (deflated observed)? Could the deflation distort the neighbour set?`
  99	
 100	## 5. Joint simulation and intervals
 101	
 102	`simulate_household_totals` performs `n_draws` (=200) complete joint draws. Within a
 103	single draw, every component is drawn for every recipient and the **signed sum** gives
 104	that draw's household net total. Across draws, `household_total_intervals` returns the
 105	median as the point estimate and the central `level` (=0.9) quantiles as the interval
 106	bounds. Component interval endpoints are **never** summed — intervals are formed on the
 107	household-total draw distribution directly, to preserve cross-component dependence within
 108	a draw.
 109	
 110	`@pro: Each draw redraws ownership and PMM independently per component with no modelled cross-component correlation (beyond shared covariates). Does forming the interval on the summed total nonetheless understate or misstate joint uncertainty? Is 200 draws adequate for stable 5th/95th percentiles?`
 111	
 112	## 6. Settings
 113	
 114	`n_draws = 200`, `seed = 0`, `k = 10` (PMM neighbours, clipped to a component's owner
 115	count), `level = 0.9`.
 116	
 117	## 7. The residual to the official total (two-part — current code)
 118	
 119	The five components do not sum to the official total; the gap is **business + other real
 120	estate** (absent from V41 as separable variables) plus fit/measurement noise. We model it
 121	as a residual:
 122	
 123	```
 124	residual_h = official_total_h − Σ_c sign_c · modelled_component_{c,h}
 125	```
 126	
 127	over training households that have an official total. Construction (`impute.py
 128	_training_residual`, `residual_model.py`):
 129	
 130	1. **Deflate** each training residual from its wave to 2022 by `RESIDUAL_INDEX` — an
 131	   equal-weight blend of the BIS house-price and MSCI World indices, each rebased to a
 132	   common base year (other real estate ≈ property, business ≈ equity).
 133	2. **Two-part allocator** (`ResidualModel`): a logistic incidence model for
 134	   `P(residual > 0)` (does the household hold any unmodelled wealth) times an
 135	   asinh-scaled `AmountModel` fit on the **positive residuals only**. The expected
 136	   residual `P(owns) · amount` is **clipped at zero**.
 137	3. The per-recipient expected residual is **added to the point estimate and both
 138	   interval bounds** (a deterministic level shift; it does not widen the interval).
 139	4. Fallback: if owners and non-owners are not both present, a flat training-mean shift.
 140	
 141	This **replaced an earlier OLS** on the raw signed residual. The OLS smeared a highly
 142	concentrated, mostly-zero quantity (business/other-RE) across all households, which
 143	inflated the median, compressed measured inequality, and manufactured negative net
 144	wealth (see §10). The two-part form is meant to keep the mass concentrated.
 145	
 146	`@pro: Is "expected residual = P(owns)·amount(asinh-predicted), clipped at 0, added to point and both bounds" a coherent estimator of the unmodelled-wealth contribution? The amount model's asinh prediction is a conditional median-ish quantity, not a mean — is P·amount a defensible plug-in for E[residual | x]? Does clipping at 0 bias the level?`
 147	
 148	`@pro: The residual deflation (50/50 property/equity blend) and the component deflation both bring donors to 2022. Is there any double-counting of asset-price growth between the deflated components and the deflated residual?`
 149	
 150	## 8. Distribution and mobility analysis (`wealth_dynamics.py`)
 151	
 152	Disclosure-safe aggregates only (no row-level value leaves the secure environment):
 153	
 154	- **Per-wave distribution** over households on `w011h` (imputed point estimate for 2022):
 155	  count, mean, quantile grid (p1…p99), Gini, top-10% and top-1% shares, negative- and
 156	  zero-wealth shares. Gini uses the mean-absolute-difference (sorted-rank) formula and
 157	  can exceed 1 with negative net wealth.
 158	- **Quintile transitions** over persons across consecutive 5-year horizons. The unit is
 159	  the **person** (`p_id`, stable across waves), assigned their household's net wealth;
 160	  quintile ranks are formed on the full person cross-section of each wave; persons present
 161	  in both waves of a horizon are cross-tabulated. Cells below 30 movers are suppressed.
 162	
 163	`@pro: Mobility is person-level (each person carries household wealth) while the cross-sectional distribution is household-level. Is mixing the two units defensible, and does the person-level ranking (which weights large households more) bias the transition matrices?`
 164	
 165	## 9. Key assumptions and known approximations (review hit-list)
 166	
 167	1. **Single wealth implicate** ("a") — SOEP multiply-imputes wealth; we use one
 168	   implicate, so we ignore SOEP's own item-imputation uncertainty.
 169	2. **No survey weights** anywhere — models, distribution, and mobility are all
 170	   unweighted, so population-level statements are biased by the SOEP sample design and
 171	   refresh samples.
 172	3. **Residual fit on a single wave (2017)** — because `n011h` exists only from 2017.
 173	4. **Residual deflation blend (50/50 property/equity)** — a rough default; business
 174	   growth is proxied by world equities.
 175	5. **Intervals from draw spread only** — the residual is a deterministic shift; SOEP
 176	   imputation uncertainty and model uncertainty are not propagated.
 177	6. **PMM on asinh-predicted amounts with asset-deflated donors.**
 178	7. **Household property is net of mortgage; vehicles/consumer-debt donors not deflated.**
 179	8. **2022 mobility leg uses the imputed proxy**, so the 2017→2022 transition is
 180	   attenuated by imputation regression-to-the-mean.
 181	
 182	`@pro: Are intervals that omit (1) the SOEP item-imputation variance, (2) model/parameter uncertainty, and (3) any residual uncertainty likely to be badly under-covered? Roughly how much, and what is the cheapest fix that would make them honest?`
 183	
 184	## 10. Empirical results
 185	
 186	### 10.1 Distribution over time (household net overall wealth `w011h`; 2022 imputed)
 187	
 188	| wave | n | mean (€) | median (€) | Gini | top-10% | top-1% | neg. share |
 189	|---|---|---|---|---|---|---|---|
 190	| 2002 | 12,692 | 197,406 | 60,000 | 0.752 | 0.568 | 0.228 | 0.064 |
 191	| 2007 | 11,689 | 192,393 | 60,492 | 0.750 | 0.566 | 0.217 | 0.077 |
 192	| 2012 | 14,982 | 166,656 | 45,600 | 0.768 | 0.567 | 0.200 | 0.103 |
 193	| 2017 | 15,891 | 197,236 | 52,200 | 0.759 | 0.566 | 0.212 | 0.091 |
 194	| **2022\*** | 30,003 | 274,922 | 109,716 | 0.719 | 0.540 | 0.172 | 0.144 |
 195	
 196	\* Imputed, under the **earlier OLS residual** specification (see version note §11).
 197	
 198	The four actual waves are internally consistent and match known SOEP wealth facts (high
 199	Gini ~0.75, stable top shares, 2012 euro-crisis trough). The imputed 2022 row shows three
 200	distortions versus the actual trend: median roughly doubles, measured inequality falls
 201	(Gini and top shares down), and the negative-wealth share jumps to 14.4%.
 202	
 203	### 10.2 Imputation run summary (OLS residual specification)
 204	
 205	```
 206	n_recipients=30003, n_training_heads=70813, components_used=5 (none skipped),
 207	residual_model="ols", mean_residual=122560, n_draws=200, k=10, level=0.9
 208	```
 209	
 210	### 10.3 Transition matrices, row % (origin quintile → destination quintile)
 211	
 212	Actual horizons (real data):
 213	
 214	```
 215	2002→2007            2007→2012            2012→2017
 216	   Q1 Q2 Q3 Q4 Q5       Q1 Q2 Q3 Q4 Q5       Q1 Q2 Q3 Q4 Q5
 217	Q1 59 27 10  3  2    Q1 59 28 10  3  -    Q1 60 24 11  4  1
 218	Q2 24 45 22  6  2    Q2 21 38 32  7  2    Q2 31 39 22  6  1
 219	Q3  8 15 44 27  6    Q3  6 10 46 31  7    Q3  7 12 48 27  6
 220	Q4  4  5 18 50 24    Q4  2  4 11 52 31    Q4  2  3 18 51 26
 221	Q5  3  4  6 17 71    Q5  1  3  3 14 78    Q5  1  2  3 16 78
 222	```
 223	
 224	Imputed horizon (2017 actual → 2022 imputed, OLS residual):
 225	
 226	```
 227	   Q1 Q2 Q3 Q4 Q5
 228	Q1 26 33 20 16  5
 229	Q2 21 31 22 20  6
 230	Q3  7 19 16 36 22
 231	Q4  3 17 10 27 44
 232	Q5  3 11  7 12 67
 233	```
 234	
 235	The actual horizons show strong, stable diagonal persistence (textbook wealth mobility).
 236	The imputed horizon's diagonal collapses in the bottom and middle quintiles — consistent
 237	with imputation regression-to-the-mean rather than genuine mobility.
 238	
 239	`@pro: Is the contrast between the three actual transition matrices and the imputed one a fair internal validity check? What additional disclosure-safe diagnostic would best quantify how much the imputed mobility is an artefact?`
 240	
 241	## 11. Version note (code vs empirics)
 242	
 243	The **bundled code** implements the **two-part residual model** (§7). The **empirics in
 244	§10** were produced by the **previous OLS residual** specification; they are included
 245	because they are the diagnostic that motivated the two-part change, and because the
 246	actual-data results (2002–2017) are specification-independent. A re-run under the two-part
 247	code is pending; it is expected to reduce the imputed-2022 median, restore measured
 248	inequality toward the actual trend, and remove the spurious negatives. Please review the
 249	two-part code on its merits and treat the §10 imputed-2022 numbers as the "before" state.
 250	
 251	`@pro: Independent of the rerun, does the two-part code in residual_model.py + impute.py plausibly fix the three §10 distortions, or could it over-correct (e.g. concentrate too aggressively, or the clip-at-0 truncate genuine variation)?`
