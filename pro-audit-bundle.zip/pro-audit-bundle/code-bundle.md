# Code bundle (every source file, line-numbered)
Cite locations as `path:line` from these headers.


### wealth_imputation/__init__.py

```py
   1	"""Provisional SOEP wealth-imputation harness (2022 household-wealth proxy)."""
```


### wealth_imputation/aggregate.py

```py
   1	"""Aggregate share-resolved person amounts to households and isolate PUNR residuals.
   2	
   3	Household wealth is the plain sum of members' share-resolved person amounts plus a
   4	household-level partial-unit-nonresponse (PUNR) residual — the part of the official
   5	household total not covered by represented members. Both helpers fail closed on an
   6	invalid input (missing keys, duplicate cells, non-numeric or non-finite values, or
   7	non-canonical components), and all monetary arithmetic runs in `float64` so input dtype
   8	can neither silently lose precision nor concatenate strings into a plausible total.
   9	"""
  10	
  11	import numpy as np
  12	import pandas as pd
  13	
  14	from soep_preparation.wealth_imputation.components import (
  15	    CanonicalComponent,
  16	    component_sign,
  17	)
  18	
  19	_PERSON_PANEL_COLUMNS = (
  20	    "p_id",
  21	    "hh_id",
  22	    "survey_year",
  23	    "component",
  24	    "person_component_value",
  25	)
  26	_KEY_COLUMNS = ["hh_id", "survey_year", "component"]
  27	_HOUSEHOLD_KEY_COLUMNS = ["hh_id", "survey_year"]
  28	
  29	
  30	def _fail_if_columns_missing(
  31	    frame: pd.DataFrame, columns: tuple[str, ...], name: str
  32	) -> None:
  33	    missing = [col for col in columns if col not in frame.columns]
  34	    if missing:
  35	        msg = f"{name} is missing required columns: {missing}"
  36	        raise ValueError(msg)
  37	
  38	
  39	def _fail_if_components_non_canonical(component_values: pd.Series) -> None:
  40	    valid = {member.value for member in CanonicalComponent}
  41	    bad = set(component_values.dropna().unique()) - valid
  42	    if bad:
  43	        listed = sorted(str(value) for value in bad)
  44	        msg = (
  45	            f"'component' has non-canonical values: {listed}; use "
  46	            "CanonicalComponent.value strings."
  47	        )
  48	        raise ValueError(msg)
  49	
  50	
  51	def _to_finite_float64(values: pd.Series, name: str) -> pd.Series:
  52	    numeric = pd.to_numeric(values, errors="raise").astype("float64")
  53	    if not np.isfinite(numeric.to_numpy()).all():
  54	        msg = f"{name} must be finite (no NaN/inf)."
  55	        raise ValueError(msg)
  56	    return numeric
  57	
  58	
  59	def _fail_if_person_panel_invalid(person_panel: pd.DataFrame) -> None:
  60	    _fail_if_columns_missing(person_panel, _PERSON_PANEL_COLUMNS, "person_panel")
  61	    for col in ("p_id", "hh_id", "survey_year", "component"):
  62	        if person_panel[col].isna().any():
  63	            msg = (
  64	                f"person_panel has missing values in key column '{col}'; rows with a "
  65	                "missing key would be silently dropped by groupby."
  66	            )
  67	            raise ValueError(msg)
  68	    _fail_if_components_non_canonical(person_panel["component"])
  69	    if person_panel.duplicated(subset=["p_id", "survey_year", "component"]).any():
  70	        msg = (
  71	            "person_panel has duplicate (p_id, survey_year, component) rows; each "
  72	            "person-component cell must be unique before aggregation."
  73	        )
  74	        raise ValueError(msg)
  75	    if person_panel["person_component_value"].isna().any():
  76	        msg = (
  77	            "person_panel has missing person_component_value entries; resolve item "
  78	            "nonresponse before aggregation so it is not mistaken for a PUNR residual."
  79	        )
  80	        raise ValueError(msg)
  81	
  82	
  83	def household_component_sum(person_panel: pd.DataFrame) -> pd.DataFrame:
  84	    """Sum share-resolved person amounts within household, year, and component.
  85	
  86	    The values are coerced to `float64` *before* grouping, so integer overflow,
  87	    `float32` precision loss, and string concatenation cannot corrupt the total.
  88	
  89	    Args:
  90	        person_panel: Columns `p_id`, `hh_id`, `survey_year`, `component`,
  91	            `person_component_value`. Every key column must be non-missing, each
  92	            `(p_id, survey_year, component)` unique, `component` a
  93	            `CanonicalComponent.value` string, and `person_component_value` a finite
  94	            number.
  95	
  96	    Returns:
  97	        Columns `hh_id`, `survey_year`, `component`, `member_sum` (float64).
  98	
  99	    Raises:
 100	        ValueError: On missing columns/keys, non-canonical components, duplicate
 101	            person-component rows, or non-numeric / non-finite values.
 102	    """
 103	    _fail_if_person_panel_invalid(person_panel)
 104	    panel = person_panel.assign(
 105	        person_component_value=_to_finite_float64(
 106	            person_panel["person_component_value"], "person_component_value"
 107	        )
 108	    )
 109	    grouped = (
 110	        panel.groupby(_KEY_COLUMNS, observed=True)["person_component_value"]
 111	        .sum()
 112	        .reset_index(name="member_sum")
 113	    )
 114	    grouped["member_sum"] = grouped["member_sum"].astype("float64")
 115	    return grouped
 116	
 117	
 118	def punr_residual(
 119	    household_totals: pd.DataFrame, member_sums: pd.DataFrame
 120	) -> pd.DataFrame:
 121	    """Return household total minus represented-member sum, joined on household keys.
 122	
 123	    The two tables are merged one-to-one on `(hh_id, survey_year, component)`; the keys
 124	    must be unique on each side and identical across the two, so alignment is by
 125	    household identity, not by row position. The residual is positive when the official
 126	    total exceeds the represented-member sum (partial-unit nonresponse), in the same
 127	    sign convention as the inputs (debt carried as positive magnitudes).
 128	
 129	    Args:
 130	        household_totals: Columns `hh_id`, `survey_year`, `component`,
 131	            `household_total`.
 132	        member_sums: Columns `hh_id`, `survey_year`, `component`, `member_sum`.
 133	
 134	    Returns:
 135	        Columns `hh_id`, `survey_year`, `component`, `punr_residual` (float64).
 136	
 137	    Raises:
 138	        ValueError: On missing columns, non-unique keys, key sets that differ between
 139	            the two tables, or non-numeric / non-finite values.
 140	    """
 141	    _fail_if_columns_missing(
 142	        household_totals, (*_KEY_COLUMNS, "household_total"), "household_totals"
 143	    )
 144	    _fail_if_columns_missing(member_sums, (*_KEY_COLUMNS, "member_sum"), "member_sums")
 145	    for name, frame in (
 146	        ("household_totals", household_totals),
 147	        ("member_sums", member_sums),
 148	    ):
 149	        if frame.duplicated(subset=_KEY_COLUMNS).any():
 150	            msg = f"{name} has duplicate (hh_id, survey_year, component) keys."
 151	            raise ValueError(msg)
 152	    merged = household_totals.merge(
 153	        member_sums, on=_KEY_COLUMNS, how="outer", validate="one_to_one", indicator=True
 154	    )
 155	    if (merged["_merge"] != "both").any():
 156	        msg = (
 157	            "household_totals and member_sums must cover identical "
 158	            "(hh_id, survey_year, component) keys."
 159	        )
 160	        raise ValueError(msg)
 161	    total = _to_finite_float64(merged["household_total"], "household_total")
 162	    member = _to_finite_float64(merged["member_sum"], "member_sum")
 163	    out = merged[_KEY_COLUMNS].copy()
 164	    out["punr_residual"] = (total - member).to_numpy()
 165	    return out
 166	
 167	
 168	_COMPONENT_VALUE_COLUMNS = (
 169	    "hh_id",
 170	    "survey_year",
 171	    "component",
 172	    "household_component_value",
 173	)
 174	
 175	
 176	def household_net_total(component_values: pd.DataFrame) -> pd.DataFrame:
 177	    """Sum signed component values into a household net total per year.
 178	
 179	    Each component value is a positive magnitude; its net-wealth sign comes from
 180	    `component_sign`, so liabilities (mortgage, consumer debt) subtract. This is one
 181	    joint draw's modelled household net wealth -- the quantity whose draw-to-draw
 182	    spread `intervals.household_total_intervals` summarises. Arithmetic runs in
 183	    `float64`.
 184	
 185	    Args:
 186	        component_values: Columns `hh_id`, `survey_year`, `component`,
 187	            `household_component_value`. `component` is a `CanonicalComponent.value`
 188	            string and the value a finite magnitude.
 189	
 190	    Returns:
 191	        Columns `hh_id`, `survey_year`, `net_total` (float64).
 192	
 193	    Raises:
 194	        ValueError: On missing columns, non-canonical components, or non-numeric /
 195	            non-finite values.
 196	    """
 197	    _fail_if_columns_missing(
 198	        component_values, _COMPONENT_VALUE_COLUMNS, "component_values"
 199	    )
 200	    _fail_if_components_non_canonical(component_values["component"])
 201	    value = _to_finite_float64(
 202	        component_values["household_component_value"], "household_component_value"
 203	    )
 204	    signs = component_values["component"].map(
 205	        lambda name: component_sign(CanonicalComponent(name))
 206	    )
 207	    signed = component_values[_HOUSEHOLD_KEY_COLUMNS].assign(
 208	        signed_value=value.to_numpy() * signs.to_numpy().astype("float64")
 209	    )
 210	    summed = (
 211	        signed.groupby(_HOUSEHOLD_KEY_COLUMNS, observed=True)["signed_value"]
 212	        .sum()
 213	        .reset_index(name="net_total")
 214	    )
 215	    summed["net_total"] = summed["net_total"].astype("float64")
 216	    return summed
 217	
 218	
 219	def unmodelled_components_residual(
 220	    component_values: pd.DataFrame, official_totals: pd.DataFrame
 221	) -> pd.DataFrame:
 222	    """Return the official net total minus the signed sum of modelled components.
 223	
 224	    SOEP-Core exposes only a subset of wealth components separately; the rest (other
 225	    real estate, business assets) live only inside the official totals. This residual
 226	    is what those unmodelled components contribute: the authoritative net total minus
 227	    the modelled `household_net_total`. All arithmetic runs in `float64`.
 228	
 229	    Args:
 230	        component_values: Columns `hh_id`, `survey_year`, `component`,
 231	            `household_component_value`. `component` is a `CanonicalComponent.value`
 232	            string and the value a finite non-negative magnitude.
 233	        official_totals: Columns `hh_id`, `survey_year`, `official_net_total`.
 234	
 235	    Returns:
 236	        Columns `hh_id`, `survey_year`, `residual` (float64).
 237	
 238	    Raises:
 239	        ValueError: On missing columns, non-canonical components, non-numeric /
 240	            non-finite values, non-unique official-total keys, or household keys that
 241	            differ between the two tables.
 242	    """
 243	    _fail_if_columns_missing(
 244	        official_totals,
 245	        (*_HOUSEHOLD_KEY_COLUMNS, "official_net_total"),
 246	        "official_totals",
 247	    )
 248	    if official_totals.duplicated(subset=_HOUSEHOLD_KEY_COLUMNS).any():
 249	        msg = "official_totals has duplicate (hh_id, survey_year) keys."
 250	        raise ValueError(msg)
 251	    modelled = household_net_total(component_values).rename(
 252	        columns={"net_total": "modelled_sum"}
 253	    )
 254	    merged = official_totals.merge(
 255	        modelled,
 256	        on=_HOUSEHOLD_KEY_COLUMNS,
 257	        how="outer",
 258	        validate="one_to_one",
 259	        indicator=True,
 260	    )
 261	    if (merged["_merge"] != "both").any():
 262	        msg = (
 263	            "official_totals and component_values must cover identical "
 264	            "(hh_id, survey_year) households."
 265	        )
 266	        raise ValueError(msg)
 267	    total = _to_finite_float64(merged["official_net_total"], "official_net_total")
 268	    out = merged[_HOUSEHOLD_KEY_COLUMNS].copy()
 269	    out["residual"] = (total.to_numpy() - merged["modelled_sum"].to_numpy()).astype(
 270	        "float64"
 271	    )
 272	    return out
```


### wealth_imputation/amount_model.py

```py
   1	"""Amount model: predict component euro amounts via an asinh-scaled regression.
   2	
   3	Wraps a scikit-learn `LinearRegression` fitted on the `asinh(y / s_c)`-transformed
   4	amount, so the heavy right tail of wealth is variance-stabilised during fitting. The
   5	public `predict` returns euro amounts (the asinh prediction is inverted with the same
   6	component scale), which feed the PMM matching in `amounts.draw_amounts`. The wrapper is
   7	a thin, fail-closed boundary; real covariates are wired in the deferred data stage.
   8	"""
   9	
  10	from dataclasses import dataclass
  11	
  12	import numpy as np
  13	import pandas as pd
  14	from sklearn.linear_model import LinearRegression
  15	
  16	from soep_preparation.wealth_imputation.transforms import (
  17	    asinh_scaled,
  18	    inverse_asinh_scaled,
  19	)
  20	
  21	
  22	def _fail_if_training_data_invalid(
  23	    features: np.ndarray, observed_amounts: np.ndarray
  24	) -> None:
  25	    if features.ndim != 2:  # noqa: PLR2004 -- a design matrix is 2-D by definition
  26	        msg = f"features must be a 2-D design matrix, got {features.ndim}-D."
  27	        raise ValueError(msg)
  28	    if observed_amounts.ndim != 1:
  29	        msg = f"observed_amounts must be 1-D, got {observed_amounts.ndim}-D."
  30	        raise ValueError(msg)
  31	    if features.shape[0] != observed_amounts.shape[0]:
  32	        msg = (
  33	            "features and observed_amounts must have the same number of rows, got "
  34	            f"{features.shape[0]} and {observed_amounts.shape[0]}."
  35	        )
  36	        raise ValueError(msg)
  37	    if not np.all(np.isfinite(features)):
  38	        msg = "features must be finite (no NaN/inf)."
  39	        raise ValueError(msg)
  40	    if not np.all(np.isfinite(observed_amounts)):
  41	        msg = "observed_amounts must be finite (no NaN/inf)."
  42	        raise ValueError(msg)
  43	
  44	
  45	@dataclass(frozen=True)
  46	class AmountModel:
  47	    """A fitted amount model with its asinh component scale."""
  48	
  49	    estimator: LinearRegression
  50	    """The fitted scikit-learn linear regression on the asinh-scaled target."""
  51	    scale: float
  52	    """The positive, finite component scale used in the asinh transform."""
  53	
  54	    @classmethod
  55	    def fit(
  56	        cls, features: np.ndarray, observed_amounts: np.ndarray, *, scale: float
  57	    ) -> AmountModel:
  58	        """Fit the amount model on observed euro amounts.
  59	
  60	        Args:
  61	            features: Design matrix, shape `(n_rows, n_features)`, all finite.
  62	            observed_amounts: Observed euro amounts per row, all finite.
  63	            scale: Positive, finite component scale for the asinh transform.
  64	
  65	        Returns:
  66	            A fitted `AmountModel`.
  67	
  68	        Raises:
  69	            ValueError: On a non-2-D design matrix, mismatched lengths, non-finite
  70	                inputs, or an invalid scale.
  71	        """
  72	        _fail_if_training_data_invalid(features, observed_amounts)
  73	        target = asinh_scaled(pd.Series(observed_amounts), scale).to_numpy()
  74	        estimator = LinearRegression()
  75	        estimator.fit(features, target)
  76	        return cls(estimator=estimator, scale=scale)
  77	
  78	    def predict(self, features: np.ndarray) -> np.ndarray:
  79	        """Return predicted euro amounts for each row of `features` as float64.
  80	
  81	        Args:
  82	            features: Design matrix with the same column layout used in `fit`.
  83	
  84	        Returns:
  85	            Predicted euro amounts, shape `(n_rows,)`.
  86	
  87	        Raises:
  88	            ValueError: On a non-2-D design matrix or non-finite features.
  89	        """
  90	        if features.ndim != 2:  # noqa: PLR2004 -- a design matrix is 2-D by definition
  91	            msg = f"features must be a 2-D design matrix, got {features.ndim}-D."
  92	            raise ValueError(msg)
  93	        if not np.all(np.isfinite(features)):
  94	            msg = "features must be finite (no NaN/inf)."
  95	            raise ValueError(msg)
  96	        transformed = self.estimator.predict(features)
  97	        return inverse_asinh_scaled(pd.Series(transformed), self.scale).to_numpy()
```


### wealth_imputation/amounts.py

```py
   1	"""Draw component amounts by predictive mean matching on the asinh-scaled scale.
   2	
   3	The amount model predicts on the `asinh(y / s_c)` scale, so recipients and donors are
   4	matched there: both predicted amounts are transformed with the component scale `s_c`,
   5	matched by `pmm_draw`, and each recipient takes the **observed** euro value of its drawn
   6	donor. Matching on the scaled axis makes the donor caliper comparable across components
   7	regardless of their euro magnitude, and drawing an observed value keeps every imputed
   8	amount on the real support without back-transforming a prediction.
   9	"""
  10	
  11	from collections.abc import Sequence
  12	
  13	import numpy as np
  14	import pandas as pd
  15	
  16	from soep_preparation.wealth_imputation.donors import PmmResult, pmm_draw
  17	from soep_preparation.wealth_imputation.transforms import asinh_scaled
  18	
  19	
  20	def draw_amounts(  # noqa: PLR0913
  21	    recipient_predicted: np.ndarray,
  22	    donor_predicted: np.ndarray,
  23	    donor_observed: np.ndarray,
  24	    scale: float,
  25	    k: int,
  26	    rng: np.random.Generator,
  27	    caliper: float | None = None,
  28	    exclude: Sequence[Sequence[int]] | None = None,
  29	) -> PmmResult:
  30	    """Draw each recipient's amount from a near donor's observed value.
  31	
  32	    Args:
  33	        recipient_predicted: Predicted euro amounts for recipients, shape
  34	            `(n_recipients,)`.
  35	        donor_predicted: Predicted euro amounts for donors, shape `(n_donors,)`.
  36	        donor_observed: Observed euro amounts for donors, shape `(n_donors,)`.
  37	        scale: Positive, finite component scale `s_c` for the asinh transform.
  38	        k: Number of nearest eligible donors to sample from (>= 1).
  39	        rng: NumPy random generator.
  40	        caliper: Maximum allowed distance on the asinh-scaled axis, if set (>= 0).
  41	        exclude: Per-recipient sequences of donor indices to exclude, if any.
  42	
  43	    Returns:
  44	        A `PmmResult` whose `values` are the drawn observed euro amounts (float64).
  45	
  46	    Raises:
  47	        ValueError: On an invalid scale, invalid PMM inputs, or a recipient with no
  48	            eligible donor.
  49	    """
  50	    recipient_scores = asinh_scaled(pd.Series(recipient_predicted), scale).to_numpy()
  51	    donor_scores = asinh_scaled(pd.Series(donor_predicted), scale).to_numpy()
  52	    return pmm_draw(
  53	        recipient_scores=recipient_scores,
  54	        donor_scores=donor_scores,
  55	        donor_values=np.asarray(donor_observed, dtype="float64"),
  56	        k=k,
  57	        rng=rng,
  58	        caliper=caliper,
  59	        exclude=exclude,
  60	    )
```


### wealth_imputation/components.py

```py
   1	"""Canonical wealth ontology and three-axis cell-provenance enums."""
   2	
   3	from enum import Enum
   4	
   5	
   6	class CanonicalComponent(Enum):
   7	    """Wealth components, normalized across waves by the registry."""
   8	
   9	    OWNER_OCCUPIED_PROPERTY_GROSS = "owner_occupied_property_gross"
  10	    OWNER_OCCUPIED_MORTGAGE = "owner_occupied_mortgage"
  11	    OTHER_REAL_ESTATE = "other_real_estate"
  12	    FINANCIAL_ASSETS = "financial_assets"
  13	    PRIVATE_PENSION = "private_pension"
  14	    BUSINESS_ASSETS = "business_assets"
  15	    VEHICLES = "vehicles"
  16	    CONSUMER_DEBT = "consumer_debt"
  17	
  18	
  19	class RawInputState(Enum):
  20	    """Axis A — the raw response state of a person-component cell."""
  21	
  22	    OBSERVED_COMPLETE = "observed_complete"
  23	    MISSING_SHARE = "missing_share"
  24	    MISSING_AMOUNT = "missing_amount"
  25	    MISSING_FILTER = "missing_filter"
  26	    PUNR = "punr"
  27	    STRUCTURAL_ABSENT = "structural_absent"
  28	    INCONSISTENT = "inconsistent"
  29	    AMBIGUOUS = "ambiguous"
  30	
  31	
  32	class AlignmentEvidence(Enum):
  33	    """Axis B — how a raw-derived value compares to the official completed value."""
  34	
  35	    AGREES_ALL = "agrees_all"
  36	    AGREES_MEAN = "agrees_mean"
  37	    OFFICIAL_DIFFERS = "official_differs"
  38	    FLAG_CONFLICT = "flag_conflict"
  39	    UNAVAILABLE = "unavailable"
  40	
  41	
  42	class HarnessAction(Enum):
  43	    """Axis C — the action this harness took on a cell."""
  44	
  45	    PRESERVED = "preserved"
  46	    DETERMINISTIC_EDIT = "deterministic_edit"
  47	    OWNERSHIP_IMPUTED = "ownership_imputed"
  48	    AMOUNT_PMM = "amount_pmm"
  49	    SHARE_IMPUTED = "share_imputed"
  50	    PUNR_RESIDUAL = "punr_residual"
  51	    STATISTICAL_REPLACEMENT = "statistical_replacement"
  52	    SUPPRESSED = "suppressed"
  53	
  54	
  55	LIABILITY_COMPONENTS: frozenset[CanonicalComponent] = frozenset(
  56	    {
  57	        CanonicalComponent.OWNER_OCCUPIED_MORTGAGE,
  58	        CanonicalComponent.CONSUMER_DEBT,
  59	    }
  60	)
  61	
  62	
  63	def component_sign(component: CanonicalComponent) -> int:
  64	    """Return `-1` for liability components and `+1` for assets.
  65	
  66	    Args:
  67	        component: The wealth component (must be a `CanonicalComponent`).
  68	
  69	    Returns:
  70	        The sign used when summing components into net wealth.
  71	
  72	    Raises:
  73	        TypeError: If `component` is not a `CanonicalComponent` (e.g. a raw string),
  74	            which would otherwise silently be classified as an asset.
  75	    """
  76	    if not isinstance(component, CanonicalComponent):
  77	        msg = (
  78	            "component must be a CanonicalComponent, got "
  79	            f"{type(component).__name__}; convert via CanonicalComponent(value) first."
  80	        )
  81	        raise TypeError(msg)
  82	    return -1 if component in LIABILITY_COMPONENTS else 1
```


### wealth_imputation/deflation.py

```py
   1	"""Bring earlier-wave donor values into target-wave terms via asset-class indices.
   2	
   3	A donor observed in wave `w` is scaled by `index[target] / index[w]` so the pre-2022
   4	donor pool reflects 2022 price levels for its component (equities, bonds, ...). This
   5	removes the downward bias a uniform CPI leaves when asset prices outpaced consumer
   6	prices. Fails closed on a donor wave absent from the index.
   7	"""
   8	
   9	from collections.abc import Mapping, Sequence
  10	
  11	import numpy as np
  12	
  13	
  14	def deflation_factor(
  15	    index_by_year: Mapping[int, float], *, from_year: int, target_year: int
  16	) -> float:
  17	    """Return the factor scaling a `from_year` value into `target_year` terms.
  18	
  19	    Args:
  20	        index_by_year: Annual index levels for the asset class.
  21	        from_year: Wave the donor value was observed in.
  22	        target_year: Wave to express the value in.
  23	
  24	    Returns:
  25	        `index[target_year] / index[from_year]`.
  26	
  27	    Raises:
  28	        ValueError: If either year is absent from the index.
  29	    """
  30	    for year in (from_year, target_year):
  31	        if year not in index_by_year:
  32	            msg = f"Year {year} is absent from the index."
  33	            raise ValueError(msg)
  34	    return index_by_year[target_year] / index_by_year[from_year]
  35	
  36	
  37	def deflate_donor_values(
  38	    values: np.ndarray,
  39	    from_years: Sequence[int],
  40	    *,
  41	    index_by_year: Mapping[int, float],
  42	    target_year: int,
  43	) -> np.ndarray:
  44	    """Scale each donor value from its origin wave into target-wave terms.
  45	
  46	    Args:
  47	        values: Donor amounts, shape `(n_donors,)`.
  48	        from_years: Origin wave per donor, same length as `values`.
  49	        index_by_year: Annual index levels for the component's asset class.
  50	        target_year: Wave to express the values in.
  51	
  52	    Returns:
  53	        The deflated donor values as float64, shape `(n_donors,)`.
  54	
  55	    Raises:
  56	        ValueError: If `from_years` length differs, or a year is absent from the index.
  57	    """
  58	    amounts = np.asarray(values, dtype="float64")
  59	    if len(from_years) != amounts.shape[0]:
  60	        msg = f"from_years has {len(from_years)} entries for {amounts.shape[0]} values."
  61	        raise ValueError(msg)
  62	    factors = np.array(
  63	        [
  64	            deflation_factor(
  65	                index_by_year, from_year=int(year), target_year=target_year
  66	            )
  67	            for year in from_years
  68	        ],
  69	        dtype="float64",
  70	    )
  71	    return amounts * factors
```


### wealth_imputation/donors.py

```py
   1	"""Predictive-mean-matching donor draws.
   2	
   3	Each recipient borrows an observed amount from one of its `k` nearest *eligible*
   4	donors in predictive-score space, so imputed values stay on the real observed
   5	support and the back-transformation of `asinh`-scale predictions never has to be
   6	computed analytically. Eligibility — recipient-specific exclusions and the caliper —
   7	is enforced *before* the nearest `k` are chosen, so an out-of-caliper or excluded
   8	donor can never be drawn.
   9	"""
  10	
  11	from collections.abc import Sequence
  12	from dataclasses import dataclass
  13	
  14	import numpy as np
  15	
  16	
  17	@dataclass(frozen=True)
  18	class PmmResult:
  19	    """Outcome of a PMM draw, with donor diagnostics."""
  20	
  21	    values: np.ndarray
  22	    """Drawn donor values as float64, shape `(n_recipients,)`."""
  23	    donor_indices: np.ndarray
  24	    """Index into the donor arrays of the drawn donor, shape `(n_recipients,)`."""
  25	    distances: np.ndarray
  26	    """Score distance to the drawn donor as float64, shape `(n_recipients,)`."""
  27	
  28	
  29	def _fail_if_pmm_inputs_invalid(  # noqa: PLR0913
  30	    recipient_scores: np.ndarray,
  31	    donor_scores: np.ndarray,
  32	    donor_values: np.ndarray,
  33	    k: int,
  34	    caliper: float | None,
  35	    exclude: Sequence[Sequence[int]] | None,
  36	) -> None:
  37	    for name, arr in (
  38	        ("recipient_scores", recipient_scores),
  39	        ("donor_scores", donor_scores),
  40	        ("donor_values", donor_values),
  41	    ):
  42	        if arr.ndim != 1:
  43	            msg = f"{name} must be 1-D, got {arr.ndim}-D"
  44	            raise ValueError(msg)
  45	        if not np.all(np.isfinite(arr)):
  46	            msg = f"{name} must be finite (no NaN/inf)"
  47	            raise ValueError(msg)
  48	    if donor_scores.shape[0] != donor_values.shape[0]:
  49	        msg = (
  50	            "donor_scores and donor_values must have equal length, got "
  51	            f"{donor_scores.shape[0]} and {donor_values.shape[0]}"
  52	        )
  53	        raise ValueError(msg)
  54	    if donor_scores.shape[0] == 0:
  55	        msg = "donors must be non-empty"
  56	        raise ValueError(msg)
  57	    if not isinstance(k, int) or isinstance(k, bool):
  58	        msg = f"k must be an integer, got {type(k).__name__}"
  59	        raise TypeError(msg)
  60	    if k < 1:
  61	        msg = f"k must be >= 1, got {k}"
  62	        raise ValueError(msg)
  63	    if caliper is not None and (not np.isfinite(caliper) or caliper < 0):
  64	        msg = f"caliper must be finite and non-negative, got {caliper}"
  65	        raise ValueError(msg)
  66	    if exclude is not None:
  67	        _fail_if_exclude_invalid(
  68	            exclude, recipient_scores.shape[0], donor_scores.shape[0]
  69	        )
  70	
  71	
  72	def _fail_if_exclude_invalid(
  73	    exclude: Sequence[Sequence[int]], n_recipients: int, n_donors: int
  74	) -> None:
  75	    if len(exclude) != n_recipients:
  76	        msg = (
  77	            "exclude must have one entry per recipient, got "
  78	            f"{len(exclude)} for {n_recipients} recipients"
  79	        )
  80	        raise ValueError(msg)
  81	    for r_idx, entry in enumerate(exclude):
  82	        entry_arr = np.asarray(entry)
  83	        if entry_arr.size == 0:
  84	            continue
  85	        if entry_arr.ndim != 1:
  86	            msg = f"exclude[{r_idx}] must be a 1-D sequence of donor indices"
  87	            raise ValueError(msg)
  88	        if entry_arr.dtype == np.bool_:
  89	            msg = f"exclude[{r_idx}] must contain integers, not booleans"
  90	            raise ValueError(msg)
  91	        if not np.issubdtype(entry_arr.dtype, np.integer):
  92	            msg = f"exclude[{r_idx}] must contain integer donor indices"
  93	            raise ValueError(msg)
  94	        if np.any((entry_arr < 0) | (entry_arr >= n_donors)):
  95	            msg = f"exclude[{r_idx}] has donor indices outside [0, {n_donors})"
  96	            raise ValueError(msg)
  97	
  98	
  99	def pmm_draw(  # noqa: PLR0913
 100	    recipient_scores: np.ndarray,
 101	    donor_scores: np.ndarray,
 102	    donor_values: np.ndarray,
 103	    k: int,
 104	    rng: np.random.Generator,
 105	    caliper: float | None = None,
 106	    exclude: Sequence[Sequence[int]] | None = None,
 107	) -> PmmResult:
 108	    """Draw one near, eligible donor's observed value per recipient.
 109	
 110	    For each recipient the donor set is filtered to the eligible candidates — those
 111	    not in that recipient's `exclude` list and (if a `caliper` is given) within it —
 112	    *before* the nearest `k` are selected and one is drawn with `rng`. This
 113	    guarantees an out-of-caliper or excluded donor is never returned.
 114	
 115	    Args:
 116	        recipient_scores: Finite predictive scores, shape `(n_recipients,)`.
 117	        donor_scores: Finite predictive scores, shape `(n_donors,)`.
 118	        donor_values: Finite observed values, shape `(n_donors,)`.
 119	        k: Number of nearest eligible donors to sample from (>= 1).
 120	        rng: NumPy random generator.
 121	        caliper: Maximum allowed score distance to a donor, if set (>= 0).
 122	        exclude: Per-recipient sequences of donor indices to exclude, if any.
 123	
 124	    Returns:
 125	        A `PmmResult` with drawn values (float64), donor indices, and distances.
 126	
 127	    Raises:
 128	        ValueError: On invalid inputs, or if a recipient has no eligible donor.
 129	    """
 130	    _fail_if_pmm_inputs_invalid(
 131	        recipient_scores, donor_scores, donor_values, k, caliper, exclude
 132	    )
 133	    all_indices = np.arange(donor_scores.shape[0])
 134	    n_recipients = recipient_scores.shape[0]
 135	    values = np.empty(n_recipients, dtype=np.float64)
 136	    donor_indices = np.empty(n_recipients, dtype=np.intp)
 137	    distances_out = np.empty(n_recipients, dtype=np.float64)
 138	    for i, score in enumerate(recipient_scores):
 139	        eligible = all_indices
 140	        if exclude is not None:
 141	            excluded = np.asarray(tuple(exclude[i]), dtype=np.intp)
 142	            eligible = eligible[~np.isin(eligible, excluded)]
 143	        distances = np.abs(donor_scores[eligible] - score)
 144	        if caliper is not None:
 145	            within = distances <= caliper
 146	            eligible = eligible[within]
 147	            distances = distances[within]
 148	        if eligible.shape[0] == 0:
 149	            msg = f"No eligible donor within caliper {caliper} for recipient {i}."
 150	            raise ValueError(msg)
 151	        nearest = np.argsort(distances)[:k]
 152	        chosen = rng.choice(nearest)
 153	        donor_indices[i] = eligible[chosen]
 154	        values[i] = float(donor_values[eligible[chosen]])
 155	        distances_out[i] = float(distances[chosen])
 156	    return PmmResult(
 157	        values=values, donor_indices=donor_indices, distances=distances_out
 158	    )
```


### wealth_imputation/features.py

```py
   1	"""Predictor registry for the wealth models, mapped to cleaned SOEP-Core columns.
   2	
   3	Each `FeatureSpec` pins one model predictor to its cleaned output column, the module
   4	that produces it, the level it is measured at (person or household), and whether it is
   5	continuous or categorical. Names are confirmed against both the Milestone-0 covariate
   6	inventory (raw availability) and the clean-module sources (cleaned output), so the
   7	model stage selects predictors by confirmed name rather than guessing. Household-level
   8	predictors are broadcast to persons via `hh_id` during feature assembly.
   9	"""
  10	
  11	from collections.abc import Mapping, Sequence
  12	from dataclasses import dataclass
  13	from types import MappingProxyType
  14	from typing import Literal
  15	
  16	import numpy as np
  17	import pandas as pd
  18	
  19	_PERSON_KEYS = ("p_id", "hh_id", "survey_year")
  20	_HOUSEHOLD_KEYS = ("hh_id", "survey_year")
  21	
  22	
  23	@dataclass(frozen=True)
  24	class FeatureSpec:
  25	    """One model predictor mapped to its cleaned source column."""
  26	
  27	    column: str
  28	    """Cleaned output column name in `source_module`."""
  29	    source_module: str
  30	    """`MODULES` catalog key of the module that produces the column."""
  31	    level: Literal["person", "household"]
  32	    """Whether the predictor is measured per person or per household."""
  33	    kind: Literal["continuous", "categorical"]
  34	    """Whether the predictor enters the model as a number or a category."""
  35	
  36	
  37	FEATURE_SPECS: tuple[FeatureSpec, ...] = (
  38	    FeatureSpec("age", "pequiv", "person", "continuous"),
  39	    FeatureSpec("gender", "pequiv", "person", "categorical"),
  40	    FeatureSpec("number_of_persons_hh", "pequiv", "person", "continuous"),
  41	    FeatureSpec("number_of_children_living_in_hh", "pequiv", "person", "continuous"),
  42	    FeatureSpec("federal_state_of_residence", "pequiv", "person", "categorical"),
  43	    FeatureSpec("einkommen_nach_steuern_y_hh", "pequiv", "person", "continuous"),
  44	    FeatureSpec("education_isced", "pgen", "person", "categorical"),
  45	    FeatureSpec("employment_status", "pgen", "person", "categorical"),
  46	    FeatureSpec("marital_status", "pgen", "person", "categorical"),
  47	    FeatureSpec("occupation_status", "pgen", "person", "categorical"),
  48	    FeatureSpec("self_employed", "pgen", "person", "categorical"),
  49	    FeatureSpec("retired", "pgen", "person", "categorical"),
  50	    FeatureSpec("gross_labor_income_previous_month_m", "pgen", "person", "continuous"),
  51	    FeatureSpec("tenure", "pgen", "person", "continuous"),
  52	    FeatureSpec("migration_background", "ppathl", "person", "categorical"),
  53	    FeatureSpec("rented_or_owned", "hgen", "household", "categorical"),
  54	    FeatureSpec("living_space_hh", "hgen", "household", "continuous"),
  55	    FeatureSpec("building_year_hh_min", "hgen", "household", "continuous"),
  56	)
  57	
  58	
  59	def assemble_feature_matrix(modules: Mapping[str, pd.DataFrame]) -> pd.DataFrame:
  60	    """Join the cleaned modules into one person-level predictor matrix.
  61	
  62	    Person-level modules are merged on `(p_id, hh_id, survey_year)`; household-level
  63	    modules are then left-joined on `(hh_id, survey_year)`, broadcasting each household
  64	    predictor to its members. Only the registered feature columns (plus keys) are kept.
  65	
  66	    Args:
  67	        modules: `MODULES` name -> cleaned module frame. Must contain every source
  68	            module in `FEATURE_SPECS` with its required columns.
  69	
  70	    Returns:
  71	        One row per person-year with `p_id`, `hh_id`, `survey_year`, and every
  72	        registered feature column.
  73	
  74	    Raises:
  75	        ValueError: If a source module or a registered column is missing.
  76	    """
  77	    fail_if_features_missing(modules)
  78	    columns_by_module = required_columns_by_module()
  79	    person_modules = sorted(
  80	        {spec.source_module for spec in FEATURE_SPECS if spec.level == "person"}
  81	    )
  82	    household_modules = sorted(
  83	        {spec.source_module for spec in FEATURE_SPECS if spec.level == "household"}
  84	    )
  85	    person_frames = [
  86	        modules[module][list(columns_by_module[module])] for module in person_modules
  87	    ]
  88	    matrix = person_frames[0]
  89	    for subset in person_frames[1:]:
  90	        matrix = matrix.merge(subset, on=list(_PERSON_KEYS), how="outer")
  91	    for module in household_modules:
  92	        subset = modules[module][list(columns_by_module[module])]
  93	        matrix = matrix.merge(subset, on=list(_HOUSEHOLD_KEYS), how="left")
  94	    return matrix
  95	
  96	
  97	def select_household_heads(frame: pd.DataFrame) -> pd.DataFrame:
  98	    """Keep one representative row -- the oldest member -- per household and year.
  99	
 100	    Representing each household by its oldest member lets the simulation aggregate one
 101	    row per household without summing jointly-held amounts across members (which would
 102	    double-count, since SOEP-Core omits the person-level ownership shares).
 103	
 104	    Args:
 105	        frame: Rows with `p_id`, `hh_id`, `survey_year`, and `age`.
 106	
 107	    Returns:
 108	        One row per `(hh_id, survey_year)`, the member with the greatest `age`.
 109	    """
 110	    ordered = frame.sort_values(["hh_id", "survey_year", "age"])
 111	    return ordered.drop_duplicates(
 112	        subset=["hh_id", "survey_year"], keep="last"
 113	    ).reset_index(drop=True)
 114	
 115	
 116	def encode_design_matrix(frame: pd.DataFrame, columns: Sequence[str]) -> np.ndarray:
 117	    """Return a float64 design matrix, filling missing values with column medians.
 118	
 119	    Args:
 120	        frame: Source frame containing every name in `columns`.
 121	        columns: Predictor columns to encode, in order.
 122	
 123	    Returns:
 124	        A `(len(frame), len(columns))` float64 array; an all-missing column becomes
 125	        zeros.
 126	    """
 127	    encoded = []
 128	    for column in columns:
 129	        values = pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype="float64")
 130	        median = np.nanmedian(values) if np.any(~np.isnan(values)) else 0.0
 131	        encoded.append(np.where(np.isnan(values), median, values))
 132	    if not encoded:
 133	        return np.empty((len(frame), 0), dtype="float64")
 134	    return np.column_stack(encoded).astype("float64")
 135	
 136	
 137	@dataclass(frozen=True)
 138	class CategoricalEncoder:
 139	    """Fixed categories per column, learned from training, for stable one-hot width."""
 140	
 141	    categories: Mapping[str, tuple[str, ...]]
 142	    """Column name -> the sorted distinct training categories."""
 143	
 144	
 145	def fit_categorical_encoder(
 146	    frame: pd.DataFrame, columns: Sequence[str]
 147	) -> CategoricalEncoder:
 148	    """Record the sorted distinct categories of each column for later encoding.
 149	
 150	    Args:
 151	        frame: Training frame containing every name in `columns`.
 152	        columns: Categorical predictor columns.
 153	
 154	    Returns:
 155	        A `CategoricalEncoder` with one fixed category tuple per column.
 156	    """
 157	    categories = {
 158	        column: tuple(sorted(frame[column].dropna().astype(str).unique()))
 159	        for column in columns
 160	    }
 161	    return CategoricalEncoder(categories=MappingProxyType(categories))
 162	
 163	
 164	def encode_features(
 165	    frame: pd.DataFrame,
 166	    *,
 167	    continuous_columns: Sequence[str],
 168	    encoder: CategoricalEncoder,
 169	) -> np.ndarray:
 170	    """Build a float64 design matrix from continuous and one-hot categorical columns.
 171	
 172	    Continuous columns are median-filled; categorical columns are one-hot encoded
 173	    against the encoder's fixed categories, so an unseen or missing level maps to an
 174	    all-zero block and train and recipient matrices share an identical column layout.
 175	
 176	    Args:
 177	        frame: Frame to encode.
 178	        continuous_columns: Numeric predictor columns.
 179	        encoder: Encoder carrying the fixed categorical levels.
 180	
 181	    Returns:
 182	        A `(len(frame), n_continuous + sum(n_categories))` float64 design matrix.
 183	    """
 184	    blocks = []
 185	    if continuous_columns:
 186	        blocks.append(encode_design_matrix(frame, continuous_columns))
 187	    for column, levels in encoder.categories.items():
 188	        as_string = frame[column].astype(str)
 189	        blocks.extend(
 190	            (as_string == level).to_numpy(dtype="float64").reshape(-1, 1)
 191	            for level in levels
 192	        )
 193	    if not blocks:
 194	        return np.empty((len(frame), 0), dtype="float64")
 195	    return np.hstack(blocks).astype("float64")
 196	
 197	
 198	def lagged_wealth(
 199	    wealth_panel: pd.DataFrame,
 200	    *,
 201	    value_columns: Sequence[str],
 202	    wave_gap: int = 5,
 203	) -> pd.DataFrame:
 204	    """Shift prior-wave wealth values forward by one wealth-module cycle.
 205	
 206	    Each person's wealth at `survey_year` becomes a `lagged_`-prefixed predictor for
 207	    that person at `survey_year + wave_gap` (the next wealth wave). The earliest wave
 208	    has no predecessor and so is absent from the result; assembly left-joins this onto
 209	    the feature matrix, leaving new entrants' lags as NA.
 210	
 211	    Args:
 212	        wealth_panel: Columns `p_id`, `survey_year`, and every name in
 213	            `value_columns`.
 214	        value_columns: Prior-wave wealth columns to carry forward.
 215	        wave_gap: Years between wealth waves (the SOEP module runs every five years).
 216	
 217	    Returns:
 218	        Columns `p_id`, `survey_year` (the wave the lag applies to), and
 219	        `lagged_<column>` for each value column.
 220	
 221	    Raises:
 222	        ValueError: If a required column is missing from `wealth_panel`.
 223	    """
 224	    required = ("p_id", "survey_year", *value_columns)
 225	    missing = [column for column in required if column not in wealth_panel.columns]
 226	    if missing:
 227	        msg = f"wealth_panel is missing required columns: {missing}"
 228	        raise ValueError(msg)
 229	    lagged = wealth_panel[list(required)].copy()
 230	    lagged["survey_year"] = lagged["survey_year"] + wave_gap
 231	    return lagged.rename(
 232	        columns={column: f"lagged_{column}" for column in value_columns}
 233	    )
 234	
 235	
 236	def required_columns_by_module() -> dict[str, tuple[str, ...]]:
 237	    """Return the columns each source module must provide, including its keys.
 238	
 239	    Returns:
 240	        Module name -> the key columns for its level plus every registered feature
 241	        column drawn from that module.
 242	    """
 243	    by_module: dict[str, list[str]] = {}
 244	    for spec in FEATURE_SPECS:
 245	        keys = _PERSON_KEYS if spec.level == "person" else _HOUSEHOLD_KEYS
 246	        columns = by_module.setdefault(spec.source_module, list(keys))
 247	        if spec.column not in columns:
 248	            columns.append(spec.column)
 249	    return {module: tuple(columns) for module, columns in by_module.items()}
 250	
 251	
 252	def fail_if_features_missing(modules: Mapping[str, pd.DataFrame]) -> None:
 253	    """Raise if any registered feature column is absent from its source module.
 254	
 255	    Args:
 256	        modules: `MODULES` name -> cleaned module frame.
 257	
 258	    Raises:
 259	        ValueError: If a source module is absent, or a registered column is missing
 260	            from the module that should produce it.
 261	    """
 262	    for module, columns in required_columns_by_module().items():
 263	        if module not in modules:
 264	            msg = f"Required source module '{module}' is absent from modules."
 265	            raise ValueError(msg)
 266	        missing = [
 267	            column for column in columns if column not in modules[module].columns
 268	        ]
 269	        if missing:
 270	            msg = f"Module '{module}' is missing required columns: {missing}"
 271	            raise ValueError(msg)
```


### wealth_imputation/impute.py

```py
   1	"""Run the provisional 2022 household-wealth imputation end to end.
   2	
   3	Targets are bias-free household component totals: the joint components (property,
   4	financial, vehicles) come from the DIW-aggregated `hwealth` file (correctly
   5	share-summed), and the person-direct components (insurances, consumer debt) -- which
   6	have no ownership share and so are absent from the household file -- are summed from
   7	person `pwealth` across members, which is unbiased. The five components plus a residual
   8	to the official total reconstruct net wealth. The pipeline composes the tested blocks:
   9	
  10	1. assemble the person feature matrix, attach each person's lagged prior-wave wealth,
  11	   and represent each household by its oldest member (`select_household_heads`);
  12	2. merge the joint household targets and the summed person-direct targets onto heads;
  13	3. restrict training to the wealth waves, fit ownership + amount models per component
  14	   on continuous + one-hot categorical predictors, with cross-wave donor values
  15	   deflated to 2022 terms by asset-class indices (MSCI -> financial, BIS house prices
  16	   -> property, REX bonds -> insurances);
  17	4. simulate joint draws into household net-total intervals, shifted by a per-household
  18	   residual to the official total -- a two-part model (logistic incidence times an
  19	   asinh amount model, clipped at zero) allocates the unmodelled business /
  20	   other-real-estate mass to the households whose covariates predict it, keeping it
  21	   concentrated rather than smeared across every household.
  22	
  23	Documented approximations: vehicles and consumer-debt donors are not deflated (no
  24	asset index); the residual is deflated to 2022 by a property/equity blend
  25	(`RESIDUAL_INDEX`) standing in for its business and other-real-estate mass; implicate
  26	`a` is the representative value; household property is taken net of mortgage.
  27	"""
  28	
  29	from collections.abc import Mapping, Sequence
  30	from dataclasses import dataclass
  31	
  32	import numpy as np
  33	import pandas as pd
  34	
  35	from soep_preparation.wealth_imputation.components import (
  36	    CanonicalComponent,
  37	    component_sign,
  38	)
  39	from soep_preparation.wealth_imputation.deflation import deflate_donor_values
  40	from soep_preparation.wealth_imputation.features import (
  41	    FEATURE_SPECS,
  42	    assemble_feature_matrix,
  43	    encode_features,
  44	    fit_categorical_encoder,
  45	    lagged_wealth,
  46	    select_household_heads,
  47	)
  48	from soep_preparation.wealth_imputation.market_indices import (
  49	    HOUSE_PRICE_INDEX,
  50	    MSCI_WORLD_INDEX,
  51	    RESIDUAL_INDEX,
  52	    REX_BOND_INDEX,
  53	)
  54	from soep_preparation.wealth_imputation.residual_model import ResidualModel
  55	from soep_preparation.wealth_imputation.simulate import simulate_household_totals
  56	from soep_preparation.wealth_imputation.training import (
  57	    build_component_config,
  58	    fit_component_models,
  59	)
  60	
  61	_PREDICTION_WAVE = 2022
  62	_WEALTH_WAVES = (2002, 2007, 2012, 2017)
  63	_MIN_TRAINING_ROWS = 5
  64	_MIN_OWNERS = 2
  65	_KEYS = ["p_id", "hh_id", "survey_year"]
  66	_HH_KEYS = ["hh_id", "survey_year"]
  67	
  68	# Person-level cleaned pwealth columns (implicate `a`) lagged as predictors.
  69	_LAG_SOURCE_COLUMNS = (
  70	    "property_value_primary_residence_a",
  71	    "financial_assets_value_a",
  72	    "private_insurances_value_a",
  73	    "vehicles_value_a",
  74	    "consumer_debt_value_a",
  75	)
  76	
  77	# Joint components taken from the DIW-aggregated household file (correctly
  78	# share-summed). Net property folds in the mortgage.
  79	_HW_PROPERTY = "hh_net_property_value_primary_residence_a"
  80	_HW_FINANCIAL = "hh_financial_assets_value_a"
  81	_HW_VEHICLES = "hh_vehicles_value_a"
  82	
  83	# Person-direct components (no ownership share) absent from the household file: summed
  84	# from person `pwealth` across members, which is unbiased because they are individual
  85	# holdings (no joint double-counting).
  86	_PERSON_DIRECT_SOURCE = {
  87	    "hh_private_insurances_value_a": "private_insurances_value_a",
  88	    "hh_consumer_debt_value_a": "consumer_debt_value_a",
  89	}
  90	
  91	# Each component's target column and the asset-class index used to deflate its donors.
  92	_COMPONENT_COLUMNS: dict[CanonicalComponent, str] = {
  93	    CanonicalComponent.OWNER_OCCUPIED_PROPERTY_GROSS: _HW_PROPERTY,
  94	    CanonicalComponent.FINANCIAL_ASSETS: _HW_FINANCIAL,
  95	    CanonicalComponent.VEHICLES: _HW_VEHICLES,
  96	    CanonicalComponent.PRIVATE_PENSION: "hh_private_insurances_value_a",
  97	    CanonicalComponent.CONSUMER_DEBT: "hh_consumer_debt_value_a",
  98	}
  99	_COMPONENT_INDEX: dict[CanonicalComponent, Mapping[int, float] | None] = {
 100	    CanonicalComponent.OWNER_OCCUPIED_PROPERTY_GROSS: HOUSE_PRICE_INDEX,
 101	    CanonicalComponent.FINANCIAL_ASSETS: MSCI_WORLD_INDEX,
 102	    CanonicalComponent.VEHICLES: None,  # depreciating; no asset index
 103	    CanonicalComponent.PRIVATE_PENSION: REX_BOND_INDEX,
 104	    CanonicalComponent.CONSUMER_DEBT: None,  # nominal debt
 105	}
 106	_OFFICIAL_TOTAL_COLUMN = "hh_net_overall_wealth_including_vehicles_and_student_loans_a"
 107	
 108	
 109	@dataclass(frozen=True)
 110	class ImputationResult:
 111	    """The 2022 household-wealth intervals and a disclosure-safe run summary."""
 112	
 113	    intervals: pd.DataFrame
 114	    """Columns `hh_id`, `survey_year`, `point_estimate`, `lower`, `upper`."""
 115	    summary: dict
 116	    """Counts and choices for the run (no row-level data)."""
 117	
 118	
 119	def run_imputation(
 120	    modules: Mapping[str, pd.DataFrame],
 121	    *,
 122	    n_draws: int,
 123	    seed: int,
 124	    k: int,
 125	    level: float = 0.9,
 126	) -> ImputationResult:
 127	    """Impute 2022 household net wealth as donor-based intervals.
 128	
 129	    Args:
 130	        modules: Cleaned `MODULES` frames; must include `pwealth`, `hwealth`, and the
 131	            feature modules used by `assemble_feature_matrix`.
 132	        n_draws: Number of complete joint draws.
 133	        seed: Seed for model fitting and the draw RNG.
 134	        k: Nearest-donor count for PMM (clipped to each component's owner count).
 135	        level: Central coverage of the reported intervals.
 136	
 137	    Returns:
 138	        An `ImputationResult` with the 2022 intervals and a run summary.
 139	
 140	    Raises:
 141	        ValueError: If there are no 2022 recipients or no component can be fit.
 142	    """
 143	    heads = _household_heads(modules)
 144	    continuous_columns = [
 145	        spec.column for spec in FEATURE_SPECS if spec.kind == "continuous"
 146	    ] + [f"lagged_{column}" for column in _LAG_SOURCE_COLUMNS]
 147	    categorical_columns = [
 148	        spec.column for spec in FEATURE_SPECS if spec.kind == "categorical"
 149	    ]
 150	
 151	    training = heads[heads["survey_year"].isin(_WEALTH_WAVES)]
 152	    recipients = heads[heads["survey_year"] == _PREDICTION_WAVE].reset_index(drop=True)
 153	    if recipients.empty:
 154	        msg = "No 2022 recipients found; cannot impute the prediction wave."
 155	        raise ValueError(msg)
 156	
 157	    encoder = fit_categorical_encoder(training, categorical_columns)
 158	    recipient_design = encode_features(
 159	        recipients, continuous_columns=continuous_columns, encoder=encoder
 160	    )
 161	    recipient_keys = recipients[_KEYS]
 162	
 163	    configs = []
 164	    used: list[CanonicalComponent] = []
 165	    skipped: list[str] = []
 166	    for component, column in _COMPONENT_COLUMNS.items():
 167	        trained = training.dropna(subset=[column])
 168	        values = trained[column].to_numpy(dtype="float64")
 169	        owners = int((values > 0.0).sum())
 170	        if (
 171	            len(trained) < _MIN_TRAINING_ROWS
 172	            or {int(value > 0.0) for value in values} != {0, 1}
 173	            or owners < _MIN_OWNERS
 174	        ):
 175	            skipped.append(component.value)
 176	            continue
 177	        index = _COMPONENT_INDEX[component]
 178	        if index is not None:
 179	            values = deflate_donor_values(
 180	                values,
 181	                trained["survey_year"].tolist(),
 182	                index_by_year=index,
 183	                target_year=_PREDICTION_WAVE,
 184	            )
 185	        design = encode_features(
 186	            trained, continuous_columns=continuous_columns, encoder=encoder
 187	        )
 188	        models = fit_component_models(design, values, seed=seed)
 189	        owner_mask = values > 0.0
 190	        configs.append(
 191	            build_component_config(
 192	                component=component,
 193	                models=models,
 194	                recipient_features=recipient_design,
 195	                recipient_shares=np.ones(len(recipient_keys), dtype="float64"),
 196	                donor_features=design[owner_mask],
 197	                donor_values=values[owner_mask],
 198	                k=min(k, owners),
 199	            )
 200	        )
 201	        used.append(component)
 202	    if not configs:
 203	        msg = "No wealth component could be fit on the historical waves."
 204	        raise ValueError(msg)
 205	
 206	    intervals = simulate_household_totals(
 207	        recipient_keys,
 208	        configs,
 209	        n_draws=n_draws,
 210	        rng=np.random.default_rng(seed),
 211	        level=level,
 212	    )
 213	    have_total, residual = _training_residual(
 214	        training, used, target_year=_PREDICTION_WAVE
 215	    )
 216	    residual_owners = int((residual > 0.0).sum())
 217	    if (
 218	        len(have_total) >= _MIN_TRAINING_ROWS
 219	        and _MIN_OWNERS <= residual_owners < residual.size
 220	    ):
 221	        residual_design = encode_features(
 222	            have_total, continuous_columns=continuous_columns, encoder=encoder
 223	        )
 224	        recipient_residual = ResidualModel.fit(
 225	            residual_design, residual, seed=seed
 226	        ).predict(recipient_design)
 227	        residual_model_kind = "two_part"
 228	    else:
 229	        flat = float(np.mean(residual)) if residual.size else 0.0
 230	        recipient_residual = np.full(len(recipients), flat, dtype="float64")
 231	        residual_model_kind = "flat"
 232	    residual_frame = recipients[_HH_KEYS].assign(applied_residual=recipient_residual)
 233	    intervals = intervals.merge(
 234	        residual_frame, on=_HH_KEYS, how="left", validate="one_to_one"
 235	    )
 236	    for column in ("point_estimate", "lower", "upper"):
 237	        intervals[column] = intervals[column] + intervals["applied_residual"]
 238	    intervals = intervals.drop(columns="applied_residual")
 239	    summary = {
 240	        "n_recipients": len(recipient_keys),
 241	        "n_training_heads": len(training),
 242	        "components_used": [component.value for component in used],
 243	        "components_skipped": skipped,
 244	        "residual_model": residual_model_kind,
 245	        "mean_residual": float(np.mean(recipient_residual)),
 246	        "n_draws": n_draws,
 247	        "k": k,
 248	        "level": level,
 249	    }
 250	    return ImputationResult(intervals=intervals, summary=summary)
 251	
 252	
 253	def _household_heads(modules: Mapping[str, pd.DataFrame]) -> pd.DataFrame:
 254	    pwealth = modules["pwealth"]
 255	    features = assemble_feature_matrix(modules)
 256	    lagged = lagged_wealth(
 257	        pwealth[["p_id", "survey_year", *_LAG_SOURCE_COLUMNS]],
 258	        value_columns=_LAG_SOURCE_COLUMNS,
 259	    )
 260	    with_lag = features.merge(lagged, on=["p_id", "survey_year"], how="left")
 261	    heads = select_household_heads(with_lag)
 262	    household_wealth = modules["hwealth"][
 263	        [*_HH_KEYS, _HW_PROPERTY, _HW_FINANCIAL, _HW_VEHICLES, _OFFICIAL_TOTAL_COLUMN]
 264	    ]
 265	    heads = heads.merge(household_wealth, on=_HH_KEYS, how="left")
 266	    return heads.merge(_household_person_direct(pwealth), on=_HH_KEYS, how="left")
 267	
 268	
 269	def _household_person_direct(pwealth: pd.DataFrame) -> pd.DataFrame:
 270	    """Sum person-direct components (insurances, consumer debt) to the household.
 271	
 272	    These have no ownership share, so a plain member sum is the correct household
 273	    total -- there is no joint-ownership double-counting to worry about.
 274	    """
 275	    aggregation = {
 276	        target: (source, "sum") for target, source in _PERSON_DIRECT_SOURCE.items()
 277	    }
 278	    return pwealth.groupby(_HH_KEYS, as_index=False).agg(**aggregation)
 279	
 280	
 281	def _training_residual(
 282	    training: pd.DataFrame,
 283	    used: Sequence[CanonicalComponent],
 284	    *,
 285	    target_year: int,
 286	) -> tuple[pd.DataFrame, np.ndarray]:
 287	    """Return training heads with an official total and their residual, in 2022 terms.
 288	
 289	    The residual is `official_net_total - sum(component_sign * modelled_component)`
 290	    over the fitted components, kept in euros and signed (negative when modelled wealth
 291	    exceeds the official total). It is deflated from each household's wave into
 292	    `target_year` terms by `RESIDUAL_INDEX` -- a property/equity blend standing in for
 293	    the unmodelled business and other-real-estate mass -- so the time component is
 294	    explicit rather than absorbed into the OLS coefficients. Rows whose residual is
 295	    non-finite are dropped so the frame and the residual array stay aligned for
 296	    `ResidualModel.fit`.
 297	    """
 298	    have_total = training.dropna(subset=[_OFFICIAL_TOTAL_COLUMN])
 299	    if have_total.empty:
 300	        return have_total, np.empty(0, dtype="float64")
 301	    modelled = np.zeros(len(have_total), dtype="float64")
 302	    for component in used:
 303	        values = (
 304	            pd.to_numeric(have_total[_COMPONENT_COLUMNS[component]], errors="coerce")
 305	            .fillna(0.0)
 306	            .to_numpy(dtype="float64")
 307	        )
 308	        modelled += component_sign(component) * values
 309	    official = pd.to_numeric(
 310	        have_total[_OFFICIAL_TOTAL_COLUMN], errors="coerce"
 311	    ).to_numpy(dtype="float64")
 312	    residual = official - modelled
 313	    finite = np.isfinite(residual)
 314	    have_total = have_total[finite]
 315	    deflated = deflate_donor_values(
 316	        residual[finite],
 317	        have_total["survey_year"].tolist(),
 318	        index_by_year=RESIDUAL_INDEX,
 319	        target_year=target_year,
 320	    )
 321	    return have_total, deflated
```


### wealth_imputation/intervals.py

```py
   1	"""Assemble household-total intervals from the joint-draw distribution.
   2	
   3	Each draw is one complete joint draw already aggregated to the household total, so an
   4	interval is the empirical spread of those totals -- the median as point estimate and
   5	the central-`level` quantiles as bounds. Intervals are formed on the household-total
   6	distribution directly; component interval endpoints are **never** summed, which would
   7	ignore the cross-component dependence carried in each joint draw. Quantiles run in
   8	`float64` and the helper fails closed on invalid input.
   9	"""
  10	
  11	import numpy as np
  12	import pandas as pd
  13	
  14	_DRAW_COLUMNS = ("hh_id", "survey_year", "household_total_draw")
  15	_HOUSEHOLD_KEY_COLUMNS = ["hh_id", "survey_year"]
  16	
  17	
  18	def _fail_if_columns_missing(frame: pd.DataFrame, name: str) -> None:
  19	    missing = [col for col in _DRAW_COLUMNS if col not in frame.columns]
  20	    if missing:
  21	        msg = f"{name} is missing required columns: {missing}"
  22	        raise ValueError(msg)
  23	
  24	
  25	def _fail_if_level_invalid(level: float) -> None:
  26	    if not np.isfinite(level) or not (0.0 < level < 1.0):
  27	        msg = f"level must lie strictly in (0, 1), got {level}."
  28	        raise ValueError(msg)
  29	
  30	
  31	def household_total_intervals(
  32	    draws: pd.DataFrame, *, level: float = 0.9
  33	) -> pd.DataFrame:
  34	    """Summarise per-household total draws into a point estimate and interval.
  35	
  36	    Args:
  37	        draws: Columns `hh_id`, `survey_year`, `household_total_draw`. Each row is one
  38	            complete joint draw aggregated to the household total; multiple rows per
  39	            household span the implicate / donor / incidence draws.
  40	        level: Central coverage of the interval (e.g. `0.9` gives the 5th and 95th
  41	            percentiles). Must lie strictly in `(0, 1)`.
  42	
  43	    Returns:
  44	        Columns `hh_id`, `survey_year`, `point_estimate`, `lower`, `upper` (float64),
  45	        one row per household-year.
  46	
  47	    Raises:
  48	        ValueError: On missing columns, a `level` outside `(0, 1)`, or non-numeric /
  49	            non-finite draws.
  50	    """
  51	    _fail_if_columns_missing(draws, "draws")
  52	    _fail_if_level_invalid(level)
  53	    values = pd.to_numeric(draws["household_total_draw"], errors="raise").astype(
  54	        "float64"
  55	    )
  56	    if not np.isfinite(values.to_numpy()).all():
  57	        msg = "household_total_draw must be finite (no NaN/inf)."
  58	        raise ValueError(msg)
  59	    alpha = (1.0 - level) / 2.0
  60	    keyed = draws[_HOUSEHOLD_KEY_COLUMNS].assign(household_total_draw=values)
  61	    grouped = keyed.groupby(_HOUSEHOLD_KEY_COLUMNS, observed=True)[
  62	        "household_total_draw"
  63	    ]
  64	    summary = grouped.agg(
  65	        point_estimate=lambda series: float(np.quantile(series, 0.5)),
  66	        lower=lambda series: float(np.quantile(series, alpha)),
  67	        upper=lambda series: float(np.quantile(series, 1.0 - alpha)),
  68	    ).reset_index()
  69	    for column in ("point_estimate", "lower", "upper"):
  70	        summary[column] = summary[column].astype("float64")
  71	    return summary
```


### wealth_imputation/market_indices.py

```py
   1	"""Annual asset-class index levels for cross-wave donor deflation.
   2	
   3	Donors observed in an earlier wealth wave understate 2022 values when asset prices
   4	ran ahead of consumer prices, so the donor pool is brought to 2022 terms with
   5	component-appropriate indices rather than a uniform CPI. Index levels are base 100 in
   6	2000.
   7	
   8	Sources:
   9	- MSCI World and REX (5-year German government bonds): annual series provided by
  10	  MImmesberger on PR #88 (`benchmark_index_annual.csv`), base 100 in 2000.
  11	- House prices: BIS nominal residential property prices for Germany, FRED series
  12	  `QDEN628BIS`, annual averages of the quarterly index (base 100 in 2010); used to
  13	  deflate the owner-occupied and other-real-estate components.
  14	"""
  15	
  16	from types import MappingProxyType
  17	
  18	MSCI_WORLD_INDEX: MappingProxyType[int, float] = MappingProxyType(
  19	    {
  20	        2000: 100.00,
  21	        2001: 88.98,
  22	        2002: 61.16,
  23	        2003: 68.67,
  24	        2004: 73.79,
  25	        2005: 94.10,
  26	        2006: 102.61,
  27	        2007: 104.12,
  28	        2008: 63.20,
  29	        2009: 83.55,
  30	        2010: 101.23,
  31	        2011: 97.43,
  32	        2012: 111.66,
  33	        2013: 132.30,
  34	        2014: 157.40,
  35	        2015: 172.10,
  36	        2016: 192.87,
  37	        2017: 210.64,
  38	        2018: 200.65,
  39	        2019: 261.32,
  40	        2020: 280.21,
  41	        2021: 358.35,
  42	        2022: 312.28,
  43	        2023: 371.90,
  44	        2024: 467.85,
  45	    }
  46	)
  47	
  48	REX_BOND_INDEX: MappingProxyType[int, float] = MappingProxyType(
  49	    {
  50	        2000: 100.00,
  51	        2001: 105.91,
  52	        2002: 115.84,
  53	        2003: 120.54,
  54	        2004: 128.43,
  55	        2005: 132.88,
  56	        2006: 133.22,
  57	        2007: 137.09,
  58	        2008: 151.50,
  59	        2009: 159.68,
  60	        2010: 167.11,
  61	        2011: 180.33,
  62	        2012: 188.09,
  63	        2013: 187.07,
  64	        2014: 197.10,
  65	        2015: 198.16,
  66	        2016: 201.99,
  67	        2017: 199.54,
  68	        2018: 201.92,
  69	        2019: 202.68,
  70	        2020: 204.15,
  71	        2021: 201.03,
  72	        2022: 178.85,
  73	        2023: 186.26,
  74	        2024: 188.37,
  75	    }
  76	)
  77	
  78	_BASE_YEAR = 2000
  79	_REBASE_LEVEL = 100.0
  80	_RESIDUAL_PROPERTY_WEIGHT = 0.5
  81	
  82	
  83	def _rebased(index: MappingProxyType[int, float]) -> dict[int, float]:
  84	    """Rescale an index so its base-year level is `_REBASE_LEVEL`."""
  85	    base = index[_BASE_YEAR]
  86	    return {year: level / base * _REBASE_LEVEL for year, level in index.items()}
  87	
  88	
  89	HOUSE_PRICE_INDEX: MappingProxyType[int, float] = MappingProxyType(
  90	    {
  91	        2000: 101.37,
  92	        2001: 101.27,
  93	        2002: 100.58,
  94	        2003: 99.18,
  95	        2004: 97.88,
  96	        2005: 96.98,
  97	        2006: 97.07,
  98	        2007: 96.88,
  99	        2008: 100.05,
 100	        2009: 99.42,
 101	        2010: 100.00,
 102	        2011: 102.42,
 103	        2012: 105.47,
 104	        2013: 108.67,
 105	        2014: 111.85,
 106	        2015: 117.12,
 107	        2016: 125.93,
 108	        2017: 133.62,
 109	        2018: 142.53,
 110	        2019: 150.75,
 111	        2020: 162.47,
 112	        2021: 181.28,
 113	        2022: 192.22,
 114	        2023: 176.03,
 115	        2024: 173.35,
 116	    }
 117	)
 118	
 119	# The residual to the official total is chiefly business assets and other real estate.
 120	# Lacking a separate series for either, deflate it by an equal-weight blend of the
 121	# property and equity indices (other real estate ~ house prices; business ~ equities),
 122	# each rebased to a common base year so the 50/50 weighting is economic, not an artefact
 123	# of the legs' different base years. The weight is a rough default, easily adjusted.
 124	_HOUSE_REBASED = _rebased(HOUSE_PRICE_INDEX)
 125	_MSCI_REBASED = _rebased(MSCI_WORLD_INDEX)
 126	RESIDUAL_INDEX: MappingProxyType[int, float] = MappingProxyType(
 127	    {
 128	        year: _RESIDUAL_PROPERTY_WEIGHT * _HOUSE_REBASED[year]
 129	        + (1.0 - _RESIDUAL_PROPERTY_WEIGHT) * _MSCI_REBASED[year]
 130	        for year in sorted(set(_HOUSE_REBASED) & set(_MSCI_REBASED))
 131	    }
 132	)
```


### wealth_imputation/ownership_model.py

```py
   1	"""Ownership-incidence model: a thin, fail-closed logistic-regression boundary.
   2	
   3	Wraps a scikit-learn `LogisticRegression` behind a small typed interface so the rest
   4	of the harness depends on `fit` / `probability`, not on estimator internals. The
   5	returned probability is `P(owns)` for each row and feeds the ownership step of
   6	`value_generator.draw_component`. Real covariates are wired in the (deferred) data
   7	stage; the wrapper itself is trained and tested on in-memory arrays.
   8	"""
   9	
  10	from dataclasses import dataclass
  11	
  12	import numpy as np
  13	from sklearn.linear_model import LogisticRegression
  14	
  15	
  16	def _fail_if_training_data_invalid(features: np.ndarray, owns: np.ndarray) -> None:
  17	    if features.ndim != 2:  # noqa: PLR2004 -- a design matrix is 2-D by definition
  18	        msg = f"features must be a 2-D design matrix, got {features.ndim}-D."
  19	        raise ValueError(msg)
  20	    if owns.ndim != 1:
  21	        msg = f"owns must be 1-D, got {owns.ndim}-D."
  22	        raise ValueError(msg)
  23	    if features.shape[0] != owns.shape[0]:
  24	        msg = (
  25	            "features and owns must have the same number of rows, got "
  26	            f"{features.shape[0]} and {owns.shape[0]}."
  27	        )
  28	        raise ValueError(msg)
  29	    if not np.all(np.isfinite(features)):
  30	        msg = "features must be finite (no NaN/inf)."
  31	        raise ValueError(msg)
  32	    unique = set(np.unique(owns).tolist())
  33	    if not unique <= {0, 1}:
  34	        msg = f"owns must be binary 0/1, got values {sorted(unique)}."
  35	        raise ValueError(msg)
  36	    if unique != {0, 1}:
  37	        msg = "owns must contain both classes (0 and 1) to fit an incidence model."
  38	        raise ValueError(msg)
  39	
  40	
  41	@dataclass(frozen=True)
  42	class OwnershipModel:
  43	    """A fitted ownership-incidence classifier."""
  44	
  45	    estimator: LogisticRegression
  46	    """The fitted scikit-learn logistic-regression estimator."""
  47	
  48	    @classmethod
  49	    def fit(
  50	        cls, features: np.ndarray, owns: np.ndarray, *, seed: int
  51	    ) -> OwnershipModel:
  52	        """Fit the incidence model on observed ownership outcomes.
  53	
  54	        Args:
  55	            features: Design matrix, shape `(n_rows, n_features)`, all finite.
  56	            owns: Binary ownership outcome per row (`0`/`1`), both classes present.
  57	            seed: Random seed for the estimator's deterministic solver state.
  58	
  59	        Returns:
  60	            A fitted `OwnershipModel`.
  61	
  62	        Raises:
  63	            ValueError: On a non-2-D design matrix, mismatched lengths, non-finite
  64	                features, or a non-binary / single-class outcome.
  65	        """
  66	        _fail_if_training_data_invalid(features, owns)
  67	        estimator = LogisticRegression(random_state=seed)
  68	        estimator.fit(features, owns)
  69	        return cls(estimator=estimator)
  70	
  71	    def probability(self, features: np.ndarray) -> np.ndarray:
  72	        """Return `P(owns)` for each row of `features` as float64.
  73	
  74	        Args:
  75	            features: Design matrix with the same column layout used in `fit`.
  76	
  77	        Returns:
  78	            Ownership probabilities, shape `(n_rows,)`, in `[0, 1]`.
  79	
  80	        Raises:
  81	            ValueError: On a non-2-D design matrix or non-finite features.
  82	        """
  83	        if features.ndim != 2:  # noqa: PLR2004 -- a design matrix is 2-D by definition
  84	            msg = f"features must be a 2-D design matrix, got {features.ndim}-D."
  85	            raise ValueError(msg)
  86	        if not np.all(np.isfinite(features)):
  87	            msg = "features must be finite (no NaN/inf)."
  88	            raise ValueError(msg)
  89	        return self.estimator.predict_proba(features)[:, 1].astype("float64")
```


### wealth_imputation/probe.py

```py
   1	"""Milestone-0 source probe: confirm registry variables exist, disclosure-safe.
   2	
   3	Reports only registry keys, presence booleans, and the wealth-pattern *column names*
   4	present in each probed source file — never row-level data — so it is safe to read
   5	from logs/artifacts under the no-data-access rule.
   6	"""
   7	
   8	import re
   9	from collections.abc import Mapping, Sequence
  10	
  11	from soep_preparation.wealth_imputation.registry import (
  12	    VerificationStatus,
  13	    WealthVariable,
  14	)
  15	
  16	# DIW generated wealth variables: a single component letter, four or five digits,
  17	# and an optional implicate suffix `a`-`e` (e.g. `p0100a`, `p0010a`, `w0101a`,
  18	# `p10000`). Matching column names lets us discover the real V41 names for any
  19	# component whose expected name probes absent.
  20	_WEALTH_COLUMN_PATTERN = re.compile(r"^[a-z]\d{4,5}[a-e]?$")
  21	
  22	
  23	def inventory_columns(
  24	    available_columns: Mapping[str, frozenset[str]],
  25	) -> dict[str, list[str]]:
  26	    """Return the sorted column names of each probed source file.
  27	
  28	    Disclosure-safe: column names only, no row-level data. Used to discover the real
  29	    covariate variable names in the feature-source files (`ppathl`, `pgen`, ...) so
  30	    model predictors are chosen against confirmed names rather than guessed.
  31	
  32	    Args:
  33	        available_columns: Source-file name -> set of its column names.
  34	
  35	    Returns:
  36	        Source-file name -> sorted list of its column names.
  37	    """
  38	    return {
  39	        source_file: sorted(columns)
  40	        for source_file, columns in available_columns.items()
  41	    }
  42	
  43	
  44	def assemble_probe_report(
  45	    entries: Sequence[WealthVariable],
  46	    available_columns: Mapping[str, frozenset[str]],
  47	) -> dict:
  48	    """Build a disclosure-safe presence report for registry entries.
  49	
  50	    Args:
  51	        entries: Registry entries to probe.
  52	        available_columns: Source-file name → set of its column names.
  53	
  54	    Returns:
  55	        A dict with per-entry presence flags, a numeric summary, and the
  56	        wealth-pattern column names observed in each probed source file. Contains
  57	        no row-level data.
  58	    """
  59	    rows = []
  60	    for entry in entries:
  61	        present = entry.raw_variable in available_columns.get(
  62	            entry.source_file, frozenset()
  63	        )
  64	        rows.append(
  65	            {
  66	                "component": entry.component.value,
  67	                "wave": entry.wave,
  68	                "source_file": entry.source_file,
  69	                "raw_variable": entry.raw_variable,
  70	                "present": present,
  71	                "verification_status": entry.verification_status.value,
  72	            }
  73	        )
  74	    n_present = sum(row["present"] for row in rows)
  75	    n_unresolved_required = sum(
  76	        entry.required_for_release
  77	        and entry.verification_status is VerificationStatus.UNRESOLVED
  78	        for entry in entries
  79	    )
  80	    summary = {
  81	        "n_entries": len(rows),
  82	        "n_present": n_present,
  83	        "n_missing": len(rows) - n_present,
  84	        "n_unresolved_required": n_unresolved_required,
  85	    }
  86	    observed_columns = {
  87	        source_file: sorted(
  88	            column for column in columns if _WEALTH_COLUMN_PATTERN.fullmatch(column)
  89	        )
  90	        for source_file, columns in available_columns.items()
  91	    }
  92	    return {
  93	        "entries": rows,
  94	        "summary": summary,
  95	        "observed_columns": observed_columns,
  96	    }
```


### wealth_imputation/registry.py

```py
   1	"""Typed semantic contract for raw wealth variables.
   2	
   3	Each `WealthVariable` declares one raw questionnaire item for one component in one
   4	wave, together with the verification status that gates it. Production reads only
   5	verified (or inferred) entries; an unresolved entry that is `required_for_release`
   6	fails closed via `fail_if_unresolved_required`. The net-wealth sign is derived from
   7	the canonical component (`net_sign`), never carried as a separate, contradictable
   8	field.
   9	"""
  10	
  11	import math
  12	from collections.abc import Sequence
  13	from dataclasses import dataclass
  14	from enum import Enum
  15	from typing import Literal
  16	
  17	from soep_preparation.wealth_imputation.components import (
  18	    CanonicalComponent,
  19	    component_sign,
  20	)
  21	
  22	
  23	class VerificationStatus(Enum):
  24	    """Whether a registry entry's variable mapping has been confirmed."""
  25	
  26	    VERIFIED = "verified"
  27	    INFERRED = "inferred"
  28	    UNRESOLVED = "unresolved"
  29	
  30	
  31	class AggregationRule(Enum):
  32	    """How a raw item's person values combine into the household total."""
  33	
  34	    PERSON_SHARE_THEN_PLAIN_SUM = "person_share_then_plain_sum"
  35	    """Per-person = joint amount times ownership share; household = plain sum."""
  36	    PERSON_DIRECT_PLAIN_SUM = "person_direct_plain_sum"
  37	    """Per-person amount is already person-specific; household = plain sum, no share."""
  38	    HOUSEHOLD_DIRECT = "household_direct"
  39	    """Item is asked at household level; no per-person share step."""
  40	
  41	
  42	@dataclass(frozen=True)
  43	class WealthVariable:
  44	    """One raw wealth item for one component in one wave."""
  45	
  46	    component: CanonicalComponent
  47	    """The canonical component this item contributes to."""
  48	    wave: int
  49	    """Survey year of the raw item."""
  50	    source_file: str
  51	    """Themed-file / raw-file name (a `RAW_DATA_FILES` catalog key)."""
  52	    raw_variable: str
  53	    """Raw column name in `source_file`."""
  54	    concept: str
  55	    """Questionnaire concept in plain language."""
  56	    unit: str
  57	    """Measurement unit, e.g. `"euro"` or `"share"`."""
  58	    universe: str
  59	    """Population the item applies to (filter)."""
  60	    missing_codes: tuple[int, ...]
  61	    """Negative SOEP codes treated as missing for this item."""
  62	    bracket_variable: str | None
  63	    """Range follow-up variable for `don't know`, if any."""
  64	    ownership_flag: str | None
  65	    """Ownership yes/no filter variable, if any."""
  66	    ownership_share_variable: str | None
  67	    """Per-person ownership-share variable, if any."""
  68	    level: Literal["person", "household"]
  69	    """Whether the raw item is asked of persons or households."""
  70	    aggregation_rule: AggregationRule
  71	    """How person items combine to the household."""
  72	    expected_min: float | None
  73	    """Plausible lower bound for range checks, if known."""
  74	    expected_max: float | None
  75	    """Plausible upper bound for range checks, if known."""
  76	    verification_status: VerificationStatus
  77	    """Whether the mapping is verified, inferred, or unresolved."""
  78	    verification_evidence: str
  79	    """Citation/evidence for the mapping."""
  80	    codebook_version: str
  81	    """SOEP version the evidence is drawn from."""
  82	    required_for_release: bool
  83	    """Whether the advertised full total depends on this entry."""
  84	
  85	    def __post_init__(self) -> None:
  86	        """Validate internal consistency; fail closed on contradictions."""
  87	        for name, bound in (
  88	            ("expected_min", self.expected_min),
  89	            ("expected_max", self.expected_max),
  90	        ):
  91	            if bound is not None and not math.isfinite(bound):
  92	                msg = f"{name} must be finite, got {bound}."
  93	                raise ValueError(msg)
  94	        if (
  95	            self.expected_min is not None
  96	            and self.expected_max is not None
  97	            and self.expected_min > self.expected_max
  98	        ):
  99	            msg = (
 100	                f"expected_min ({self.expected_min}) exceeds expected_max "
 101	                f"({self.expected_max}) for {self.raw_variable}."
 102	            )
 103	            raise ValueError(msg)
 104	        if (
 105	            self.verification_status is VerificationStatus.VERIFIED
 106	            and not self.verification_evidence.strip()
 107	        ):
 108	            msg = f"VERIFIED entry {self.raw_variable} requires non-empty evidence."
 109	            raise ValueError(msg)
 110	        self._fail_if_aggregation_rule_inconsistent()
 111	
 112	    def _fail_if_aggregation_rule_inconsistent(self) -> None:
 113	        has_share = self.ownership_share_variable is not None
 114	        if self.aggregation_rule is AggregationRule.HOUSEHOLD_DIRECT:
 115	            if self.level != "household":
 116	                msg = "HOUSEHOLD_DIRECT requires level='household'."
 117	                raise ValueError(msg)
 118	            if has_share:
 119	                msg = "HOUSEHOLD_DIRECT must not set an ownership_share_variable."
 120	                raise ValueError(msg)
 121	        elif self.aggregation_rule is AggregationRule.PERSON_SHARE_THEN_PLAIN_SUM:
 122	            if self.level != "person":
 123	                msg = "PERSON_SHARE_THEN_PLAIN_SUM requires level='person'."
 124	                raise ValueError(msg)
 125	            if not has_share:
 126	                msg = (
 127	                    "PERSON_SHARE_THEN_PLAIN_SUM requires an ownership_share_variable."
 128	                )
 129	                raise ValueError(msg)
 130	        elif self.aggregation_rule is AggregationRule.PERSON_DIRECT_PLAIN_SUM:
 131	            if self.level != "person":
 132	                msg = "PERSON_DIRECT_PLAIN_SUM requires level='person'."
 133	                raise ValueError(msg)
 134	            if has_share:
 135	                msg = (
 136	                    "PERSON_DIRECT_PLAIN_SUM must not set an ownership_share_variable."
 137	                )
 138	                raise ValueError(msg)
 139	
 140	    @property
 141	    def net_sign(self) -> int:
 142	        """Net-wealth sign for this component (+1 asset, -1 liability)."""
 143	        return component_sign(self.component)
 144	
 145	
 146	def fail_if_unresolved_required(entries: Sequence[WealthVariable]) -> None:
 147	    """Raise if any release-critical entry is unresolved.
 148	
 149	    Args:
 150	        entries: Registry entries to check.
 151	
 152	    Raises:
 153	        ValueError: If a `required_for_release` entry is `UNRESOLVED`.
 154	    """
 155	    offenders = [
 156	        f"{entry.component.value}/{entry.wave}/{entry.raw_variable}"
 157	        for entry in entries
 158	        if entry.required_for_release
 159	        and entry.verification_status is VerificationStatus.UNRESOLVED
 160	    ]
 161	    if offenders:
 162	        joined = "\n".join(offenders)
 163	        msg = (
 164	            "Release-critical registry entries are unresolved:\n"
 165	            f"{joined}\n"
 166	            "Resolve them against the codebook (Milestone 0) before release."
 167	        )
 168	        raise ValueError(msg)
```


### wealth_imputation/registry_content.py

```py
   1	"""Registry entries for the SOEP wealth battery, one per component and survey wave.
   2	
   3	The variable names are the DIW generated-wealth columns confirmed present in the
   4	SOEP-Core V41 `pwealth` file by the Milestone-0 probe. SOEP-Core ships a *reduced*
   5	wealth file: it carries the headline per-component imputed values and the overall
   6	totals, but not the full DIW research breakdown documented in SOEP Survey Paper 272
   7	(Grabka & Westermeier 2015). Each value column carries five implicate suffixes
   8	`a`-`e`; the registry uses the `a` implicate as the probe representative of the
   9	family.
  10	
  11	Five components are available directly and identically across every wave:
  12	
  13	- owner-occupied property, gross (`p0100`)
  14	- financial assets (`f0100`)
  15	- private insurances (`h0100`)
  16	- vehicles (`v0100`)
  17	- consumer debt (`c0100`)
  18	
  19	Three canonical components are not separately sourceable from the SOEP-Core file and
  20	are recorded as UNRESOLVED with evidence:
  21	
  22	- owner-occupied mortgage: no separate debt column; derive as `p0100` - `p0110`.
  23	- other real estate (`e0100`) and business assets (`b0100`): absent; subsumed in the
  24	  overall totals `w0101`/`w0111`, separable only from the DIW full wealth file.
  25	
  26	Verification status per `(component, wave)`:
  27	
  28	- Available components, pre-2022: VERIFIED against the live V41 columns (probe).
  29	- Available components, 2022: UNRESOLVED and release-critical -- DIW has not released
  30	  the generated 2022 wealth module, so the harness must predict it.
  31	  `fail_if_unresolved_required` blocks release until Milestone 0 resolves these.
  32	- Unavailable components: UNRESOLVED in every wave, but not release-critical (the
  33	  net-wealth target reads the overall totals directly).
  34	"""
  35	
  36	from dataclasses import dataclass
  37	
  38	from soep_preparation.wealth_imputation.components import CanonicalComponent
  39	from soep_preparation.wealth_imputation.registry import (
  40	    AggregationRule,
  41	    VerificationStatus,
  42	    WealthVariable,
  43	)
  44	
  45	# `RAW_DATA_FILES` catalog key of the individual-level wealth file.
  46	_SOURCE_FILE = "pwealth"
  47	
  48	# Wave whose generated wealth module DIW has not released; the harness predicts it.
  49	_PREDICTION_WAVE = 2022
  50	
  51	# SOEP wealth-module waves (a five-year cycle).
  52	_WAVES: tuple[int, ...] = (2002, 2007, 2012, 2017, _PREDICTION_WAVE)
  53	
  54	_EV_PROBE = (
  55	    "Confirmed present in SOEP-Core V41 pwealth.dta by the Milestone-0 probe "
  56	    "(observed_columns)."
  57	)
  58	_EV_2022 = (
  59	    "DIW has not released the generated 2022 wealth module; the 2022 values cannot "
  60	    "be confirmed and the harness must predict this component. Resolve at Milestone "
  61	    "0 / on DIW release."
  62	)
  63	_EV_ABSENT_MORTGAGE = (
  64	    "No separate mortgage-debt column in SOEP-Core V41 pwealth.dta (Milestone-0 "
  65	    "probe). Owner-occupied NET value p0110 is available directly, so the net-wealth "
  66	    "target does not require sourcing mortgage independently (mortgage = p0100 - "
  67	    "p0110)."
  68	)
  69	_EV_ABSENT_FOLDED = (
  70	    "Absent in SOEP-Core V41 pwealth.dta (Milestone-0 probe): the reduced SOEP-Core "
  71	    "wealth file carries only headline components and overall totals. This component "
  72	    "is subsumed in the overall totals w0101/w0111 and would require the DIW full "
  73	    "wealth research file to separate."
  74	)
  75	
  76	_SHARE = AggregationRule.PERSON_SHARE_THEN_PLAIN_SUM
  77	_DIRECT = AggregationRule.PERSON_DIRECT_PLAIN_SUM
  78	
  79	
  80	@dataclass(frozen=True)
  81	class _ComponentSpec:
  82	    """Wave-invariant attributes of one wealth component at the individual level."""
  83	
  84	    component: CanonicalComponent
  85	    """Canonical component this item contributes to."""
  86	    concept: str
  87	    """Questionnaire concept in plain language."""
  88	    universe: str
  89	    """Population the item applies to (the filter)."""
  90	    raw_variable: str
  91	    """Implicate-`a` value column (the expected name even when absent)."""
  92	    ownership_flag: str
  93	    """Ownership filter variable in the DIW research file."""
  94	    ownership_share_variable: str | None
  95	    """Per-person ownership-share variable, or `None` for person-direct items."""
  96	    aggregation_rule: AggregationRule
  97	    """How person values combine into the household total."""
  98	    missing_codes: tuple[int, ...]
  99	    """Negative SOEP codes treated as missing for this item."""
 100	    available_in_v41: bool
 101	    """Whether the value column is present in the SOEP-Core V41 `pwealth` file."""
 102	    absent_evidence: str = ""
 103	    """Evidence explaining the gap when `available_in_v41` is `False`."""
 104	    note: str = ""
 105	    """Extra evidence note appended to every entry for this component."""
 106	
 107	
 108	_COMPONENT_SPECS: tuple[_ComponentSpec, ...] = (
 109	    _ComponentSpec(
 110	        component=CanonicalComponent.OWNER_OCCUPIED_PROPERTY_GROSS,
 111	        concept="Gross market value of owner-occupied primary residence "
 112	        "(DIW-imputed, implicates a-e).",
 113	        universe="Persons owning a share of their primary residence.",
 114	        raw_variable="p0100a",
 115	        ownership_flag="p10000",
 116	        ownership_share_variable="p00010",
 117	        aggregation_rule=_SHARE,
 118	        missing_codes=(),
 119	        available_in_v41=True,
 120	    ),
 121	    _ComponentSpec(
 122	        component=CanonicalComponent.OWNER_OCCUPIED_MORTGAGE,
 123	        concept="Outstanding mortgage debt on the owner-occupied primary residence "
 124	        "(derived as gross minus net market value).",
 125	        universe="Persons with mortgage debt on their primary residence.",
 126	        raw_variable="p0010a",
 127	        ownership_flag="p10000",
 128	        ownership_share_variable="p00010",
 129	        aggregation_rule=_SHARE,
 130	        missing_codes=(),
 131	        available_in_v41=False,
 132	        absent_evidence=_EV_ABSENT_MORTGAGE,
 133	    ),
 134	    _ComponentSpec(
 135	        component=CanonicalComponent.OTHER_REAL_ESTATE,
 136	        concept="Gross market value of other real estate "
 137	        "(DIW-imputed, implicates a-e).",
 138	        universe="Persons owning a share of other real estate.",
 139	        raw_variable="e0100a",
 140	        ownership_flag="e10000",
 141	        ownership_share_variable="e00010",
 142	        aggregation_rule=_SHARE,
 143	        missing_codes=(),
 144	        available_in_v41=False,
 145	        absent_evidence=_EV_ABSENT_FOLDED,
 146	    ),
 147	    _ComponentSpec(
 148	        component=CanonicalComponent.FINANCIAL_ASSETS,
 149	        concept="Market value of financial assets (DIW-imputed, implicates a-e).",
 150	        universe="Persons holding a share of financial assets.",
 151	        raw_variable="f0100a",
 152	        ownership_flag="f10000",
 153	        ownership_share_variable="f00010",
 154	        aggregation_rule=_SHARE,
 155	        missing_codes=(),
 156	        available_in_v41=True,
 157	    ),
 158	    _ComponentSpec(
 159	        component=CanonicalComponent.PRIVATE_PENSION,
 160	        concept="Market value of private insurances and building-loan contracts "
 161	        "(DIW-imputed, implicates a-e).",
 162	        universe="Persons holding private insurances or building-loan contracts.",
 163	        raw_variable="h0100a",
 164	        ownership_flag="h10000",
 165	        ownership_share_variable=None,
 166	        aggregation_rule=_DIRECT,
 167	        missing_codes=(),
 168	        available_in_v41=True,
 169	        note="The reduced SOEP-Core file carries private insurances as `h0100` in "
 170	        "every wave; SP272's i0100/h0100/l0100 split applies to the full research "
 171	        "file only.",
 172	    ),
 173	    _ComponentSpec(
 174	        component=CanonicalComponent.BUSINESS_ASSETS,
 175	        concept="Market value of business assets (DIW-imputed, implicates a-e).",
 176	        universe="Persons owning business assets.",
 177	        raw_variable="b0100a",
 178	        ownership_flag="b10000",
 179	        ownership_share_variable=None,
 180	        aggregation_rule=_DIRECT,
 181	        missing_codes=(),
 182	        available_in_v41=False,
 183	        absent_evidence=_EV_ABSENT_FOLDED,
 184	    ),
 185	    _ComponentSpec(
 186	        component=CanonicalComponent.VEHICLES,
 187	        concept="Market value of vehicles / tangible assets "
 188	        "(DIW-imputed, implicates a-e).",
 189	        universe="Persons owning vehicles or other tangible assets.",
 190	        raw_variable="v0100a",
 191	        ownership_flag="v10000",
 192	        ownership_share_variable=None,
 193	        aggregation_rule=_DIRECT,
 194	        missing_codes=(-8,),
 195	        available_in_v41=True,
 196	        note="SOEP V41 uses `v0100`; SP272 lists this under the historical "
 197	        "tangible-assets name `t0100`.",
 198	    ),
 199	    _ComponentSpec(
 200	        component=CanonicalComponent.CONSUMER_DEBT,
 201	        concept="Outstanding consumer credit / debt (DIW-imputed, implicates a-e).",
 202	        universe="Persons with consumer credit or debt.",
 203	        raw_variable="c0100a",
 204	        ownership_flag="c10000",
 205	        ownership_share_variable=None,
 206	        aggregation_rule=_DIRECT,
 207	        missing_codes=(),
 208	        available_in_v41=True,
 209	    ),
 210	)
 211	
 212	
 213	def _verification(
 214	    spec: _ComponentSpec, wave: int
 215	) -> tuple[VerificationStatus, str, str]:
 216	    """Return the (status, evidence, codebook_version) for one `(component, wave)`."""
 217	    extra = f" {spec.note}" if spec.note else ""
 218	    if not spec.available_in_v41:
 219	        return (
 220	            VerificationStatus.UNRESOLVED,
 221	            spec.absent_evidence + extra,
 222	            "SOEP-Core v41 (absent)",
 223	        )
 224	    if wave == _PREDICTION_WAVE:
 225	        return (
 226	            VerificationStatus.UNRESOLVED,
 227	            _EV_2022 + extra,
 228	            "SOEP-Core v41 (2022 wealth module unreleased)",
 229	        )
 230	    return VerificationStatus.VERIFIED, _EV_PROBE + extra, "SOEP-Core v41"
 231	
 232	
 233	def _build_entry(spec: _ComponentSpec, wave: int) -> WealthVariable:
 234	    status, evidence, codebook_version = _verification(spec, wave)
 235	    return WealthVariable(
 236	        component=spec.component,
 237	        wave=wave,
 238	        source_file=_SOURCE_FILE,
 239	        raw_variable=spec.raw_variable,
 240	        concept=spec.concept,
 241	        unit="euro",
 242	        universe=spec.universe,
 243	        missing_codes=spec.missing_codes,
 244	        bracket_variable=None,
 245	        ownership_flag=spec.ownership_flag,
 246	        ownership_share_variable=spec.ownership_share_variable,
 247	        level="person",
 248	        aggregation_rule=spec.aggregation_rule,
 249	        expected_min=None,
 250	        expected_max=None,
 251	        verification_status=status,
 252	        verification_evidence=evidence,
 253	        codebook_version=codebook_version,
 254	        required_for_release=spec.available_in_v41,
 255	    )
 256	
 257	
 258	REGISTRY_ENTRIES: tuple[WealthVariable, ...] = tuple(
 259	    _build_entry(spec, wave) for spec in _COMPONENT_SPECS for wave in _WAVES
 260	)
```


### wealth_imputation/residual_model.py

```py
   1	"""Residual model: a two-part allocator for the unmodelled-components residual.
   2	
   3	The five SOEP-Core wealth components leave a residual to the official household total --
   4	chiefly business assets and other real estate, which appear only inside the total and
   5	are highly concentrated (most households hold none). A single linear fit smears that
   6	mass across every household, inflating the middle of the distribution and manufacturing
   7	spurious negatives. Instead, model it like a wealth component: a logistic incidence
   8	model for *whether* a household holds unmodelled wealth (a positive residual), times an
   9	asinh-scaled amount model for *how much*. The expected residual `P(owns) * amount` is
  10	clipped at zero, so the allocation stays non-negative and concentrated where the
  11	covariates predict it.
  12	"""
  13	
  14	from dataclasses import dataclass
  15	
  16	import numpy as np
  17	
  18	from soep_preparation.wealth_imputation.amount_model import AmountModel
  19	from soep_preparation.wealth_imputation.ownership_model import OwnershipModel
  20	
  21	
  22	def _fail_if_features_invalid(features: np.ndarray) -> None:
  23	    if features.ndim != 2:  # noqa: PLR2004 -- a design matrix is 2-D by definition
  24	        msg = f"features must be a 2-D design matrix, got {features.ndim}-D."
  25	        raise ValueError(msg)
  26	    if not np.all(np.isfinite(features)):
  27	        msg = "features must be finite (no NaN/inf)."
  28	        raise ValueError(msg)
  29	
  30	
  31	def _fail_if_training_data_invalid(features: np.ndarray, residual: np.ndarray) -> None:
  32	    _fail_if_features_invalid(features)
  33	    if residual.ndim != 1:
  34	        msg = f"residual must be 1-D, got {residual.ndim}-D."
  35	        raise ValueError(msg)
  36	    if features.shape[0] != residual.shape[0]:
  37	        msg = (
  38	            "features and residual must have the same number of rows, got "
  39	            f"{features.shape[0]} and {residual.shape[0]}."
  40	        )
  41	        raise ValueError(msg)
  42	    if not np.all(np.isfinite(residual)):
  43	        msg = "residual must be finite (no NaN/inf)."
  44	        raise ValueError(msg)
  45	
  46	
  47	@dataclass(frozen=True)
  48	class ResidualModel:
  49	    """A fitted two-part model of the signed unmodelled-components residual."""
  50	
  51	    ownership: OwnershipModel
  52	    """Logistic model for `P(residual > 0)` -- holding any unmodelled wealth."""
  53	    amount: AmountModel
  54	    """Asinh-scaled amount model fitted on the positive residuals only."""
  55	
  56	    @classmethod
  57	    def fit(
  58	        cls, features: np.ndarray, residual: np.ndarray, *, seed: int
  59	    ) -> ResidualModel:
  60	        """Fit the incidence and amount parts on the signed training residual.
  61	
  62	        A household with a positive residual is treated as holding unmodelled wealth;
  63	        the amount part is fitted on those positive residuals only. Non-positive
  64	        residuals (fit noise, where modelled wealth meets or exceeds the total) inform
  65	        the incidence part as non-owners but do not enter the amount fit.
  66	
  67	        Args:
  68	            features: Design matrix, shape `(n_rows, n_features)`, all finite.
  69	            residual: Signed euro residual per row (`official - modelled`), all finite,
  70	                with both positive and non-positive values present.
  71	            seed: Random seed for the incidence model's solver.
  72	
  73	        Returns:
  74	            A fitted `ResidualModel`.
  75	
  76	        Raises:
  77	            ValueError: On invalid shapes / lengths / non-finite inputs, or a residual
  78	                without both owners and non-owners.
  79	        """
  80	        _fail_if_training_data_invalid(features, residual)
  81	        owns = residual > 0.0
  82	        ownership = OwnershipModel.fit(features, owns.astype("int64"), seed=seed)
  83	        positive = residual[owns]
  84	        scale = float(np.median(positive)) if positive.size else 1.0
  85	        amount = AmountModel.fit(features[owns], positive, scale=scale)
  86	        return cls(ownership=ownership, amount=amount)
  87	
  88	    def predict(self, features: np.ndarray) -> np.ndarray:
  89	        """Return the expected non-negative residual `P(owns) * amount` per row.
  90	
  91	        Args:
  92	            features: Design matrix with the same column layout used in `fit`.
  93	
  94	        Returns:
  95	            Expected signed euro residuals clipped at zero, shape `(n_rows,)`.
  96	
  97	        Raises:
  98	            ValueError: On a non-2-D design matrix or non-finite features.
  99	        """
 100	        _fail_if_features_invalid(features)
 101	        expected = self.ownership.probability(features) * self.amount.predict(features)
 102	        return np.clip(expected, 0.0, None).astype("float64")
```


### wealth_imputation/shares.py

```py
   1	"""Convert jointly-held asset totals to per-person amounts via ownership shares.
   2	
   3	Applied exactly once, when building the person-level panel from raw answers. The
   4	resulting `person_component_value` is final and share-resolved, so household
   5	aggregation downstream is a plain sum (never a second share multiply). Both operands
   6	are promoted to `float64` *before* the multiplication, so a lower-precision input dtype
   7	cannot silently lose precision.
   8	"""
   9	
  10	import numpy as np
  11	import pandas as pd
  12	
  13	
  14	def _fail_if_share_values_invalid(amount: pd.Series, share: pd.Series) -> None:
  15	    observed_share = share.to_numpy()
  16	    observed_share = observed_share[~np.isnan(observed_share)]
  17	    if observed_share.size and not np.isfinite(observed_share).all():
  18	        msg = "ownership_share must be finite where observed."
  19	        raise ValueError(msg)
  20	    if observed_share.size and np.any((observed_share < 0) | (observed_share > 1)):
  21	        msg = "observed ownership_share must lie in [0, 1]."
  22	        raise ValueError(msg)
  23	    observed_amount = amount.to_numpy()
  24	    observed_amount = observed_amount[~np.isnan(observed_amount)]
  25	    if observed_amount.size and not np.isfinite(observed_amount).all():
  26	        msg = "joint_amount must be finite where observed."
  27	        raise ValueError(msg)
  28	
  29	
  30	def resolve_person_amount(
  31	    joint_amount: pd.Series, ownership_share: pd.Series
  32	) -> pd.Series:
  33	    """Return the person's share of a jointly-held asset value.
  34	
  35	    Args:
  36	        joint_amount: Total value of the asset, same index as `ownership_share`;
  37	            finite where observed.
  38	        ownership_share: The person's ownership share in `[0, 1]` where observed;
  39	            NA if unknown.
  40	
  41	    Returns:
  42	        `joint_amount * ownership_share` computed in float64, with NA propagated where
  43	        either input is NA.
  44	
  45	    Raises:
  46	        ValueError: On a mismatched index, a non-numeric or non-finite observed value,
  47	            or an observed share outside `[0, 1]`.
  48	    """
  49	    if not joint_amount.index.equals(ownership_share.index):
  50	        msg = "joint_amount and ownership_share must share an identical index."
  51	        raise ValueError(msg)
  52	    amount = pd.to_numeric(joint_amount, errors="raise").astype("float64")
  53	    share = pd.to_numeric(ownership_share, errors="raise").astype("float64")
  54	    _fail_if_share_values_invalid(amount, share)
  55	    return amount * share
```


### wealth_imputation/simulate.py

```py
   1	"""Joint-draw simulation of household wealth totals with intervals.
   2	
   3	Each draw runs every component's sequential `draw_component`, sums the signed
   4	person-component values to a household net total, and the spread of those totals
   5	across draws becomes the interval. Because each draw aggregates a *complete* joint
   6	draw before the spread is taken, cross-component dependence is preserved -- component
   7	interval endpoints are never summed. One shared RNG threads all draws so a fixed seed
   8	reproduces the whole simulation.
   9	"""
  10	
  11	from collections.abc import Sequence
  12	from dataclasses import dataclass
  13	
  14	import numpy as np
  15	import pandas as pd
  16	
  17	from soep_preparation.wealth_imputation.aggregate import household_net_total
  18	from soep_preparation.wealth_imputation.components import CanonicalComponent
  19	from soep_preparation.wealth_imputation.intervals import household_total_intervals
  20	from soep_preparation.wealth_imputation.value_generator import draw_component
  21	
  22	_RECIPIENT_KEYS = ("p_id", "hh_id", "survey_year")
  23	
  24	
  25	@dataclass(frozen=True)
  26	class ComponentDrawConfig:
  27	    """Per-component inputs for one component's draw over the recipients."""
  28	
  29	    component: CanonicalComponent
  30	    """Canonical component drawn by this config."""
  31	    ownership_prob: np.ndarray
  32	    """Ownership incidence probability per recipient, in `[0, 1]`."""
  33	    ownership_share: np.ndarray
  34	    """Ownership share per recipient, in `[0, 1]` for owners."""
  35	    recipient_predicted: np.ndarray
  36	    """Predicted gross euro amount per recipient (PMM matching)."""
  37	    donor_predicted: np.ndarray
  38	    """Predicted gross euro amounts for donors."""
  39	    donor_observed: np.ndarray
  40	    """Observed gross euro amounts for donors."""
  41	    scale: float
  42	    """Positive, finite component scale for the asinh transform."""
  43	    k: int
  44	    """Number of nearest eligible donors to sample from (>= 1)."""
  45	
  46	
  47	def simulate_household_totals(
  48	    recipients: pd.DataFrame,
  49	    configs: Sequence[ComponentDrawConfig],
  50	    *,
  51	    n_draws: int,
  52	    rng: np.random.Generator,
  53	    level: float = 0.9,
  54	) -> pd.DataFrame:
  55	    """Simulate household net-wealth totals and summarise them as intervals.
  56	
  57	    Args:
  58	        recipients: Columns `p_id`, `hh_id`, `survey_year`; one row per recipient,
  59	            aligned to every config's per-recipient arrays.
  60	        configs: One `ComponentDrawConfig` per modelled component.
  61	        n_draws: Number of complete joint draws (>= 1).
  62	        rng: NumPy random generator threaded through all draws.
  63	        level: Central coverage of the reported interval.
  64	
  65	    Returns:
  66	        Columns `hh_id`, `survey_year`, `point_estimate`, `lower`, `upper` (float64).
  67	
  68	    Raises:
  69	        ValueError: On missing recipient keys, no configs, `n_draws < 1`, or a config
  70	            whose arrays do not align with the recipients.
  71	    """
  72	    _fail_if_simulation_inputs_invalid(recipients, configs, n_draws)
  73	    keys = recipients[list(_RECIPIENT_KEYS)]
  74	    draw_frames = []
  75	    for _ in range(n_draws):
  76	        component_rows = []
  77	        for config in configs:
  78	            drawn = draw_component(
  79	                ownership_prob=config.ownership_prob,
  80	                ownership_share=config.ownership_share,
  81	                recipient_predicted=config.recipient_predicted,
  82	                donor_predicted=config.donor_predicted,
  83	                donor_observed=config.donor_observed,
  84	                scale=config.scale,
  85	                k=config.k,
  86	                rng=rng,
  87	            )
  88	            component_rows.append(
  89	                keys[["hh_id", "survey_year"]].assign(
  90	                    component=config.component.value,
  91	                    household_component_value=drawn.person_value,
  92	                )
  93	            )
  94	        per_draw = pd.concat(component_rows, ignore_index=True)
  95	        totals = household_net_total(per_draw).rename(
  96	            columns={"net_total": "household_total_draw"}
  97	        )
  98	        draw_frames.append(totals)
  99	    all_draws = pd.concat(draw_frames, ignore_index=True)
 100	    return household_total_intervals(all_draws, level=level)
 101	
 102	
 103	def _fail_if_simulation_inputs_invalid(
 104	    recipients: pd.DataFrame,
 105	    configs: Sequence[ComponentDrawConfig],
 106	    n_draws: int,
 107	) -> None:
 108	    missing = [key for key in _RECIPIENT_KEYS if key not in recipients.columns]
 109	    if missing:
 110	        msg = f"recipients is missing required columns: {missing}"
 111	        raise ValueError(msg)
 112	    if not configs:
 113	        msg = "configs must contain at least one component."
 114	        raise ValueError(msg)
 115	    if n_draws < 1:
 116	        msg = f"n_draws must be >= 1, got {n_draws}."
 117	        raise ValueError(msg)
 118	    n_recipients = len(recipients)
 119	    for config in configs:
 120	        if config.ownership_prob.shape[0] != n_recipients:
 121	            msg = (
 122	                f"config for {config.component.value} has "
 123	                f"{config.ownership_prob.shape[0]} recipient entries, but there are "
 124	                f"{n_recipients} recipients."
 125	            )
 126	            raise ValueError(msg)
```


### wealth_imputation/task_impute.py

```py
   1	"""Imputation task: fit on the historical waves and write 2022 wealth intervals.
   2	
   3	Opt-in like the probe: defined only when `RUN_WEALTH_IMPUTATION` is set (env var
   4	`SOEP_WEALTH_IMPUTATION`, or `pixi run wealth`). It declares the cleaned `MODULES` it
   5	consumes as dependencies, so pytask runs the cleaning first, then composes the tested
   6	imputation pipeline and writes the 2022 household net-wealth intervals plus a
   7	disclosure-safe run summary to `bld/wealth_imputation/`.
   8	"""
   9	
  10	import json
  11	from pathlib import Path
  12	from typing import Annotated
  13	
  14	import pandas as pd
  15	from pytask import Product
  16	
  17	from soep_preparation.config import (
  18	    BLD,
  19	    MODULES,
  20	    RUN_WEALTH_IMPUTATION,
  21	    SRC,
  22	)
  23	from soep_preparation.wealth_imputation.impute import run_imputation
  24	
  25	# Cleaned modules the imputation consumes: household + person wealth and the covariates.
  26	_IMPUTE_MODULES = ("hwealth", "pwealth", "pequiv", "pgen", "ppathl", "hgen")
  27	
  28	# Run settings (kept explicit so a re-run is reproducible).
  29	_N_DRAWS = 200
  30	_SEED = 0
  31	_K = 10
  32	_LEVEL = 0.9
  33	
  34	_WEALTH_SRC = SRC / "wealth_imputation"
  35	_SOURCE_DEPENDENCIES: tuple[Path, ...] = (
  36	    _WEALTH_SRC / "impute.py",
  37	    _WEALTH_SRC / "training.py",
  38	    _WEALTH_SRC / "simulate.py",
  39	    _WEALTH_SRC / "features.py",
  40	    _WEALTH_SRC / "aggregate.py",
  41	    _WEALTH_SRC / "amounts.py",
  42	    _WEALTH_SRC / "donors.py",
  43	    _WEALTH_SRC / "intervals.py",
  44	    _WEALTH_SRC / "ownership_model.py",
  45	    _WEALTH_SRC / "amount_model.py",
  46	    _WEALTH_SRC / "residual_model.py",
  47	    _WEALTH_SRC / "transforms.py",
  48	    _WEALTH_SRC / "deflation.py",
  49	    _WEALTH_SRC / "market_indices.py",
  50	    _WEALTH_SRC / "components.py",
  51	)
  52	
  53	if RUN_WEALTH_IMPUTATION:
  54	    _MODULE_INPUTS = {name: MODULES[name] for name in _IMPUTE_MODULES}
  55	
  56	    def task_wealth_imputation_impute(
  57	        modules: Annotated[dict[str, pd.DataFrame], _MODULE_INPUTS],
  58	        source_dependencies: tuple[Path, ...] = _SOURCE_DEPENDENCIES,
  59	        intervals_path: Annotated[Path, Product] = BLD
  60	        / "wealth_imputation"
  61	        / "household_wealth_2022.arrow",
  62	        summary_path: Annotated[Path, Product] = BLD
  63	        / "wealth_imputation"
  64	        / "imputation_summary.json",
  65	    ) -> None:
  66	        """Run the provisional 2022 wealth imputation and write its outputs.
  67	
  68	        Args:
  69	            modules: Injected cleaned `MODULES` frames (declared dependencies).
  70	            source_dependencies: First-party modules whose edits re-run the task.
  71	            intervals_path: Output Feather file of per-household 2022 intervals.
  72	            summary_path: Output JSON of the disclosure-safe run summary.
  73	        """
  74	        result = run_imputation(
  75	            modules, n_draws=_N_DRAWS, seed=_SEED, k=_K, level=_LEVEL
  76	        )
  77	        intervals_path.parent.mkdir(parents=True, exist_ok=True)
  78	        result.intervals.reset_index(drop=True).to_feather(intervals_path)
  79	        summary_path.write_text(json.dumps(result.summary, indent=2), encoding="utf-8")
```


### wealth_imputation/task_probe.py

```py
   1	"""Milestone-0 probe task: write the disclosure-safe registry presence report.
   2	
   3	Opt-in: the task is defined only when `RUN_WEALTH_IMPUTATION` is set (env var
   4	`SOEP_WEALTH_IMPUTATION`, or the `pixi run wealth` task), so the default
   5	`pixi run pytask` collects nothing from the wealth-imputation subsystem. Every
   6	future wealth task module follows the same guard.
   7	"""
   8	
   9	import json
  10	from pathlib import Path
  11	from typing import Annotated
  12	
  13	import pandas as pd
  14	from pytask import Product
  15	
  16	from soep_preparation.config import (
  17	    BLD,
  18	    RAW_DATA_FILES,
  19	    RUN_WEALTH_IMPUTATION,
  20	    SRC,
  21	    get_raw_data_file_names,
  22	)
  23	from soep_preparation.wealth_imputation.probe import (
  24	    assemble_probe_report,
  25	    inventory_columns,
  26	)
  27	from soep_preparation.wealth_imputation.registry_content import REGISTRY_ENTRIES
  28	
  29	# Source files to inventory so columns are chosen against the real V41 names.
  30	# Covariates (ppathl, pgen, pequiv, pl, hgen, hl) plus hwealth, to confirm the
  31	# household insurance/consumer-debt columns (h010h/c010h) before cleaning them.
  32	_FEATURE_SOURCE_FILES = ("ppathl", "pgen", "pequiv", "pl", "hgen", "hl", "hwealth")
  33	
  34	# Raw-data files the probe reads: the registry source files plus the covariate files.
  35	_REGISTRY_SOURCE_FILES = tuple(
  36	    sorted({entry.source_file for entry in REGISTRY_ENTRIES})
  37	)
  38	_PROBED_FILES = tuple(sorted({*_REGISTRY_SOURCE_FILES, *_FEATURE_SOURCE_FILES}))
  39	
  40	# First-party source modules whose content determines the report. Declared as task
  41	# dependencies so editing any of them re-runs the probe without `--force`; third-party
  42	# imports are deliberately excluded.
  43	_WEALTH_SRC = SRC / "wealth_imputation"
  44	_SOURCE_DEPENDENCIES: tuple[Path, ...] = (
  45	    _WEALTH_SRC / "probe.py",
  46	    _WEALTH_SRC / "registry.py",
  47	    _WEALTH_SRC / "registry_content.py",
  48	    _WEALTH_SRC / "components.py",
  49	)
  50	
  51	if RUN_WEALTH_IMPUTATION:
  52	    # Declare each probed catalog entry as a dependency so pytask runs the
  53	    # convert_stata_to_pandas tasks first and injects the loaded frames; only files
  54	    # actually present in the V41 catalog are wired.
  55	    _CATALOG_FILES = set(get_raw_data_file_names())
  56	    _DATA_INPUTS = {
  57	        name: RAW_DATA_FILES[name] for name in _PROBED_FILES if name in _CATALOG_FILES
  58	    }
  59	
  60	    def task_wealth_imputation_probe(
  61	        data_inputs: Annotated[dict[str, pd.DataFrame], _DATA_INPUTS],
  62	        source_dependencies: tuple[Path, ...] = _SOURCE_DEPENDENCIES,
  63	        report_path: Annotated[Path, Product] = BLD
  64	        / "wealth_imputation"
  65	        / "milestone_0_probe.json",
  66	        feature_columns_path: Annotated[Path, Product] = BLD
  67	        / "wealth_imputation"
  68	        / "milestone_0_feature_columns.json",
  69	    ) -> None:
  70	        """Probe registry variables and inventory covariate columns; write JSON reports.
  71	
  72	        Reads only column names from each injected `RAW_DATA_FILES` frame and writes two
  73	        disclosure-safe reports (no row-level data): the registry presence report and a
  74	        column inventory of the feature-source files. `data_inputs` declares the catalog
  75	        dependencies so the raw-data conversions run first; `source_dependencies`
  76	        carries the first-party modules whose edits should re-run the probe.
  77	        """
  78	        registry_files = set(_REGISTRY_SOURCE_FILES)
  79	        available = {
  80	            name: frozenset(frame.columns)
  81	            for name, frame in data_inputs.items()
  82	            if name in registry_files
  83	        }
  84	        report = assemble_probe_report(REGISTRY_ENTRIES, available)
  85	        report_path.parent.mkdir(parents=True, exist_ok=True)
  86	        report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
  87	
  88	        feature_available = {
  89	            name: frozenset(frame.columns)
  90	            for name, frame in data_inputs.items()
  91	            if name in _FEATURE_SOURCE_FILES
  92	        }
  93	        feature_columns = inventory_columns(feature_available)
  94	        feature_columns_path.write_text(
  95	            json.dumps(feature_columns, indent=2), encoding="utf-8"
  96	        )
```


### wealth_imputation/task_wealth_dynamics.py

```py
   1	"""Dynamics task: per-wave wealth distribution and 5-year mobility, disclosure-safe.
   2	
   3	Opt-in like the imputation (`SOEP_WEALTH_IMPUTATION`, or `pixi run wealth`). It consumes
   4	the cleaned `hwealth` (official household totals for the wealth waves) and `ppathl` (the
   5	person-household roster), plus the imputed 2022 intervals produced by the imputation
   6	task, and writes a single JSON of aggregates -- per-wave distribution statistics and
   7	quintile transition matrices across the four 5-year horizons. No row-level value leaves
   8	the secure environment.
   9	
  10	The actual waves are ranked on `hh_net_overall_wealth_a` (SOEP `w011h`), the net overall
  11	wealth populated in every wealth wave. The vehicle/student-loan-augmented total
  12	(`n011h`) that the imputation targets exists only from 2017, so it cannot anchor a
  13	cross-wave comparison. The imputed 2022 leg is on that augmented concept; the difference
  14	(vehicles plus student loans) is negligible for quintile ranking and small for levels.
  15	"""
  16	
  17	import json
  18	from pathlib import Path
  19	from typing import Annotated
  20	
  21	import pandas as pd
  22	from pytask import Product
  23	
  24	from soep_preparation.config import (
  25	    BLD,
  26	    MODULES,
  27	    RUN_WEALTH_IMPUTATION,
  28	    SRC,
  29	)
  30	from soep_preparation.wealth_imputation.wealth_dynamics import build_dynamics_report
  31	
  32	# Actual wealth-module waves carried by `hwealth`; 2022 is appended from the imputation.
  33	_ACTUAL_WAVES = (2002, 2007, 2012, 2017)
  34	_IMPUTED_WAVE = 2022
  35	_WAVES = (*_ACTUAL_WAVES, _IMPUTED_WAVE)
  36	_N_GROUPS = 5
  37	_MIN_CELL = 30
  38	
  39	# Cross-wave-consistent net overall wealth, present in every wealth wave.
  40	_CROSS_WAVE_TOTAL_COLUMN = "hh_net_overall_wealth_a"
  41	
  42	_DYNAMICS_MODULES = ("hwealth", "ppathl")
  43	_WEALTH_SRC = SRC / "wealth_imputation"
  44	_SOURCE_DEPENDENCIES: tuple[Path, ...] = (
  45	    _WEALTH_SRC / "wealth_dynamics.py",
  46	    _WEALTH_SRC / "task_wealth_dynamics.py",
  47	)
  48	_IMPUTED_INTERVALS = BLD / "wealth_imputation" / "household_wealth_2022.arrow"
  49	
  50	
  51	def _assemble_household_wealth(
  52	    hwealth: pd.DataFrame, imputed: pd.DataFrame
  53	) -> pd.DataFrame:
  54	    """Stack official household net wealth (actual waves) and the imputed 2022 proxy."""
  55	    actual = (
  56	        hwealth.loc[
  57	            hwealth["survey_year"].isin(_ACTUAL_WAVES),
  58	            ["hh_id", "survey_year", _CROSS_WAVE_TOTAL_COLUMN],
  59	        ]
  60	        .rename(columns={_CROSS_WAVE_TOTAL_COLUMN: "net_wealth"})
  61	        .dropna(subset=["net_wealth"])
  62	    )
  63	    proxy = imputed[["hh_id", "survey_year", "point_estimate"]].rename(
  64	        columns={"point_estimate": "net_wealth"}
  65	    )
  66	    combined = pd.concat([actual, proxy], ignore_index=True)
  67	    combined["net_wealth"] = combined["net_wealth"].astype("float64")
  68	    return combined
  69	
  70	
  71	if RUN_WEALTH_IMPUTATION:
  72	    _MODULE_INPUTS = {name: MODULES[name] for name in _DYNAMICS_MODULES}
  73	
  74	    def task_wealth_imputation_dynamics(
  75	        modules: Annotated[dict[str, pd.DataFrame], _MODULE_INPUTS],
  76	        imputed_intervals: Path = _IMPUTED_INTERVALS,
  77	        source_dependencies: tuple[Path, ...] = _SOURCE_DEPENDENCIES,
  78	        report_path: Annotated[Path, Product] = BLD
  79	        / "wealth_imputation"
  80	        / "wealth_dynamics_report.json",
  81	    ) -> None:
  82	        """Write per-wave distribution and 5-year mobility aggregates.
  83	
  84	        Args:
  85	            modules: Injected cleaned `hwealth` and `ppathl` frames.
  86	            imputed_intervals: The imputation task's per-household 2022 intervals.
  87	            source_dependencies: First-party modules whose edits re-run the task.
  88	            report_path: Output JSON of the disclosure-safe dynamics report.
  89	        """
  90	        imputed = pd.read_feather(imputed_intervals)
  91	        household_wealth = _assemble_household_wealth(modules["hwealth"], imputed)
  92	        roster = modules["ppathl"][["p_id", "hh_id", "survey_year"]]
  93	        report = build_dynamics_report(
  94	            household_wealth,
  95	            roster,
  96	            waves=_WAVES,
  97	            n_groups=_N_GROUPS,
  98	            min_cell=_MIN_CELL,
  99	        )
 100	        report_path.parent.mkdir(parents=True, exist_ok=True)
 101	        report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
```


### wealth_imputation/training.py

```py
   1	"""Fit per-component wealth models and build their draw configs.
   2	
   3	For one component, training derives ownership from the observed amount (positive =
   4	owner), fits the ownership-incidence and asinh-scaled amount models on the historical
   5	waves, and packages predictions for the target-wave recipients plus the observed donor
   6	pool into a `ComponentDrawConfig` for `simulate.simulate_household_totals`. The
   7	component scale is the median positive amount, so the asinh knee tracks each
   8	component's magnitude. Pure functions over arrays; the I/O lives in the probe/impute
   9	tasks.
  10	"""
  11	
  12	from dataclasses import dataclass
  13	
  14	import numpy as np
  15	
  16	from soep_preparation.wealth_imputation.amount_model import AmountModel
  17	from soep_preparation.wealth_imputation.components import CanonicalComponent
  18	from soep_preparation.wealth_imputation.ownership_model import OwnershipModel
  19	from soep_preparation.wealth_imputation.simulate import ComponentDrawConfig
  20	
  21	
  22	@dataclass(frozen=True)
  23	class ComponentModels:
  24	    """The fitted ownership and amount models for one component, with its scale."""
  25	
  26	    ownership_model: OwnershipModel
  27	    """Incidence model predicting `P(owns)`."""
  28	    amount_model: AmountModel
  29	    """Amount model predicting euro amounts for owners."""
  30	    scale: float
  31	    """The asinh component scale used by the amount model."""
  32	
  33	
  34	def derive_ownership(values: np.ndarray) -> np.ndarray:
  35	    """Return 1 where the component amount is positive (owner), else 0.
  36	
  37	    Args:
  38	        values: Observed component amounts (positive magnitudes).
  39	
  40	    Returns:
  41	        Binary ownership outcome per row as an integer array.
  42	    """
  43	    return (np.asarray(values, dtype="float64") > 0.0).astype(int)
  44	
  45	
  46	def component_scale(values: np.ndarray) -> float:
  47	    """Return the median strictly-positive amount, or 1.0 if none are positive.
  48	
  49	    Args:
  50	        values: Observed component amounts.
  51	
  52	    Returns:
  53	        A positive, finite asinh scale for the component.
  54	    """
  55	    positive = np.asarray(values, dtype="float64")
  56	    positive = positive[positive > 0.0]
  57	    if positive.size == 0:
  58	        return 1.0
  59	    return float(np.median(positive))
  60	
  61	
  62	def fit_component_models(
  63	    features: np.ndarray, values: np.ndarray, *, seed: int
  64	) -> ComponentModels:
  65	    """Fit the ownership and amount models for one component.
  66	
  67	    Args:
  68	        features: Training design matrix, shape `(n_rows, n_features)`.
  69	        values: Observed component amounts per row (positive magnitudes).
  70	        seed: Random seed for the ownership model.
  71	
  72	    Returns:
  73	        The fitted `ComponentModels` (ownership model, amount model, scale).
  74	
  75	    Raises:
  76	        ValueError: If ownership has a single class, or model inputs are invalid.
  77	    """
  78	    scale = component_scale(values)
  79	    owns = derive_ownership(values)
  80	    ownership_model = OwnershipModel.fit(features, owns, seed=seed)
  81	    owner_mask = owns.astype(bool)
  82	    amount_model = AmountModel.fit(
  83	        features[owner_mask],
  84	        np.asarray(values, dtype="float64")[owner_mask],
  85	        scale=scale,
  86	    )
  87	    return ComponentModels(
  88	        ownership_model=ownership_model, amount_model=amount_model, scale=scale
  89	    )
  90	
  91	
  92	def build_component_config(  # noqa: PLR0913
  93	    component: CanonicalComponent,
  94	    models: ComponentModels,
  95	    recipient_features: np.ndarray,
  96	    recipient_shares: np.ndarray,
  97	    donor_features: np.ndarray,
  98	    donor_values: np.ndarray,
  99	    k: int,
 100	) -> ComponentDrawConfig:
 101	    """Predict for recipients and donors and assemble a `ComponentDrawConfig`.
 102	
 103	    Args:
 104	        component: The canonical component being configured.
 105	        models: The fitted models for this component.
 106	        recipient_features: Target-wave recipient design matrix.
 107	        recipient_shares: Ownership share per recipient, in `[0, 1]`.
 108	        donor_features: Donor design matrix (observed owners).
 109	        donor_values: Donor observed euro amounts.
 110	        k: Number of nearest eligible donors to sample from.
 111	
 112	    Returns:
 113	        A `ComponentDrawConfig` ready for `simulate_household_totals`.
 114	    """
 115	    return ComponentDrawConfig(
 116	        component=component,
 117	        ownership_prob=models.ownership_model.probability(recipient_features),
 118	        ownership_share=np.asarray(recipient_shares, dtype="float64"),
 119	        recipient_predicted=models.amount_model.predict(recipient_features),
 120	        donor_predicted=models.amount_model.predict(donor_features),
 121	        donor_observed=np.asarray(donor_values, dtype="float64"),
 122	        scale=models.scale,
 123	        k=k,
 124	    )
```


### wealth_imputation/transforms.py

```py
   1	"""Signed log-like transforms for monetary amounts.
   2	
   3	`asinh(y / s)` behaves like `log` for large `|y|` but is finite and smooth at
   4	zero and for negative values (net debt), so it suits wealth amounts that mix a
   5	zero mass with positive assets and negative net positions.
   6	"""
   7	
   8	import numpy as np
   9	import pandas as pd
  10	
  11	
  12	def _fail_if_scale_invalid(scale: float) -> None:
  13	    if not np.isfinite(scale) or scale <= 0:
  14	        msg = f"scale must be positive and finite, got {scale}"
  15	        raise ValueError(msg)
  16	
  17	
  18	def asinh_scaled(values: pd.Series, scale: float) -> pd.Series:
  19	    """Apply the scaled inverse-hyperbolic-sine transform `asinh(values / scale)`.
  20	
  21	    Args:
  22	        values: Monetary amounts (may be zero or negative).
  23	        scale: Positive, finite component scale `s` controlling the linear-to-log knee.
  24	
  25	    Returns:
  26	        The transformed series as float64, same index.
  27	    """
  28	    _fail_if_scale_invalid(scale)
  29	    numeric = values.to_numpy(dtype="float64", na_value=np.nan)
  30	    return pd.Series(np.arcsinh(numeric / scale), index=values.index)
  31	
  32	
  33	def inverse_asinh_scaled(transformed: pd.Series, scale: float) -> pd.Series:
  34	    """Invert `asinh_scaled`: `scale * sinh(transformed)`.
  35	
  36	    Args:
  37	        transformed: Values on the `asinh`-scaled axis.
  38	        scale: The same positive, finite scale used in the forward transform.
  39	
  40	    Returns:
  41	        The back-transformed monetary amounts as float64, same index.
  42	    """
  43	    _fail_if_scale_invalid(scale)
  44	    numeric = transformed.to_numpy(dtype="float64", na_value=np.nan)
  45	    return pd.Series(np.sinh(numeric) * scale, index=transformed.index)
```


### wealth_imputation/value_generator.py

```py
   1	"""Generate a per-component person value by chaining ownership, amount, and share.
   2	
   3	For one component, each recipient's draw runs in sequence: a Bernoulli ownership
   4	decision from its incidence probability, then -- for owners only -- a PMM amount draw
   5	(`amounts.draw_amounts`) and a single ownership-share resolution
   6	(`shares.resolve_person_amount`). Non-owners contribute a structural zero. Ownership is
   7	drawn before amounts so a fixed seed reproduces the whole chain, and passing 0/1
   8	probabilities makes the ownership step a deterministic filter.
   9	"""
  10	
  11	from dataclasses import dataclass
  12	
  13	import numpy as np
  14	import pandas as pd
  15	
  16	from soep_preparation.wealth_imputation.amounts import draw_amounts
  17	from soep_preparation.wealth_imputation.shares import resolve_person_amount
  18	
  19	
  20	@dataclass(frozen=True)
  21	class ComponentDraw:
  22	    """Outcome of one component's sequential draw over recipients."""
  23	
  24	    person_value: np.ndarray
  25	    """Final share-resolved person amount per recipient as float64."""
  26	    owns: np.ndarray
  27	    """Bernoulli ownership decision per recipient as bool."""
  28	    gross_amount: np.ndarray
  29	    """Drawn gross (joint) amount per recipient as float64; zero for non-owners."""
  30	
  31	
  32	def _fail_if_lengths_differ(
  33	    ownership_prob: np.ndarray,
  34	    ownership_share: np.ndarray,
  35	    recipient_predicted: np.ndarray,
  36	) -> None:
  37	    lengths = {
  38	        "ownership_prob": ownership_prob.shape[0],
  39	        "ownership_share": ownership_share.shape[0],
  40	        "recipient_predicted": recipient_predicted.shape[0],
  41	    }
  42	    if len(set(lengths.values())) > 1:
  43	        msg = f"recipient arrays must share one length, got {lengths}."
  44	        raise ValueError(msg)
  45	
  46	
  47	def _fail_if_probabilities_invalid(ownership_prob: np.ndarray) -> None:
  48	    if not np.all(np.isfinite(ownership_prob)):
  49	        msg = "ownership_prob must be finite (no NaN/inf)."
  50	        raise ValueError(msg)
  51	    if np.any((ownership_prob < 0.0) | (ownership_prob > 1.0)):
  52	        msg = "ownership_prob must lie in [0, 1]."
  53	        raise ValueError(msg)
  54	
  55	
  56	def draw_component(  # noqa: PLR0913
  57	    ownership_prob: np.ndarray,
  58	    ownership_share: np.ndarray,
  59	    recipient_predicted: np.ndarray,
  60	    donor_predicted: np.ndarray,
  61	    donor_observed: np.ndarray,
  62	    scale: float,
  63	    k: int,
  64	    rng: np.random.Generator,
  65	    caliper: float | None = None,
  66	) -> ComponentDraw:
  67	    """Draw one component's person value for every recipient.
  68	
  69	    Args:
  70	        ownership_prob: Ownership incidence probability per recipient, in `[0, 1]`.
  71	        ownership_share: Ownership share per recipient, in `[0, 1]` for owners.
  72	        recipient_predicted: Predicted gross euro amount per recipient (PMM matching).
  73	        donor_predicted: Predicted gross euro amounts for donors.
  74	        donor_observed: Observed gross euro amounts for donors.
  75	        scale: Positive, finite component scale for the asinh transform.
  76	        k: Number of nearest eligible donors to sample from (>= 1).
  77	        rng: NumPy random generator (ownership drawn first, then amounts).
  78	        caliper: Maximum donor distance on the asinh-scaled axis, if set.
  79	
  80	    Returns:
  81	        A `ComponentDraw` with the share-resolved `person_value`, the `owns`
  82	        decision, and the drawn `gross_amount`.
  83	
  84	    Raises:
  85	        ValueError: On mismatched recipient lengths, probabilities outside `[0, 1]`,
  86	            an invalid scale, or invalid PMM / share inputs.
  87	    """
  88	    _fail_if_lengths_differ(ownership_prob, ownership_share, recipient_predicted)
  89	    _fail_if_probabilities_invalid(ownership_prob)
  90	    n_recipients = ownership_prob.shape[0]
  91	    owns = rng.random(n_recipients) < ownership_prob
  92	    gross_amount = np.zeros(n_recipients, dtype="float64")
  93	    person_value = np.zeros(n_recipients, dtype="float64")
  94	    if owns.any():
  95	        drawn = draw_amounts(
  96	            recipient_predicted=recipient_predicted[owns],
  97	            donor_predicted=donor_predicted,
  98	            donor_observed=donor_observed,
  99	            scale=scale,
 100	            k=k,
 101	            rng=rng,
 102	            caliper=caliper,
 103	        )
 104	        gross_amount[owns] = drawn.values  # noqa: PD011 -- PmmResult attr, not pandas
 105	        owner_value = resolve_person_amount(
 106	            pd.Series(gross_amount[owns]), pd.Series(ownership_share[owns])
 107	        )
 108	        person_value[owns] = owner_value.to_numpy()
 109	    return ComponentDraw(
 110	        person_value=person_value, owns=owns, gross_amount=gross_amount
 111	    )
```


### wealth_imputation/wealth_dynamics.py

```py
   1	"""Disclosure-safe wealth distribution and 5-year mobility summaries.
   2	
   3	Turns household net wealth across the wealth waves (and the imputed 2022 proxy) into
   4	aggregates that can leave the secure environment: per-wave distribution statistics
   5	(quantiles, Gini, top shares) and quintile transition matrices across consecutive
   6	5-year horizons. No row-level value is ever returned -- transition cells below
   7	`min_cell` underlying observations are suppressed to `None`.
   8	
   9	The cross-sectional distribution is taken over households (one net-wealth value each).
  10	Mobility is taken over persons, each assigned their household's net wealth, because the
  11	person identifier `p_id` is stable across waves whereas `hh_id` splits and reforms;
  12	quintile ranks are defined on the full person cross-section of each wave, then movers
  13	present in both waves are cross-tabulated.
  14	
  15	Documented approximations: values are unweighted (SOEP design weights omitted); wealth
  16	is per household, not equivalised; the 2022 leg is the imputed point estimate, so any
  17	transition into 2022 is attenuated by imputation regression-to-the-mean. The Gini is
  18	the mean-absolute-difference form and can exceed 1 when negative net wealth is present.
  19	"""
  20	
  21	from collections.abc import Sequence
  22	from itertools import pairwise
  23	
  24	import numpy as np
  25	import pandas as pd
  26	
  27	_QUANTILE_PROBABILITIES = {
  28	    "p1": 0.01,
  29	    "p5": 0.05,
  30	    "p10": 0.10,
  31	    "p25": 0.25,
  32	    "p50": 0.50,
  33	    "p75": 0.75,
  34	    "p90": 0.90,
  35	    "p95": 0.95,
  36	    "p99": 0.99,
  37	}
  38	_TOP_DECILE = 0.10
  39	_TOP_PERCENTILE = 0.01
  40	
  41	
  42	def gini(values: np.ndarray) -> float:
  43	    """Return the Gini coefficient via the mean absolute difference.
  44	
  45	    Args:
  46	        values: Net-wealth values, at least one, all finite.
  47	
  48	    Returns:
  49	        `sum_ij |x_i - x_j| / (2 n^2 mean)`. With negative net wealth present this can
  50	        exceed 1; with a non-positive mean it is undefined and returned as `nan`.
  51	
  52	    Raises:
  53	        ValueError: On an empty or non-finite input.
  54	    """
  55	    array = _finite_1d(values, "values")
  56	    mean = float(array.mean())
  57	    if not np.isfinite(mean) or mean <= 0.0:
  58	        return float("nan")
  59	    # sum_ij |x_i - x_j| = 2 * sum_i (2i - n - 1) x_(i) for x sorted ascending, so the
  60	    # Gini is computed in O(n log n) without ever materialising the n-by-n difference
  61	    # matrix (which would exhaust memory at survey scale).
  62	    sorted_values = np.sort(array)
  63	    count = array.size
  64	    rank = np.arange(1, count + 1)
  65	    weighted_sum = float(np.sum((2 * rank - count - 1) * sorted_values))
  66	    return weighted_sum / (count**2 * mean)
  67	
  68	
  69	def top_share(values: np.ndarray, *, top_fraction: float) -> float:
  70	    """Return the share of the total held by the richest `top_fraction` of holders.
  71	
  72	    Args:
  73	        values: Net-wealth values, at least one, all finite.
  74	        top_fraction: Fraction in `(0, 1]` defining the top group; the group size is
  75	            rounded up to at least one holder.
  76	
  77	    Returns:
  78	        The top group's summed value over the grand total, or `nan` if the total is
  79	        non-positive.
  80	
  81	    Raises:
  82	        ValueError: On an empty/non-finite input or a `top_fraction` outside `(0, 1]`.
  83	    """
  84	    array = _finite_1d(values, "values")
  85	    if not (0.0 < top_fraction <= 1.0):
  86	        msg = f"top_fraction must lie in (0, 1], got {top_fraction}."
  87	        raise ValueError(msg)
  88	    total = float(array.sum())
  89	    if total <= 0.0:
  90	        return float("nan")
  91	    count = max(1, int(np.ceil(top_fraction * array.size)))
  92	    top = np.sort(array)[-count:]
  93	    return float(top.sum() / total)
  94	
  95	
  96	def quintile_ranks(values: pd.Series, *, n_groups: int = 5) -> pd.Series:
  97	    """Rank values into `n_groups` equal-count groups, labelled 1 (lowest) upward.
  98	
  99	    Ties at a quantile boundary are absorbed by dropping duplicate edges, so the number
 100	    of distinct ranks may be below `n_groups` on heavily-tied data.
 101	
 102	    Args:
 103	        values: Net-wealth values to rank.
 104	        n_groups: Number of equal-count groups.
 105	
 106	    Returns:
 107	        Integer ranks aligned to `values.index`.
 108	    """
 109	    ranked = pd.qcut(values.rank(method="first"), n_groups, labels=False)
 110	    return (ranked + 1).astype("int64")
 111	
 112	
 113	def transition_counts(
 114	    rank_from: pd.Series, rank_to: pd.Series, *, n_groups: int = 5
 115	) -> np.ndarray:
 116	    """Cross-tabulate origin against destination ranks into a count matrix.
 117	
 118	    Args:
 119	        rank_from: Origin-wave rank per mover, in `1..n_groups`.
 120	        rank_to: Destination-wave rank per mover, aligned to `rank_from`.
 121	        n_groups: Number of groups (matrix is `n_groups x n_groups`).
 122	
 123	    Returns:
 124	        A `(n_groups, n_groups)` float64 count matrix; row `i`, column `j` counts movers
 125	        from group `i+1` to group `j+1`.
 126	    """
 127	    counts = np.zeros((n_groups, n_groups), dtype="float64")
 128	    for origin, destination in zip(rank_from, rank_to, strict=True):
 129	        counts[int(origin) - 1, int(destination) - 1] += 1.0
 130	    return counts
 131	
 132	
 133	def transition_probabilities(counts: np.ndarray) -> np.ndarray:
 134	    """Row-normalise a count matrix into destination probabilities per origin group.
 135	
 136	    Args:
 137	        counts: A square count matrix.
 138	
 139	    Returns:
 140	        A matrix whose non-empty rows sum to 1; all-zero rows stay zero.
 141	    """
 142	    row_totals = counts.sum(axis=1, keepdims=True)
 143	    safe_totals = np.where(row_totals == 0.0, 1.0, row_totals)
 144	    return counts / safe_totals
 145	
 146	
 147	def wave_distribution_summary(values: np.ndarray) -> dict:
 148	    """Summarise one wave's net-wealth distribution into disclosure-safe scalars.
 149	
 150	    Args:
 151	        values: Household net-wealth values for the wave, all finite.
 152	
 153	    Returns:
 154	        A dict with the count, mean, a quantile grid, the Gini, the top-10% and top-1%
 155	        shares, and the shares with negative and with zero net wealth.
 156	
 157	    Raises:
 158	        ValueError: On an empty or non-finite input.
 159	    """
 160	    array = _finite_1d(values, "values")
 161	    quantiles = {
 162	        name: float(np.quantile(array, probability))
 163	        for name, probability in _QUANTILE_PROBABILITIES.items()
 164	    }
 165	    return {
 166	        "n": int(array.size),
 167	        "mean": float(array.mean()),
 168	        "quantiles": quantiles,
 169	        "gini": gini(array),
 170	        "top10_share": top_share(array, top_fraction=_TOP_DECILE),
 171	        "top1_share": top_share(array, top_fraction=_TOP_PERCENTILE),
 172	        "negative_share": float((array < 0.0).mean()),
 173	        "zero_share": float((array == 0.0).mean()),
 174	    }
 175	
 176	
 177	def build_dynamics_report(
 178	    household_wealth: pd.DataFrame,
 179	    roster: pd.DataFrame,
 180	    *,
 181	    waves: Sequence[int],
 182	    n_groups: int = 5,
 183	    min_cell: int = 30,
 184	) -> dict:
 185	    """Assemble the per-wave distribution and per-horizon mobility report.
 186	
 187	    Args:
 188	        household_wealth: Columns `hh_id`, `survey_year`, `net_wealth` covering every
 189	            wave in `waves`.
 190	        roster: Columns `p_id`, `hh_id`, `survey_year` linking persons to households.
 191	        waves: Waves in chronological order; consecutive pairs form the horizons.
 192	        n_groups: Number of mobility groups (5 for quintiles).
 193	        min_cell: Transition cells below this many movers are suppressed to `None`.
 194	
 195	    Returns:
 196	        A nested, disclosure-safe dict with `metadata`, `distribution` (per wave) and
 197	        `transitions` (per `"from->to"` horizon).
 198	    """
 199	    available = [
 200	        wave for wave in waves if bool((household_wealth["survey_year"] == wave).any())
 201	    ]
 202	    without_data = [wave for wave in waves if wave not in available]
 203	    distribution = {
 204	        str(wave): wave_distribution_summary(
 205	            household_wealth.loc[
 206	                household_wealth["survey_year"] == wave, "net_wealth"
 207	            ].to_numpy(dtype="float64")
 208	        )
 209	        for wave in available
 210	    }
 211	    person_rank = _person_quintile_ranks(
 212	        household_wealth, roster, waves=available, n_groups=n_groups
 213	    )
 214	    transitions = {
 215	        f"{wave_from}->{wave_to}": _horizon_transition(
 216	            person_rank,
 217	            wave_from=wave_from,
 218	            wave_to=wave_to,
 219	            n_groups=n_groups,
 220	            min_cell=min_cell,
 221	        )
 222	        for wave_from, wave_to in pairwise(waves)
 223	        if wave_from in available and wave_to in available
 224	    }
 225	    return {
 226	        "metadata": {
 227	            "wealth_concept": "household net overall wealth",
 228	            "unit_distribution": "household",
 229	            "unit_transitions": "person (assigned household net wealth)",
 230	            "weighted": False,
 231	            "n_groups": n_groups,
 232	            "min_cell": min_cell,
 233	            "waves": list(waves),
 234	            "waves_without_data": without_data,
 235	        },
 236	        "distribution": distribution,
 237	        "transitions": transitions,
 238	    }
 239	
 240	
 241	def _person_quintile_ranks(
 242	    household_wealth: pd.DataFrame,
 243	    roster: pd.DataFrame,
 244	    *,
 245	    waves: Sequence[int],
 246	    n_groups: int,
 247	) -> pd.DataFrame:
 248	    """Assign each person their household's net wealth and rank within each wave."""
 249	    person_wealth = roster.merge(
 250	        household_wealth, on=["hh_id", "survey_year"], how="inner"
 251	    )
 252	    person_wealth = person_wealth[person_wealth["survey_year"].isin(waves)]
 253	    ranked = []
 254	    for wave in waves:
 255	        wave_rows = person_wealth.loc[person_wealth["survey_year"] == wave].copy()
 256	        wave_rows["rank"] = quintile_ranks(wave_rows["net_wealth"], n_groups=n_groups)
 257	        ranked.append(wave_rows[["p_id", "survey_year", "rank"]])
 258	    return pd.concat(ranked, ignore_index=True)
 259	
 260	
 261	def _horizon_transition(
 262	    person_rank: pd.DataFrame,
 263	    *,
 264	    wave_from: int,
 265	    wave_to: int,
 266	    n_groups: int,
 267	    min_cell: int,
 268	) -> dict:
 269	    """Cross-tabulate ranks of persons present in both waves of one horizon."""
 270	    left = person_rank.loc[person_rank["survey_year"] == wave_from, ["p_id", "rank"]]
 271	    right = person_rank.loc[person_rank["survey_year"] == wave_to, ["p_id", "rank"]]
 272	    movers = left.merge(right, on="p_id", how="inner", suffixes=("_from", "_to"))
 273	    counts = transition_counts(
 274	        movers["rank_from"], movers["rank_to"], n_groups=n_groups
 275	    )
 276	    probabilities = transition_probabilities(counts)
 277	    suppressed = counts < min_cell
 278	    return {
 279	        "n_persons": int(counts.sum()),
 280	        "n_suppressed_cells": int(suppressed.sum()),
 281	        "counts": _mask_suppressed(counts, suppressed),
 282	        "probabilities": _mask_suppressed(probabilities, suppressed),
 283	    }
 284	
 285	
 286	def _mask_suppressed(matrix: np.ndarray, suppressed: np.ndarray) -> list:
 287	    """Return a nested list with suppressed cells replaced by `None`."""
 288	    return [
 289	        [
 290	            None if suppressed[i, j] else float(matrix[i, j])
 291	            for j in range(matrix.shape[1])
 292	        ]
 293	        for i in range(matrix.shape[0])
 294	    ]
 295	
 296	
 297	def _finite_1d(values: np.ndarray, name: str) -> np.ndarray:
 298	    array = np.asarray(values, dtype="float64")
 299	    if array.ndim != 1:
 300	        msg = f"{name} must be 1-D, got {array.ndim}-D."
 301	        raise ValueError(msg)
 302	    if array.size == 0:
 303	        msg = f"{name} must be non-empty."
 304	        raise ValueError(msg)
 305	    if not np.all(np.isfinite(array)):
 306	        msg = f"{name} must be finite (no NaN/inf)."
 307	        raise ValueError(msg)
 308	    return array
```


### wealth_imputation/__init__.py

```py

```


### wealth_imputation/test_aggregate.py

```py
   1	import math
   2	
   3	import numpy as np
   4	import pandas as pd
   5	import pytest
   6	
   7	from soep_preparation.wealth_imputation.aggregate import (
   8	    household_component_sum,
   9	    household_net_total,
  10	    punr_residual,
  11	    unmodelled_components_residual,
  12	)
  13	
  14	
  15	def test_household_net_total_sums_signed_components_per_household():
  16	    """Net total = assets minus liabilities, summed within household and year."""
  17	    component_values = pd.DataFrame(
  18	        {
  19	            "hh_id": [1, 1, 1],
  20	            "survey_year": [2017, 2017, 2017],
  21	            "component": [
  22	                "owner_occupied_property_gross",
  23	                "owner_occupied_mortgage",
  24	                "financial_assets",
  25	            ],
  26	            "household_component_value": [200000.0, 50000.0, 30000.0],
  27	        }
  28	    )
  29	    result = household_net_total(component_values)
  30	    # 200000 - 50000 + 30000 = 180000.
  31	    np.testing.assert_allclose(result["net_total"].to_numpy(), [180000.0], atol=1e-6)
  32	
  33	
  34	def test_household_net_total_sums_each_household_and_year_separately():
  35	    """Distinct households and years get independent net totals."""
  36	    component_values = pd.DataFrame(
  37	        {
  38	            "hh_id": [1, 2, 1],
  39	            "survey_year": [2017, 2017, 2012],
  40	            "component": ["financial_assets", "financial_assets", "consumer_debt"],
  41	            "household_component_value": [30000.0, 80000.0, 5000.0],
  42	        }
  43	    )
  44	    result = household_net_total(component_values)
  45	    keyed = {
  46	        (hh_id, year): net
  47	        for hh_id, year, net in zip(
  48	            result["hh_id"], result["survey_year"], result["net_total"], strict=True
  49	        )
  50	    }
  51	    assert keyed == {(1, 2017): 30000.0, (2, 2017): 80000.0, (1, 2012): -5000.0}
  52	
  53	
  54	def test_unmodelled_components_residual_subtracts_signed_components_from_total():
  55	    """Residual = official net total minus the signed sum of modelled components."""
  56	    component_values = pd.DataFrame(
  57	        {
  58	            "hh_id": [1, 1, 1, 1, 1],
  59	            "survey_year": [2017, 2017, 2017, 2017, 2017],
  60	            "component": [
  61	                "owner_occupied_property_gross",
  62	                "owner_occupied_mortgage",
  63	                "financial_assets",
  64	                "vehicles",
  65	                "consumer_debt",
  66	            ],
  67	            "household_component_value": [200000.0, 50000.0, 30000.0, 10000.0, 5000.0],
  68	        }
  69	    )
  70	    official_totals = pd.DataFrame(
  71	        {"hh_id": [1], "survey_year": [2017], "official_net_total": [195000.0]}
  72	    )
  73	    result = unmodelled_components_residual(component_values, official_totals)
  74	    # 200000 - 50000 + 30000 + 10000 - 5000 = 185000; 195000 - 185000 = 10000.
  75	    np.testing.assert_allclose(result["residual"].to_numpy(), [10000.0], atol=1e-6)
  76	
  77	
  78	def _component_values(hh_id: int, value: float) -> pd.DataFrame:
  79	    return pd.DataFrame(
  80	        {
  81	            "hh_id": [hh_id],
  82	            "survey_year": [2017],
  83	            "component": ["financial_assets"],
  84	            "household_component_value": [value],
  85	        }
  86	    )
  87	
  88	
  89	def test_unmodelled_components_residual_reconciles_each_household_independently():
  90	    """Each household's residual uses only its own components and total."""
  91	    component_values = pd.concat(
  92	        [_component_values(1, 30000.0), _component_values(2, 80000.0)],
  93	        ignore_index=True,
  94	    )
  95	    official_totals = pd.DataFrame(
  96	        {
  97	            "hh_id": [1, 2],
  98	            "survey_year": [2017, 2017],
  99	            "official_net_total": [50000.0, 100000.0],
 100	        }
 101	    )
 102	    result = unmodelled_components_residual(
 103	        component_values, official_totals
 104	    ).set_index("hh_id")
 105	    np.testing.assert_allclose(result.loc[1, "residual"], 20000.0, atol=1e-6)
 106	    np.testing.assert_allclose(result.loc[2, "residual"], 20000.0, atol=1e-6)
 107	
 108	
 109	def test_unmodelled_components_residual_raises_on_household_key_mismatch():
 110	    """A household present in only one table fails closed rather than misaligning."""
 111	    component_values = _component_values(1, 30000.0)
 112	    official_totals = pd.DataFrame(
 113	        {"hh_id": [2], "survey_year": [2017], "official_net_total": [50000.0]}
 114	    )
 115	    with pytest.raises(ValueError, match="identical"):
 116	        unmodelled_components_residual(component_values, official_totals)
 117	
 118	
 119	def test_unmodelled_components_residual_returns_float64():
 120	    """The residual column is float64 even when inputs are integer-typed."""
 121	    component_values = pd.DataFrame(
 122	        {
 123	            "hh_id": [1],
 124	            "survey_year": [2017],
 125	            "component": ["financial_assets"],
 126	            "household_component_value": pd.array([30000], dtype="int64"),
 127	        }
 128	    )
 129	    official_totals = pd.DataFrame(
 130	        {
 131	            "hh_id": [1],
 132	            "survey_year": [2017],
 133	            "official_net_total": pd.array([50000], dtype="int64"),
 134	        }
 135	    )
 136	    result = unmodelled_components_residual(component_values, official_totals)
 137	    assert result["residual"].dtype == np.float64
 138	
 139	
 140	def _panel() -> pd.DataFrame:
 141	    return pd.DataFrame(
 142	        {
 143	            "p_id": [1, 2, 3, 1],
 144	            "hh_id": [1, 1, 2, 1],
 145	            "survey_year": [2017, 2017, 2017, 2012],
 146	            "component": ["financial_assets"] * 4,
 147	            "person_component_value": [100.0, 50.0, 200.0, 70.0],
 148	        }
 149	    )
 150	
 151	
 152	def _totals(value: float, component: str = "financial_assets") -> pd.DataFrame:
 153	    return pd.DataFrame(
 154	        {
 155	            "hh_id": [1],
 156	            "survey_year": [2017],
 157	            "component": [component],
 158	            "household_total": [value],
 159	        }
 160	    )
 161	
 162	
 163	def _members(value: float, component: str = "financial_assets") -> pd.DataFrame:
 164	    return pd.DataFrame(
 165	        {
 166	            "hh_id": [1],
 167	            "survey_year": [2017],
 168	            "component": [component],
 169	            "member_sum": [value],
 170	        }
 171	    )
 172	
 173	
 174	def test_household_component_sum_groups_by_household_year_and_component() -> None:
 175	    out = household_component_sum(_panel())
 176	    keyed = {
 177	        (hh_id, survey_year, component): member_sum
 178	        for hh_id, survey_year, component, member_sum in zip(
 179	            out["hh_id"],
 180	            out["survey_year"],
 181	            out["component"],
 182	            out["member_sum"],
 183	            strict=True,
 184	        )
 185	    }
 186	    assert keyed == {
 187	        (1, 2017, "financial_assets"): 150.0,
 188	        (2, 2017, "financial_assets"): 200.0,
 189	        (1, 2012, "financial_assets"): 70.0,
 190	    }
 191	
 192	
 193	def test_household_component_sum_keeps_distinct_components_separate() -> None:
 194	    panel = pd.DataFrame(
 195	        {
 196	            "p_id": [1, 1],
 197	            "hh_id": [1, 1],
 198	            "survey_year": [2017, 2017],
 199	            "component": ["financial_assets", "consumer_debt"],
 200	            "person_component_value": [100.0, 30.0],
 201	        }
 202	    )
 203	    out = household_component_sum(panel)
 204	    by_component = dict(zip(out["component"], out["member_sum"], strict=True))
 205	    assert by_component == {"financial_assets": 100.0, "consumer_debt": 30.0}
 206	
 207	
 208	def test_household_component_sum_returns_float64_member_sum() -> None:
 209	    assert household_component_sum(_panel())["member_sum"].dtype == np.float64
 210	
 211	
 212	def test_household_component_sum_computes_in_float64_not_float32() -> None:
 213	    # In float32 this sum collapses to 0.0; float64 (before the sum) preserves 1.0.
 214	    panel = pd.DataFrame(
 215	        {
 216	            "p_id": [1, 2, 3],
 217	            "hh_id": [1, 1, 1],
 218	            "survey_year": [2017, 2017, 2017],
 219	            "component": ["financial_assets"] * 3,
 220	            "person_component_value": pd.Series([1e8, 1.0, -1e8], dtype="float32"),
 221	        }
 222	    )
 223	    out = household_component_sum(panel)
 224	    assert math.isclose(out["member_sum"].iloc[0], 1.0)
 225	
 226	
 227	def test_household_component_sum_sums_numeric_strings_not_concatenates() -> None:
 228	    panel = pd.DataFrame(
 229	        {
 230	            "p_id": [1, 2],
 231	            "hh_id": [1, 1],
 232	            "survey_year": [2017, 2017],
 233	            "component": ["financial_assets", "financial_assets"],
 234	            "person_component_value": ["100", "50"],
 235	        }
 236	    )
 237	    out = household_component_sum(panel)
 238	    assert math.isclose(out["member_sum"].iloc[0], 150.0)
 239	
 240	
 241	def test_household_component_sum_rejects_non_numeric_value() -> None:
 242	    panel = _panel()
 243	    panel["person_component_value"] = panel["person_component_value"].astype("object")
 244	    panel.loc[0, "person_component_value"] = "abc"
 245	    with pytest.raises(ValueError, match="Unable to parse"):
 246	        household_component_sum(panel)
 247	
 248	
 249	def test_household_component_sum_rejects_non_finite_value() -> None:
 250	    panel = _panel()
 251	    panel.loc[0, "person_component_value"] = np.inf
 252	    with pytest.raises(ValueError, match="finite"):
 253	        household_component_sum(panel)
 254	
 255	
 256	def test_household_component_sum_rejects_duplicate_person_component_rows() -> None:
 257	    panel = _panel()
 258	    with pytest.raises(ValueError, match="duplicate"):
 259	        household_component_sum(pd.concat([panel, panel.iloc[[0]]], ignore_index=True))
 260	
 261	
 262	def test_household_component_sum_rejects_missing_person_value() -> None:
 263	    panel = _panel()
 264	    panel.loc[0, "person_component_value"] = pd.NA
 265	    with pytest.raises(ValueError, match="missing person_component_value"):
 266	        household_component_sum(panel)
 267	
 268	
 269	def test_household_component_sum_rejects_missing_grouping_key() -> None:
 270	    panel = _panel()
 271	    panel.loc[0, "hh_id"] = pd.NA
 272	    with pytest.raises(ValueError, match="missing values in key column 'hh_id'"):
 273	        household_component_sum(panel)
 274	
 275	
 276	def test_household_component_sum_rejects_missing_required_column() -> None:
 277	    with pytest.raises(ValueError, match="missing required columns"):
 278	        household_component_sum(_panel().drop(columns=["p_id"]))
 279	
 280	
 281	def test_household_component_sum_rejects_non_canonical_component() -> None:
 282	    panel = _panel()
 283	    panel.loc[0, "component"] = "not_a_component"
 284	    with pytest.raises(ValueError, match="non-canonical"):
 285	        household_component_sum(panel)
 286	
 287	
 288	def test_punr_residual_is_zero_when_member_sum_equals_household_total() -> None:
 289	    out = punr_residual(_totals(150.0), _members(150.0))
 290	    assert math.isclose(out["punr_residual"].iloc[0], 0.0)
 291	
 292	
 293	def test_punr_residual_is_positive_when_household_exceeds_member_sum() -> None:
 294	    out = punr_residual(_totals(150.0), _members(100.0))
 295	    assert math.isclose(out["punr_residual"].iloc[0], 50.0)
 296	
 297	
 298	def test_punr_residual_for_debt_uses_positive_magnitudes() -> None:
 299	    # Debt is carried as positive magnitudes: 200 household - 150 members = +50 PUNR.
 300	    out = punr_residual(
 301	        _totals(200.0, "consumer_debt"), _members(150.0, "consumer_debt")
 302	    )
 303	    assert math.isclose(out["punr_residual"].iloc[0], 50.0)
 304	
 305	
 306	def test_punr_residual_returns_float64() -> None:
 307	    out = punr_residual(_totals(150.0), _members(100.0))
 308	    assert out["punr_residual"].dtype == np.float64
 309	
 310	
 311	def test_punr_residual_rejects_keys_present_on_only_one_side() -> None:
 312	    members = _members(100.0).assign(hh_id=[2])
 313	    with pytest.raises(ValueError, match="identical"):
 314	        punr_residual(_totals(150.0), members)
 315	
 316	
 317	def test_punr_residual_rejects_duplicate_keys() -> None:
 318	    totals = pd.concat([_totals(150.0), _totals(150.0)], ignore_index=True)
 319	    with pytest.raises(ValueError, match="duplicate"):
 320	        punr_residual(totals, _members(100.0))
```


### wealth_imputation/test_amount_model.py

```py
   1	"""Behavior of the amount model wrapper."""
   2	
   3	import numpy as np
   4	import pytest
   5	
   6	from soep_preparation.wealth_imputation.amount_model import AmountModel
   7	
   8	_SCALE = 1000.0
   9	
  10	
  11	def _asinh_linear_data() -> tuple[np.ndarray, np.ndarray]:
  12	    """Amounts whose asinh/scale transform is linear in a single feature."""
  13	    feature = np.linspace(-2.0, 2.0, 40)
  14	    observed = _SCALE * np.sinh(feature)
  15	    return feature.reshape(-1, 1), observed
  16	
  17	
  18	def test_amount_model_prediction_increases_with_the_feature():
  19	    """A higher feature value yields a larger predicted euro amount."""
  20	    features, observed = _asinh_linear_data()
  21	    model = AmountModel.fit(features, observed, scale=_SCALE)
  22	    predictions = model.predict(np.array([[-1.0], [1.0]]))
  23	    assert predictions[1] > predictions[0]
  24	
  25	
  26	def test_amount_model_recovers_observed_amounts_when_asinh_relation_is_linear():
  27	    """A perfectly linear asinh relation is recovered in euros within tolerance."""
  28	    features, observed = _asinh_linear_data()
  29	    model = AmountModel.fit(features, observed, scale=_SCALE)
  30	    predictions = model.predict(features)
  31	    np.testing.assert_allclose(predictions, observed, rtol=1e-6)
  32	
  33	
  34	@pytest.mark.parametrize("scale", [0.0, -1.0, np.inf])
  35	def test_amount_model_rejects_invalid_scale(scale: float):
  36	    """A non-positive or non-finite component scale fails closed."""
  37	    features, observed = _asinh_linear_data()
  38	    with pytest.raises(ValueError, match="scale"):
  39	        AmountModel.fit(features, observed, scale=scale)
  40	
  41	
  42	def test_amount_model_rejects_mismatched_lengths():
  43	    """A target with a different row count than the design matrix fails closed."""
  44	    features, observed = _asinh_linear_data()
  45	    with pytest.raises(ValueError, match="same number of rows"):
  46	        AmountModel.fit(features, observed[:-1], scale=_SCALE)
```


### wealth_imputation/test_amounts.py

```py
   1	"""Behavior of the PMM amount-draw orchestration."""
   2	
   3	import numpy as np
   4	import pytest
   5	
   6	from soep_preparation.wealth_imputation.amounts import draw_amounts
   7	from soep_preparation.wealth_imputation.donors import PmmResult
   8	
   9	
  10	def test_draw_amounts_returns_observed_value_of_nearest_donor_on_asinh_scale():
  11	    """k=1 draws the observed value of the nearest donor in asinh-scaled space."""
  12	    rng = np.random.default_rng(seed=0)
  13	    result = draw_amounts(
  14	        recipient_predicted=np.array([100.0]),
  15	        donor_predicted=np.array([10.0, 100.0, 1000.0]),
  16	        donor_observed=np.array([12.0, 90.0, 1100.0]),
  17	        scale=100.0,
  18	        k=1,
  19	        rng=rng,
  20	    )
  21	    # asinh(100/100) matches the second donor exactly; its observed value is 90.
  22	    np.testing.assert_allclose(result.values, [90.0], atol=1e-6)
  23	
  24	
  25	def test_draw_amounts_caliper_applies_on_the_asinh_scaled_axis():
  26	    """A recipient far from every donor on the scaled axis fails the caliper."""
  27	    rng = np.random.default_rng(seed=0)
  28	    with pytest.raises(ValueError, match="No eligible donor"):
  29	        draw_amounts(
  30	            recipient_predicted=np.array([1e9]),
  31	            donor_predicted=np.array([10.0, 100.0]),
  32	            donor_observed=np.array([12.0, 90.0]),
  33	            scale=100.0,
  34	            k=1,
  35	            rng=rng,
  36	            caliper=1.0,
  37	        )
  38	
  39	
  40	def _draw_once(seed: int) -> PmmResult:
  41	    return draw_amounts(
  42	        recipient_predicted=np.array([50.0]),
  43	        donor_predicted=np.array([10.0, 100.0, 1000.0]),
  44	        donor_observed=np.array([12.0, 90.0, 1100.0]),
  45	        scale=100.0,
  46	        k=2,
  47	        rng=np.random.default_rng(seed=seed),
  48	    )
  49	
  50	
  51	def test_draw_amounts_is_deterministic_for_a_fixed_seed():
  52	    """Same seed and inputs reproduce the drawn values and donor indices."""
  53	    first = _draw_once(seed=7)
  54	    second = _draw_once(seed=7)
  55	    np.testing.assert_array_equal(first.values, second.values)
  56	    np.testing.assert_array_equal(first.donor_indices, second.donor_indices)
  57	
  58	
  59	@pytest.mark.parametrize("scale", [0.0, -1.0, np.inf])
  60	def test_draw_amounts_rejects_invalid_scale(scale: float):
  61	    """A non-positive or non-finite component scale fails closed."""
  62	    with pytest.raises(ValueError, match="scale"):
  63	        draw_amounts(
  64	            recipient_predicted=np.array([100.0]),
  65	            donor_predicted=np.array([100.0]),
  66	            donor_observed=np.array([90.0]),
  67	            scale=scale,
  68	            k=1,
  69	            rng=np.random.default_rng(seed=0),
  70	        )
```


### wealth_imputation/test_components.py

```py
   1	"""Tests for canonical component ontology and provenance enums."""
   2	
   3	import pytest
   4	
   5	from soep_preparation.wealth_imputation.components import (
   6	    LIABILITY_COMPONENTS,
   7	    CanonicalComponent,
   8	    component_sign,
   9	)
  10	
  11	
  12	def test_component_sign_is_negative_for_liabilities_positive_for_assets() -> None:
  13	    """Return -1 for liabilities and +1 for assets."""
  14	    assert component_sign(CanonicalComponent.CONSUMER_DEBT) == -1
  15	    assert component_sign(CanonicalComponent.OWNER_OCCUPIED_MORTGAGE) == -1
  16	    assert component_sign(CanonicalComponent.FINANCIAL_ASSETS) == 1
  17	
  18	
  19	def test_component_sign_rejects_non_canonical_component() -> None:
  20	    """A raw string is rejected, not silently classified as an asset."""
  21	    with pytest.raises(TypeError, match="must be a CanonicalComponent"):
  22	        component_sign("consumer_debt")  # ty: ignore[invalid-argument-type]
  23	
  24	
  25	def test_liability_components_are_exactly_mortgage_and_consumer_debt() -> None:
  26	    """LIABILITY_COMPONENTS contains only mortgage and consumer debt."""
  27	    assert (
  28	        frozenset(
  29	            {
  30	                CanonicalComponent.OWNER_OCCUPIED_MORTGAGE,
  31	                CanonicalComponent.CONSUMER_DEBT,
  32	            }
  33	        )
  34	        == LIABILITY_COMPONENTS
  35	    )
```


### wealth_imputation/test_deflation.py

```py
   1	"""Behavior of cross-wave donor deflation."""
   2	
   3	import numpy as np
   4	import pytest
   5	
   6	from soep_preparation.wealth_imputation.deflation import (
   7	    deflate_donor_values,
   8	    deflation_factor,
   9	)
  10	
  11	_INDEX = {2012: 100.0, 2017: 150.0, 2022: 200.0}
  12	
  13	
  14	def test_deflation_factor_scales_an_earlier_wave_to_the_target():
  15	    """A 2012 donor is scaled by target/origin index to reach 2022 terms."""
  16	    np.testing.assert_allclose(
  17	        deflation_factor(_INDEX, from_year=2012, target_year=2022), 2.0, atol=1e-9
  18	    )
  19	
  20	
  21	def test_deflation_factor_is_one_for_the_target_year():
  22	    """A donor already in the target year is unchanged."""
  23	    np.testing.assert_allclose(
  24	        deflation_factor(_INDEX, from_year=2022, target_year=2022), 1.0, atol=1e-9
  25	    )
  26	
  27	
  28	def test_deflate_donor_values_applies_per_donor_origin_year():
  29	    """Each donor value is scaled by its own origin wave's factor."""
  30	    values = np.array([100.0, 100.0])
  31	    result = deflate_donor_values(
  32	        values, from_years=[2012, 2017], index_by_year=_INDEX, target_year=2022
  33	    )
  34	    # 100 * 200/100 = 200; 100 * 200/150 = 133.33...
  35	    np.testing.assert_allclose(result, [200.0, 400.0 / 3.0], atol=1e-6)
  36	
  37	
  38	def test_deflate_donor_values_raises_on_unknown_year():
  39	    """A donor wave missing from the index fails closed rather than guessing."""
  40	    with pytest.raises(ValueError, match="2005"):
  41	        deflate_donor_values(
  42	            np.array([100.0]),
  43	            from_years=[2005],
  44	            index_by_year=_INDEX,
  45	            target_year=2022,
  46	        )
```


### wealth_imputation/test_donors.py

```py
   1	import math
   2	
   3	import numpy as np
   4	import pytest
   5	
   6	from soep_preparation.wealth_imputation.donors import pmm_draw
   7	
   8	
   9	def test_pmm_draw_is_deterministic_under_same_seed():
  10	    donor_scores = np.array([0.0, 1.0, 5.0, 10.0])
  11	    donor_values = np.array([10.0, 11.0, 50.0, 100.0])
  12	    recipient_scores = np.array([0.4, 6.0])
  13	    first = pmm_draw(
  14	        recipient_scores,
  15	        donor_scores,
  16	        donor_values,
  17	        k=2,
  18	        rng=np.random.default_rng(seed=0),
  19	    )
  20	    second = pmm_draw(
  21	        recipient_scores,
  22	        donor_scores,
  23	        donor_values,
  24	        k=2,
  25	        rng=np.random.default_rng(seed=0),
  26	    )
  27	    np.testing.assert_array_equal(first.values, second.values)
  28	    np.testing.assert_array_equal(first.donor_indices, second.donor_indices)
  29	
  30	
  31	def test_pmm_draw_never_selects_donor_outside_caliper():
  32	    # Nearest donor (0.1) is inside the caliper; the other (100.0) is outside it.
  33	    donor_scores = np.array([0.1, 100.0])
  34	    donor_values = np.array([10.0, 999.0])
  35	    recipient_scores = np.array([0.0])
  36	    rng = np.random.default_rng(seed=1)
  37	    for _ in range(20):
  38	        result = pmm_draw(
  39	            recipient_scores, donor_scores, donor_values, k=2, rng=rng, caliper=0.2
  40	        )
  41	        assert result.donor_indices[0] == 0
  42	        assert math.isclose(result.values[0], 10.0)
  43	
  44	
  45	def test_pmm_draw_never_selects_excluded_donor():
  46	    donor_scores = np.array([0.0, 1.0])
  47	    donor_values = np.array([10.0, 11.0])
  48	    recipient_scores = np.array([0.0])
  49	    rng = np.random.default_rng(seed=0)
  50	    for _ in range(20):
  51	        result = pmm_draw(
  52	            recipient_scores, donor_scores, donor_values, k=1, rng=rng, exclude=[[0]]
  53	        )
  54	        assert result.donor_indices[0] == 1
  55	        assert math.isclose(result.values[0], 11.0)
  56	
  57	
  58	def test_pmm_draw_raises_when_no_donor_within_caliper():
  59	    donor_scores = np.array([0.0, 1.0])
  60	    donor_values = np.array([10.0, 11.0])
  61	    recipient_scores = np.array([100.0])
  62	    rng = np.random.default_rng(seed=0)
  63	    with pytest.raises(ValueError, match="No eligible donor"):
  64	        pmm_draw(
  65	            recipient_scores, donor_scores, donor_values, k=1, rng=rng, caliper=0.5
  66	        )
  67	
  68	
  69	def test_pmm_draw_rejects_k_below_one():
  70	    rng = np.random.default_rng(seed=0)
  71	    with pytest.raises(ValueError, match="k must be >= 1"):
  72	        pmm_draw(np.array([0.0]), np.array([0.0]), np.array([1.0]), k=0, rng=rng)
  73	
  74	
  75	def test_pmm_draw_rejects_empty_donors():
  76	    rng = np.random.default_rng(seed=0)
  77	    with pytest.raises(ValueError, match="non-empty"):
  78	        pmm_draw(np.array([0.0]), np.array([]), np.array([]), k=1, rng=rng)
  79	
  80	
  81	def test_pmm_draw_rejects_mismatched_donor_lengths():
  82	    rng = np.random.default_rng(seed=0)
  83	    with pytest.raises(ValueError, match="equal length"):
  84	        pmm_draw(np.array([0.0]), np.array([0.0, 1.0]), np.array([10.0]), k=1, rng=rng)
  85	
  86	
  87	def test_pmm_draw_rejects_non_finite_recipient_score():
  88	    rng = np.random.default_rng(seed=0)
  89	    with pytest.raises(ValueError, match="finite"):
  90	        pmm_draw(np.array([np.nan]), np.array([0.0]), np.array([10.0]), k=1, rng=rng)
  91	
  92	
  93	def test_pmm_draw_returns_float64_values_for_integer_donors():
  94	    donor_values = np.array([10, 11], dtype=np.int64)
  95	    result = pmm_draw(
  96	        np.array([0.0]),
  97	        np.array([0.0, 1.0]),
  98	        donor_values,
  99	        k=1,
 100	        rng=np.random.default_rng(seed=0),
 101	    )
 102	    assert result.values.dtype == np.float64
 103	
 104	
 105	def test_pmm_draw_rejects_non_integer_k():
 106	    rng = np.random.default_rng(seed=0)
 107	    with pytest.raises(TypeError, match="k must be an integer"):
 108	        pmm_draw(
 109	            np.array([0.0]),
 110	            np.array([0.0]),
 111	            np.array([1.0]),
 112	            k=1.5,  # ty: ignore[invalid-argument-type]
 113	            rng=rng,
 114	        )
 115	
 116	
 117	def test_pmm_draw_rejects_negative_exclusion_index():
 118	    rng = np.random.default_rng(seed=0)
 119	    with pytest.raises(ValueError, match="outside"):
 120	        pmm_draw(
 121	            np.array([0.0]),
 122	            np.array([0.0, 1.0]),
 123	            np.array([10.0, 11.0]),
 124	            k=1,
 125	            rng=rng,
 126	            exclude=[[-1]],
 127	        )
 128	
 129	
 130	def test_pmm_draw_rejects_out_of_range_exclusion_index():
 131	    rng = np.random.default_rng(seed=0)
 132	    with pytest.raises(ValueError, match="outside"):
 133	        pmm_draw(
 134	            np.array([0.0]),
 135	            np.array([0.0, 1.0]),
 136	            np.array([10.0, 11.0]),
 137	            k=1,
 138	            rng=rng,
 139	            exclude=[[5]],
 140	        )
 141	
 142	
 143	def test_pmm_draw_rejects_fractional_exclusion_index():
 144	    rng = np.random.default_rng(seed=0)
 145	    with pytest.raises(ValueError, match="integer donor indices"):
 146	        pmm_draw(
 147	            np.array([0.0]),
 148	            np.array([0.0, 1.0]),
 149	            np.array([10.0, 11.0]),
 150	            k=1,
 151	            rng=rng,
 152	            exclude=[[0.9]],  # ty: ignore[invalid-argument-type]
 153	        )
 154	
 155	
 156	def test_pmm_draw_rejects_boolean_exclusion_index():
 157	    rng = np.random.default_rng(seed=0)
 158	    with pytest.raises(ValueError, match="not booleans"):
 159	        pmm_draw(
 160	            np.array([0.0]),
 161	            np.array([0.0, 1.0]),
 162	            np.array([10.0, 11.0]),
 163	            k=1,
 164	            rng=rng,
 165	            exclude=[[True]],
 166	        )
```


### wealth_imputation/test_features.py

```py
   1	"""Behavior of the wealth-model feature registry."""
   2	
   3	import numpy as np
   4	import pandas as pd
   5	import pytest
   6	
   7	from soep_preparation.wealth_imputation.features import (
   8	    FEATURE_SPECS,
   9	    assemble_feature_matrix,
  10	    encode_features,
  11	    fail_if_features_missing,
  12	    fit_categorical_encoder,
  13	    lagged_wealth,
  14	    required_columns_by_module,
  15	)
  16	
  17	
  18	def test_fit_categorical_encoder_captures_sorted_training_categories():
  19	    """The encoder records the sorted distinct categories seen in training."""
  20	    frame = pd.DataFrame({"education": ["b", "a", "a", "b"]})
  21	    encoder = fit_categorical_encoder(frame, ["education"])
  22	    assert encoder.categories["education"] == ("a", "b")
  23	
  24	
  25	def test_encode_features_one_hot_encodes_against_fixed_categories():
  26	    """One-hot columns follow the encoder's categories, unseen levels go to zero."""
  27	    train = pd.DataFrame({"x": [1.0, 2.0], "g": ["a", "b"]})
  28	    encoder = fit_categorical_encoder(train, ["g"])
  29	    recipients = pd.DataFrame({"x": [3.0, 4.0], "g": ["b", "c"]})  # "c" unseen
  30	    matrix = encode_features(recipients, continuous_columns=["x"], encoder=encoder)
  31	    # Columns: [x, g==a, g==b]; row 0 -> [3,0,1]; row 1 (unseen c) -> [4,0,0].
  32	    np.testing.assert_allclose(matrix, [[3.0, 0.0, 1.0], [4.0, 0.0, 0.0]], atol=1e-6)
  33	
  34	
  35	def test_encode_features_gives_train_and_recipients_the_same_width():
  36	    """Train and recipient matrices share column layout for model compatibility."""
  37	    train = pd.DataFrame({"x": [1.0, 2.0, 3.0], "g": ["a", "b", "a"]})
  38	    encoder = fit_categorical_encoder(train, ["g"])
  39	    recipients = pd.DataFrame({"x": [9.0], "g": ["b"]})
  40	    train_matrix = encode_features(train, continuous_columns=["x"], encoder=encoder)
  41	    recipient_matrix = encode_features(
  42	        recipients, continuous_columns=["x"], encoder=encoder
  43	    )
  44	    assert train_matrix.shape[1] == recipient_matrix.shape[1]
  45	
  46	
  47	def test_lagged_wealth_attaches_prior_wave_value_to_the_current_wave():
  48	    """A person's prior-wave wealth becomes a `lagged_` predictor one cycle later."""
  49	    wealth_panel = pd.DataFrame(
  50	        {
  51	            "p_id": [1, 1],
  52	            "survey_year": [2012, 2017],
  53	            "financial_assets_value": [100.0, 150.0],
  54	        }
  55	    )
  56	    result = lagged_wealth(
  57	        wealth_panel, value_columns=("financial_assets_value",), wave_gap=5
  58	    )
  59	    by_year = result.set_index("survey_year")
  60	    prior_value = wealth_panel.set_index("survey_year").loc[
  61	        2012, "financial_assets_value"
  62	    ]
  63	    # The 2012 value is the lag attached to the 2017 row.
  64	    assert by_year.loc[2017, "lagged_financial_assets_value"] == prior_value
  65	
  66	
  67	def test_lagged_wealth_has_no_lag_for_the_first_observed_wave():
  68	    """The earliest wave has no prior value, so it is absent from the lag frame."""
  69	    wealth_panel = pd.DataFrame(
  70	        {
  71	            "p_id": [1],
  72	            "survey_year": [2012],
  73	            "financial_assets_value": [100.0],
  74	        }
  75	    )
  76	    result = lagged_wealth(
  77	        wealth_panel, value_columns=("financial_assets_value",), wave_gap=5
  78	    )
  79	    first_wave = wealth_panel["survey_year"].iloc[0]
  80	    assert first_wave not in set(result["survey_year"])
  81	
  82	
  83	def _modules_with_two_persons_one_household() -> dict[str, pd.DataFrame]:
  84	    """Minimal cleaned modules: two persons in one owner-occupied household."""
  85	    columns = required_columns_by_module()
  86	    frames: dict[str, pd.DataFrame] = {}
  87	    for module, cols in columns.items():
  88	        if "p_id" in cols:  # person-level module
  89	            frame = pd.DataFrame({col: [0, 0] for col in cols})
  90	            frame["p_id"] = [1, 2]
  91	            frame["hh_id"] = [10, 10]
  92	            frame["survey_year"] = [2017, 2017]
  93	        else:  # household-level module
  94	            frame = pd.DataFrame({col: [0] for col in cols})
  95	            frame["hh_id"] = [10]
  96	            frame["survey_year"] = [2017]
  97	        frames[module] = frame
  98	    frames["pequiv"]["age"] = [40, 38]
  99	    frames["hgen"]["rented_or_owned"] = ["owned"]
 100	    return frames
 101	
 102	
 103	def test_assemble_feature_matrix_joins_persons_and_broadcasts_household_features():
 104	    """Each person row carries its own and its household's predictors."""
 105	    modules = _modules_with_two_persons_one_household()
 106	    expected_persons = len(modules["pequiv"])
 107	    result = assemble_feature_matrix(modules)
 108	    assert len(result) == expected_persons
 109	    by_person = result.set_index("p_id")
 110	    expected_age = modules["pequiv"].set_index("p_id").loc[1, "age"]
 111	    assert by_person.loc[1, "age"] == expected_age
 112	    # Household-level predictor is broadcast to every member.
 113	    assert by_person.loc[1, "rented_or_owned"] == "owned"
 114	    assert by_person.loc[2, "rented_or_owned"] == "owned"
 115	
 116	
 117	def test_assemble_feature_matrix_exposes_every_registered_feature():
 118	    """The design matrix carries each registered predictor column."""
 119	    result = assemble_feature_matrix(_modules_with_two_persons_one_household())
 120	    expected = {spec.column for spec in FEATURE_SPECS}
 121	    assert expected <= set(result.columns)
 122	
 123	
 124	def test_required_columns_by_module_includes_keys_and_feature_columns():
 125	    """Each module lists its level keys plus the features drawn from it."""
 126	    by_module = required_columns_by_module()
 127	    assert by_module["hgen"] == (
 128	        "hh_id",
 129	        "survey_year",
 130	        "rented_or_owned",
 131	        "living_space_hh",
 132	        "building_year_hh_min",
 133	    )
 134	    assert {"p_id", "hh_id", "survey_year", "age", "gender"} <= set(by_module["pequiv"])
 135	
 136	
 137	def test_fail_if_features_missing_passes_when_all_columns_present():
 138	    """A complete set of modules with every required column does not raise."""
 139	    modules = {
 140	        module: pd.DataFrame(columns=list(columns))
 141	        for module, columns in required_columns_by_module().items()
 142	    }
 143	    fail_if_features_missing(modules)  # no raise
 144	
 145	
 146	def test_fail_if_features_missing_raises_on_missing_column():
 147	    """A module missing a registered feature column fails closed."""
 148	    modules = {
 149	        module: pd.DataFrame(columns=list(columns))
 150	        for module, columns in required_columns_by_module().items()
 151	    }
 152	    modules["hgen"] = modules["hgen"].drop(columns=["rented_or_owned"])
 153	    with pytest.raises(ValueError, match="rented_or_owned"):
 154	        fail_if_features_missing(modules)
 155	
 156	
 157	def test_fail_if_features_missing_raises_on_absent_module():
 158	    """An absent source module fails closed."""
 159	    modules = {
 160	        module: pd.DataFrame(columns=list(columns))
 161	        for module, columns in required_columns_by_module().items()
 162	        if module != "ppathl"
 163	    }
 164	    with pytest.raises(ValueError, match="ppathl"):
 165	        fail_if_features_missing(modules)
 166	
 167	
 168	def test_feature_specs_homeownership_is_a_household_predictor():
 169	    """Homeownership is registered as a household-level predictor."""
 170	    homeownership = next(
 171	        spec for spec in FEATURE_SPECS if spec.column == "rented_or_owned"
 172	    )
 173	    assert homeownership.level == "household"
```


### wealth_imputation/test_impute.py

```py
   1	"""End-to-end behavior of the 2022 wealth imputation on synthetic modules."""
   2	
   3	import numpy as np
   4	import pandas as pd
   5	import pytest
   6	
   7	from soep_preparation.wealth_imputation.components import CanonicalComponent
   8	from soep_preparation.wealth_imputation.impute import (
   9	    _OFFICIAL_TOTAL_COLUMN,
  10	    _training_residual,
  11	    run_imputation,
  12	)
  13	from soep_preparation.wealth_imputation.market_indices import RESIDUAL_INDEX
  14	
  15	_TRAIN_IDS = list(range(1, 11))  # ten 2017 training households (one person each)
  16	_RECIPIENT_IDS = [101, 102, 103]  # three 2022 recipient households
  17	_TRAIN_WAVE = 2017
  18	
  19	
  20	def _feature_frame(p_ids: list[int], year: int) -> pd.DataFrame:
  21	    n = len(p_ids)
  22	    return pd.DataFrame(
  23	        {
  24	            "p_id": p_ids,
  25	            "hh_id": p_ids,
  26	            "survey_year": [year] * n,
  27	            "age": np.linspace(35, 70, n),
  28	            "gender": ["m", "f"] * (n // 2) + ["m"] * (n % 2),
  29	            "number_of_persons_hh": [2] * n,
  30	            "number_of_children_living_in_hh": [1] * n,
  31	            "federal_state_of_residence": ["BY"] * n,
  32	            "einkommen_nach_steuern_y_hh": np.linspace(20000, 90000, n),
  33	        }
  34	    )
  35	
  36	
  37	def _pequiv() -> pd.DataFrame:
  38	    return pd.concat(
  39	        [_feature_frame(_TRAIN_IDS, 2017), _feature_frame(_RECIPIENT_IDS, 2022)],
  40	        ignore_index=True,
  41	    )
  42	
  43	
  44	def _pgen() -> pd.DataFrame:
  45	    frame = _pequiv()[["p_id", "hh_id", "survey_year"]].copy()
  46	    n = len(frame)
  47	    frame["education_isced"] = "tertiary"
  48	    frame["employment_status"] = "employed"
  49	    frame["marital_status"] = "married"
  50	    frame["occupation_status"] = "white_collar"
  51	    frame["self_employed"] = "no"
  52	    frame["retired"] = "no"
  53	    frame["gross_labor_income_previous_month_m"] = np.linspace(1500, 6000, n)
  54	    frame["tenure"] = np.linspace(1, 30, n)
  55	    return frame
  56	
  57	
  58	def _ppathl() -> pd.DataFrame:
  59	    frame = _pequiv()[["p_id", "hh_id", "survey_year"]].copy()
  60	    frame["migration_background"] = "none"
  61	    return frame
  62	
  63	
  64	def _hgen() -> pd.DataFrame:
  65	    frame = _pequiv()[["hh_id", "survey_year"]].copy()
  66	    n = len(frame)
  67	    frame["rented_or_owned"] = "owned"
  68	    frame["living_space_hh"] = np.linspace(60, 160, n)
  69	    frame["building_year_hh_min"] = np.linspace(1950, 2010, n)
  70	    return frame
  71	
  72	
  73	def _owns_first(count: int, value: float, total: int) -> list[float]:
  74	    return [value] * count + [0.0] * (total - count)
  75	
  76	
  77	def _pwealth() -> pd.DataFrame:
  78	    """Person wealth: lag sources plus the summed person-direct components.
  79	
  80	    Rows at 2012 lag into the 2017 training features; 2017 rows for the training
  81	    households supply the insurances/consumer-debt component targets (summed to the
  82	    household); 2017 rows for the recipients lag into 2022.
  83	    """
  84	    blocks = [
  85	        pd.DataFrame(  # lag source for the 2017 training features
  86	            {"p_id": _TRAIN_IDS, "hh_id": _TRAIN_IDS, "survey_year": [2012] * 10}
  87	        ),
  88	        pd.DataFrame(  # 2017 person-direct component source for training households
  89	            {"p_id": _TRAIN_IDS, "hh_id": _TRAIN_IDS, "survey_year": [2017] * 10}
  90	        ),
  91	        pd.DataFrame(  # lag source for the 2022 recipients
  92	            {
  93	                "p_id": _RECIPIENT_IDS,
  94	                "hh_id": _RECIPIENT_IDS,
  95	                "survey_year": [2017] * len(_RECIPIENT_IDS),
  96	            }
  97	        ),
  98	    ]
  99	    frame = pd.concat(blocks, ignore_index=True)
 100	    n = len(frame)
 101	    frame["property_value_primary_residence_a"] = np.linspace(0, 300000, n)
 102	    frame["financial_assets_value_a"] = np.linspace(0, 60000, n)
 103	    frame["vehicles_value_a"] = np.linspace(0, 15000, n)
 104	    frame["private_insurances_value_a"] = np.linspace(0, 30000, n)
 105	    frame["consumer_debt_value_a"] = np.linspace(0, 9000, n)
 106	    # Give the 2017 training households a clear owner/non-owner split per component.
 107	    is_train_2017 = (frame["survey_year"] == _TRAIN_WAVE) & frame["hh_id"].isin(
 108	        _TRAIN_IDS
 109	    )
 110	    frame.loc[is_train_2017, "private_insurances_value_a"] = _owns_first(6, 20000.0, 10)
 111	    frame.loc[is_train_2017, "consumer_debt_value_a"] = _owns_first(5, 8000.0, 10)
 112	    return frame
 113	
 114	
 115	def _hwealth() -> pd.DataFrame:
 116	    """Household targets for the ten 2017 training households (owners + non-owners)."""
 117	    frame = pd.DataFrame({"hh_id": _TRAIN_IDS, "survey_year": [2017] * 10})
 118	    frame["hh_net_property_value_primary_residence_a"] = _owns_first(6, 250000.0, 10)
 119	    frame["hh_financial_assets_value_a"] = _owns_first(7, 40000.0, 10)
 120	    frame["hh_vehicles_value_a"] = _owns_first(8, 12000.0, 10)
 121	    total = (
 122	        frame["hh_net_property_value_primary_residence_a"]
 123	        + frame["hh_financial_assets_value_a"]
 124	        + frame["hh_vehicles_value_a"]
 125	    )
 126	    frame["hh_net_overall_wealth_including_vehicles_and_student_loans_a"] = (
 127	        total + 10000.0  # residual = other RE/business/insurance net of debts
 128	    )
 129	    return frame
 130	
 131	
 132	def _synthetic_modules() -> dict[str, pd.DataFrame]:
 133	    return {
 134	        "pequiv": _pequiv(),
 135	        "pgen": _pgen(),
 136	        "ppathl": _ppathl(),
 137	        "hgen": _hgen(),
 138	        "pwealth": _pwealth(),
 139	        "hwealth": _hwealth(),
 140	    }
 141	
 142	
 143	def test_run_imputation_produces_one_interval_per_recipient_household():
 144	    """Each 2022 household gets a finite, ordered net-wealth interval."""
 145	    result = run_imputation(_synthetic_modules(), n_draws=50, seed=0, k=3)
 146	    intervals = result.intervals
 147	    assert set(intervals["hh_id"]) == set(_RECIPIENT_IDS)
 148	    assert np.all(np.isfinite(intervals["point_estimate"].to_numpy()))
 149	    assert np.all(intervals["lower"].to_numpy() <= intervals["upper"].to_numpy())
 150	
 151	
 152	def test_run_imputation_fits_all_five_components():
 153	    """All five components (3 joint + 2 person-direct) are fit and none skipped."""
 154	    result = run_imputation(_synthetic_modules(), n_draws=20, seed=0, k=3)
 155	    expected = {
 156	        "owner_occupied_property_gross",
 157	        "financial_assets",
 158	        "vehicles",
 159	        "private_pension",
 160	        "consumer_debt",
 161	    }
 162	    assert set(result.summary["components_used"]) == expected
 163	    assert result.summary["components_skipped"] == []
 164	    assert result.summary["n_recipients"] == len(_RECIPIENT_IDS)
 165	
 166	
 167	def test_run_imputation_allocates_residual_with_a_two_part_model():
 168	    """The residual to the official total is allocated per household, not flat."""
 169	    result = run_imputation(_synthetic_modules(), n_draws=20, seed=0, k=3)
 170	    assert result.summary["residual_model"] == "two_part"
 171	
 172	
 173	def test_training_residual_deflates_to_the_target_wave():
 174	    """The signed residual to the official total is brought into target-wave terms."""
 175	    training = pd.DataFrame(
 176	        {
 177	            "survey_year": [2012, 2012],
 178	            "hh_vehicles_value_a": [10000.0, 0.0],
 179	            _OFFICIAL_TOTAL_COLUMN: [30000.0, 5000.0],
 180	        }
 181	    )
 182	    _, residual = _training_residual(
 183	        training, [CanonicalComponent.VEHICLES], target_year=2022
 184	    )
 185	    factor = RESIDUAL_INDEX[2022] / RESIDUAL_INDEX[2012]
 186	    np.testing.assert_allclose(residual, np.array([20000.0, 5000.0]) * factor)
 187	
 188	
 189	def test_run_imputation_raises_without_recipients():
 190	    """Imputation fails closed when no 2022 households are present."""
 191	    modules = _synthetic_modules()
 192	    for name in ("pequiv", "pgen", "ppathl", "hgen"):
 193	        modules[name] = modules[name].query("survey_year != 2022")
 194	    with pytest.raises(ValueError, match="2022 recipients"):
 195	        run_imputation(modules, n_draws=10, seed=0, k=3)
```


### wealth_imputation/test_intervals.py

```py
   1	"""Behavior of household-total interval assembly."""
   2	
   3	import numpy as np
   4	import pandas as pd
   5	import pytest
   6	
   7	from soep_preparation.wealth_imputation.intervals import household_total_intervals
   8	
   9	
  10	def _draws(values: list[float], hh_id: int = 1) -> pd.DataFrame:
  11	    return pd.DataFrame(
  12	        {
  13	            "hh_id": [hh_id] * len(values),
  14	            "survey_year": [2017] * len(values),
  15	            "household_total_draw": values,
  16	        }
  17	    )
  18	
  19	
  20	def test_household_total_intervals_returns_median_and_central_bounds():
  21	    """Point estimate is the median; bounds are the central-`level` quantiles."""
  22	    result = household_total_intervals(
  23	        _draws([100.0, 200.0, 300.0, 400.0, 500.0]), level=0.8
  24	    )
  25	    row = result.iloc[0]
  26	    np.testing.assert_allclose(row["point_estimate"], 300.0, atol=1e-6)
  27	    np.testing.assert_allclose(row["lower"], 140.0, atol=1e-6)
  28	    np.testing.assert_allclose(row["upper"], 460.0, atol=1e-6)
  29	
  30	
  31	def test_household_total_intervals_summarises_each_household_separately():
  32	    """Each household's interval uses only its own draws."""
  33	    draws = pd.concat(
  34	        [
  35	            _draws([10.0, 20.0, 30.0], hh_id=1),
  36	            _draws([100.0, 200.0, 300.0], hh_id=2),
  37	        ],
  38	        ignore_index=True,
  39	    )
  40	    result = household_total_intervals(draws, level=0.5).set_index("hh_id")
  41	    np.testing.assert_allclose(result.loc[1, "point_estimate"], 20.0, atol=1e-6)
  42	    np.testing.assert_allclose(result.loc[2, "point_estimate"], 200.0, atol=1e-6)
  43	
  44	
  45	@pytest.mark.parametrize("level", [0.0, 1.0, -0.1, 1.5])
  46	def test_household_total_intervals_rejects_level_outside_unit_interval(level: float):
  47	    """A coverage level outside (0, 1) fails closed."""
  48	    with pytest.raises(ValueError, match="level"):
  49	        household_total_intervals(_draws([1.0, 2.0, 3.0]), level=level)
  50	
  51	
  52	def test_household_total_intervals_returns_float64_bounds():
  53	    """Bounds are float64 even when draws are integer-typed."""
  54	    draws = pd.DataFrame(
  55	        {
  56	            "hh_id": [1, 1, 1],
  57	            "survey_year": [2017, 2017, 2017],
  58	            "household_total_draw": pd.array([10, 20, 30], dtype="int64"),
  59	        }
  60	    )
  61	    result = household_total_intervals(draws)
  62	    assert result["lower"].dtype == np.float64
  63	    assert result["upper"].dtype == np.float64
```


### wealth_imputation/test_market_indices.py

```py
   1	"""The residual blend index combines property and equity, rebased to a common base."""
   2	
   3	import pytest
   4	
   5	from soep_preparation.wealth_imputation.market_indices import (
   6	    HOUSE_PRICE_INDEX,
   7	    MSCI_WORLD_INDEX,
   8	    RESIDUAL_INDEX,
   9	)
  10	
  11	_BASE_YEAR = 2000
  12	
  13	
  14	def test_residual_index_is_one_hundred_in_the_base_year():
  15	    """Both legs are rebased to 100 in the base year, so their blend is too."""
  16	    assert RESIDUAL_INDEX[_BASE_YEAR] == pytest.approx(100.0)
  17	
  18	
  19	def test_residual_index_is_the_equal_weight_rebased_blend():
  20	    """Each level is the mean of the two legs rebased to the common base year."""
  21	    year = 2022
  22	    house = HOUSE_PRICE_INDEX[year] / HOUSE_PRICE_INDEX[_BASE_YEAR] * 100.0
  23	    equity = MSCI_WORLD_INDEX[year] / MSCI_WORLD_INDEX[_BASE_YEAR] * 100.0
  24	    assert RESIDUAL_INDEX[year] == pytest.approx(0.5 * house + 0.5 * equity)
  25	
  26	
  27	def test_residual_index_covers_all_wealth_waves_and_2022():
  28	    """The index must span every donor wave plus the 2022 target."""
  29	    for year in (2002, 2007, 2012, 2017, 2022):
  30	        assert year in RESIDUAL_INDEX
```


### wealth_imputation/test_ownership_model.py

```py
   1	"""Behavior of the ownership-incidence model wrapper."""
   2	
   3	import numpy as np
   4	import pytest
   5	
   6	from soep_preparation.wealth_imputation.ownership_model import OwnershipModel
   7	
   8	
   9	def _separable_data() -> tuple[np.ndarray, np.ndarray]:
  10	    """Ownership perfectly separated by a single feature at zero."""
  11	    features = np.linspace(-5.0, 5.0, 40).reshape(-1, 1)
  12	    owns = (features.ravel() > 0.0).astype(int)
  13	    return features, owns
  14	
  15	
  16	def test_ownership_model_probability_increases_with_the_separating_feature():
  17	    """A higher feature value yields a higher fitted ownership probability."""
  18	    features, owns = _separable_data()
  19	    model = OwnershipModel.fit(features, owns, seed=0)
  20	    probabilities = model.probability(np.array([[-4.0], [4.0]]))
  21	    assert probabilities[1] > probabilities[0]
  22	
  23	
  24	def test_ownership_model_probabilities_lie_in_the_unit_interval():
  25	    """Predicted probabilities are valid probabilities."""
  26	    features, owns = _separable_data()
  27	    model = OwnershipModel.fit(features, owns, seed=0)
  28	    probabilities = model.probability(features)
  29	    assert np.all((probabilities >= 0.0) & (probabilities <= 1.0))
  30	
  31	
  32	def test_ownership_model_is_deterministic_for_a_fixed_seed():
  33	    """The same seed and data reproduce identical probabilities."""
  34	    features, owns = _separable_data()
  35	    first = OwnershipModel.fit(features, owns, seed=3).probability(features)
  36	    second = OwnershipModel.fit(features, owns, seed=3).probability(features)
  37	    np.testing.assert_array_equal(first, second)
  38	
  39	
  40	def test_ownership_model_rejects_single_class_outcome():
  41	    """Fitting an incidence model needs both ownership classes present."""
  42	    features = np.linspace(-5.0, 5.0, 10).reshape(-1, 1)
  43	    owns = np.ones(10, dtype=int)
  44	    with pytest.raises(ValueError, match="both classes"):
  45	        OwnershipModel.fit(features, owns, seed=0)
  46	
  47	
  48	def test_ownership_model_rejects_non_binary_outcome():
  49	    """A non-0/1 outcome fails closed."""
  50	    features = np.linspace(-5.0, 5.0, 10).reshape(-1, 1)
  51	    owns = np.full(10, 2, dtype=int)
  52	    with pytest.raises(ValueError, match="binary"):
  53	        OwnershipModel.fit(features, owns, seed=0)
```


### wealth_imputation/test_probe.py

```py
   1	import json
   2	
   3	from soep_preparation.wealth_imputation.components import CanonicalComponent
   4	from soep_preparation.wealth_imputation.probe import (
   5	    assemble_probe_report,
   6	    inventory_columns,
   7	)
   8	from soep_preparation.wealth_imputation.registry import (
   9	    AggregationRule,
  10	    VerificationStatus,
  11	    WealthVariable,
  12	)
  13	
  14	_EXPECTED_ENTRY_KEYS = {
  15	    "component",
  16	    "wave",
  17	    "source_file",
  18	    "raw_variable",
  19	    "present",
  20	    "verification_status",
  21	}
  22	_EXPECTED_SUMMARY_KEYS = {
  23	    "n_entries",
  24	    "n_present",
  25	    "n_missing",
  26	    "n_unresolved_required",
  27	}
  28	
  29	
  30	def _entry(raw_variable: str, *, required: bool) -> WealthVariable:
  31	    return WealthVariable(
  32	        component=CanonicalComponent.FINANCIAL_ASSETS,
  33	        wave=2017,
  34	        source_file="pl",
  35	        raw_variable=raw_variable,
  36	        concept="financial assets",
  37	        unit="euro",
  38	        universe="adults 17+",
  39	        missing_codes=(-1,),
  40	        bracket_variable=None,
  41	        ownership_flag=None,
  42	        ownership_share_variable=None,
  43	        level="person",
  44	        aggregation_rule=AggregationRule.PERSON_DIRECT_PLAIN_SUM,
  45	        expected_min=0.0,
  46	        expected_max=None,
  47	        verification_status=VerificationStatus.UNRESOLVED,
  48	        verification_evidence="",
  49	        codebook_version="V41",
  50	        required_for_release=required,
  51	    )
  52	
  53	
  54	def test_assemble_probe_report_flags_present_and_missing_without_leaking_data():
  55	    entries = [
  56	        _entry("present_var", required=True),
  57	        _entry("absent_var", required=True),
  58	    ]
  59	    available = {"pl": frozenset({"present_var", "other"})}
  60	    report = assemble_probe_report(entries, available)
  61	    assert report["summary"]["n_present"] == 1
  62	    assert report["summary"]["n_missing"] == 1
  63	    assert report["summary"]["n_unresolved_required"] == 2  # noqa: PLR2004
  64	    presence = {row["raw_variable"]: row["present"] for row in report["entries"]}
  65	    assert presence == {"present_var": True, "absent_var": False}
  66	
  67	
  68	def test_assemble_probe_report_has_exact_disclosure_safe_schema():
  69	    report = assemble_probe_report(
  70	        [_entry("present_var", required=True)], {"pl": frozenset({"present_var"})}
  71	    )
  72	    assert set(report.keys()) == {"entries", "summary", "observed_columns"}
  73	    assert set(report["summary"].keys()) == _EXPECTED_SUMMARY_KEYS
  74	    assert set(report["entries"][0].keys()) == _EXPECTED_ENTRY_KEYS
  75	    # Disclosure-safe: the whole report serialises to JSON (only primitives/keys).
  76	    json.dumps(report)
  77	
  78	
  79	def test_inventory_columns_returns_sorted_names_per_source():
  80	    """Each source file maps to its column names, sorted, with no row data."""
  81	    available = {
  82	        "pgen": frozenset({"pgisced11", "pgemplst", "pid"}),
  83	        "hgen": frozenset({"hgowner", "hid"}),
  84	    }
  85	    assert inventory_columns(available) == {
  86	        "pgen": ["pgemplst", "pgisced11", "pid"],
  87	        "hgen": ["hgowner", "hid"],
  88	    }
  89	
  90	
  91	def test_assemble_probe_report_lists_only_wealth_pattern_columns():
  92	    """`observed_columns` surfaces DIW wealth names and drops identifiers/free text."""
  93	    available = {"pwealth": frozenset({"p0100a", "p10000", "pid", "syear", "comment"})}
  94	    report = assemble_probe_report([_entry("p0100a", required=True)], available)
  95	    assert report["observed_columns"] == {"pwealth": ["p0100a", "p10000"]}
```


### wealth_imputation/test_registry.py

```py
   1	from typing import Literal
   2	
   3	import pytest
   4	
   5	from soep_preparation.wealth_imputation.components import CanonicalComponent
   6	from soep_preparation.wealth_imputation.registry import (
   7	    AggregationRule,
   8	    VerificationStatus,
   9	    WealthVariable,
  10	    fail_if_unresolved_required,
  11	)
  12	
  13	
  14	def _entry(  # noqa: PLR0913
  15	    *,
  16	    status: VerificationStatus,
  17	    required: bool,
  18	    component: CanonicalComponent = CanonicalComponent.FINANCIAL_ASSETS,
  19	    evidence: str = "codebook p.42",
  20	    expected_min: float | None = 0.0,
  21	    expected_max: float | None = None,
  22	    aggregation_rule: AggregationRule = AggregationRule.PERSON_DIRECT_PLAIN_SUM,
  23	    level: Literal["person", "household"] = "person",
  24	    ownership_share_variable: str | None = None,
  25	) -> WealthVariable:
  26	    return WealthVariable(
  27	        component=component,
  28	        wave=2017,
  29	        source_file="pl",
  30	        raw_variable="f0100a",
  31	        concept="financial assets value",
  32	        unit="euro",
  33	        universe="adults 17+",
  34	        missing_codes=(-1, -2, -8),
  35	        bracket_variable=None,
  36	        ownership_flag=None,
  37	        ownership_share_variable=ownership_share_variable,
  38	        level=level,
  39	        aggregation_rule=aggregation_rule,
  40	        expected_min=expected_min,
  41	        expected_max=expected_max,
  42	        verification_status=status,
  43	        verification_evidence=evidence,
  44	        codebook_version="V41",
  45	        required_for_release=required,
  46	    )
  47	
  48	
  49	def test_fail_if_unresolved_required_raises_for_required_unresolved_entry():
  50	    entries = [_entry(status=VerificationStatus.UNRESOLVED, required=True)]
  51	    with pytest.raises(
  52	        ValueError, match="Release-critical registry entries are unresolved"
  53	    ):
  54	        fail_if_unresolved_required(entries)
  55	
  56	
  57	def test_fail_if_unresolved_required_allows_unresolved_optional_entry():
  58	    entries = [_entry(status=VerificationStatus.UNRESOLVED, required=False)]
  59	    fail_if_unresolved_required(entries)  # no raise
  60	
  61	
  62	def test_wealth_variable_is_frozen():
  63	    entry = _entry(status=VerificationStatus.VERIFIED, required=True)
  64	    with pytest.raises(AttributeError):
  65	        entry.raw_variable = "x"  # ty: ignore[invalid-assignment]
  66	
  67	
  68	def test_net_sign_is_minus_one_for_liability_component():
  69	    entry = _entry(
  70	        status=VerificationStatus.VERIFIED,
  71	        required=True,
  72	        component=CanonicalComponent.CONSUMER_DEBT,
  73	    )
  74	    assert entry.net_sign == -1
  75	
  76	
  77	def test_net_sign_is_plus_one_for_asset_component():
  78	    entry = _entry(status=VerificationStatus.VERIFIED, required=True)
  79	    assert entry.net_sign == 1
  80	
  81	
  82	def test_wealth_variable_rejects_inverted_expected_bounds():
  83	    with pytest.raises(ValueError, match="exceeds expected_max"):
  84	        _entry(
  85	            status=VerificationStatus.INFERRED,
  86	            required=False,
  87	            expected_min=10.0,
  88	            expected_max=1.0,
  89	        )
  90	
  91	
  92	def test_wealth_variable_rejects_non_finite_expected_bound():
  93	    with pytest.raises(ValueError, match="must be finite"):
  94	        _entry(
  95	            status=VerificationStatus.INFERRED,
  96	            required=False,
  97	            expected_max=float("nan"),
  98	        )
  99	
 100	
 101	def test_verified_entry_requires_non_empty_evidence():
 102	    with pytest.raises(ValueError, match="requires non-empty evidence"):
 103	        _entry(status=VerificationStatus.VERIFIED, required=True, evidence="")
 104	
 105	
 106	def test_household_direct_rule_requires_household_level():
 107	    with pytest.raises(ValueError, match="HOUSEHOLD_DIRECT requires level"):
 108	        _entry(
 109	            status=VerificationStatus.INFERRED,
 110	            required=False,
 111	            aggregation_rule=AggregationRule.HOUSEHOLD_DIRECT,
 112	            level="person",
 113	        )
 114	
 115	
 116	def test_person_share_rule_requires_a_share_variable():
 117	    with pytest.raises(ValueError, match="requires an ownership_share_variable"):
 118	        _entry(
 119	            status=VerificationStatus.INFERRED,
 120	            required=False,
 121	            aggregation_rule=AggregationRule.PERSON_SHARE_THEN_PLAIN_SUM,
 122	            ownership_share_variable=None,
 123	        )
 124	
 125	
 126	def test_person_share_rule_with_share_variable_is_valid():
 127	    _entry(
 128	        status=VerificationStatus.INFERRED,
 129	        required=False,
 130	        aggregation_rule=AggregationRule.PERSON_SHARE_THEN_PLAIN_SUM,
 131	        ownership_share_variable="p_share",
 132	    )  # no raise
```


### wealth_imputation/test_registry_content.py

```py
   1	"""Behavior of the populated wealth-battery registry."""
   2	
   3	import pytest
   4	
   5	from soep_preparation.wealth_imputation.components import CanonicalComponent
   6	from soep_preparation.wealth_imputation.registry import (
   7	    AggregationRule,
   8	    VerificationStatus,
   9	    fail_if_unresolved_required,
  10	)
  11	from soep_preparation.wealth_imputation.registry_content import REGISTRY_ENTRIES
  12	
  13	_PREDICTION_WAVE = 2022
  14	_WAVES = (2002, 2007, 2012, 2017, _PREDICTION_WAVE)
  15	
  16	# Components available directly in the reduced SOEP-Core V41 pwealth file.
  17	_AVAILABLE_COMPONENTS = frozenset(
  18	    {
  19	        CanonicalComponent.OWNER_OCCUPIED_PROPERTY_GROSS,
  20	        CanonicalComponent.FINANCIAL_ASSETS,
  21	        CanonicalComponent.PRIVATE_PENSION,
  22	        CanonicalComponent.VEHICLES,
  23	        CanonicalComponent.CONSUMER_DEBT,
  24	    }
  25	)
  26	# Components not separately sourceable from the SOEP-Core file.
  27	_UNAVAILABLE_COMPONENTS = frozenset(
  28	    {
  29	        CanonicalComponent.OWNER_OCCUPIED_MORTGAGE,
  30	        CanonicalComponent.OTHER_REAL_ESTATE,
  31	        CanonicalComponent.BUSINESS_ASSETS,
  32	    }
  33	)
  34	_SHARE_COMPONENTS = frozenset(
  35	    {
  36	        CanonicalComponent.OWNER_OCCUPIED_PROPERTY_GROSS,
  37	        CanonicalComponent.OWNER_OCCUPIED_MORTGAGE,
  38	        CanonicalComponent.OTHER_REAL_ESTATE,
  39	        CanonicalComponent.FINANCIAL_ASSETS,
  40	    }
  41	)
  42	_EXPECTED_NAMES = {
  43	    CanonicalComponent.OWNER_OCCUPIED_PROPERTY_GROSS: "p0100a",
  44	    CanonicalComponent.FINANCIAL_ASSETS: "f0100a",
  45	    CanonicalComponent.PRIVATE_PENSION: "h0100a",
  46	    CanonicalComponent.VEHICLES: "v0100a",
  47	    CanonicalComponent.CONSUMER_DEBT: "c0100a",
  48	}
  49	
  50	
  51	def test_registry_has_one_entry_per_component_and_wave():
  52	    """Every canonical component is declared for all five wealth-module waves."""
  53	    assert len(REGISTRY_ENTRIES) == len(CanonicalComponent) * len(_WAVES)
  54	
  55	
  56	def test_each_component_appears_in_every_wave():
  57	    """The component-wave grid is complete with no duplicates."""
  58	    grid = {(entry.component, entry.wave) for entry in REGISTRY_ENTRIES}
  59	    expected = {
  60	        (component, wave) for component in CanonicalComponent for wave in _WAVES
  61	    }
  62	    assert grid == expected
  63	
  64	
  65	@pytest.mark.parametrize("component", sorted(CanonicalComponent, key=lambda c: c.value))
  66	def test_each_component_uses_the_same_variable_in_every_wave(
  67	    component: CanonicalComponent,
  68	) -> None:
  69	    """A component's raw variable is identical across all waves (wave-invariance)."""
  70	    names = {
  71	        entry.raw_variable for entry in REGISTRY_ENTRIES if entry.component is component
  72	    }
  73	    assert len(names) == 1
  74	
  75	
  76	@pytest.mark.parametrize(
  77	    ("component", "expected"),
  78	    sorted(_EXPECTED_NAMES.items(), key=lambda item: item[0].value),
  79	)
  80	def test_available_components_map_to_their_v41_column(
  81	    component: CanonicalComponent,
  82	    expected: str,
  83	) -> None:
  84	    """Each available component probes its confirmed SOEP-Core V41 column."""
  85	    names = {
  86	        entry.raw_variable for entry in REGISTRY_ENTRIES if entry.component is component
  87	    }
  88	    assert names == {expected}
  89	
  90	
  91	def test_private_pension_uses_insurances_column_in_every_wave():
  92	    """Private provision maps to `h0100a` in all waves, including 2002."""
  93	    names = {
  94	        entry.raw_variable
  95	        for entry in REGISTRY_ENTRIES
  96	        if entry.component is CanonicalComponent.PRIVATE_PENSION
  97	    }
  98	    assert names == {"h0100a"}
  99	
 100	
 101	def test_share_components_apply_the_ownership_share_rule():
 102	    """Property and financial components carry a share and the share-then-sum rule."""
 103	    for entry in REGISTRY_ENTRIES:
 104	        if entry.component in _SHARE_COMPONENTS:
 105	            assert entry.aggregation_rule is AggregationRule.PERSON_SHARE_THEN_PLAIN_SUM
 106	            assert entry.ownership_share_variable is not None
 107	
 108	
 109	def test_direct_components_have_no_ownership_share():
 110	    """Pension, business, vehicles, and consumer debt are person-direct, no share."""
 111	    for entry in REGISTRY_ENTRIES:
 112	        if entry.component not in _SHARE_COMPONENTS:
 113	            assert entry.aggregation_rule is AggregationRule.PERSON_DIRECT_PLAIN_SUM
 114	            assert entry.ownership_share_variable is None
 115	
 116	
 117	def test_available_pre_2022_entries_are_verified_and_required():
 118	    """Present components are VERIFIED before 2022 and drive the release."""
 119	    for entry in REGISTRY_ENTRIES:
 120	        if entry.component in _AVAILABLE_COMPONENTS and entry.wave != _PREDICTION_WAVE:
 121	            assert entry.verification_status is VerificationStatus.VERIFIED
 122	            assert entry.required_for_release
 123	
 124	
 125	def test_available_2022_entries_are_unresolved_and_required():
 126	    """The unreleased 2022 values are UNRESOLVED but still release-critical."""
 127	    for entry in REGISTRY_ENTRIES:
 128	        if entry.component in _AVAILABLE_COMPONENTS and entry.wave == _PREDICTION_WAVE:
 129	            assert entry.verification_status is VerificationStatus.UNRESOLVED
 130	            assert entry.required_for_release
 131	
 132	
 133	def test_unavailable_components_are_unresolved_and_not_required():
 134	    """Components absent from SOEP-Core are UNRESOLVED and not release-critical."""
 135	    for entry in REGISTRY_ENTRIES:
 136	        if entry.component in _UNAVAILABLE_COMPONENTS:
 137	            assert entry.verification_status is VerificationStatus.UNRESOLVED
 138	            assert not entry.required_for_release
 139	
 140	
 141	def test_vehicles_uses_the_v41_name_not_the_sp272_tangible_name():
 142	    """Vehicles probes `v0100a` (V41), not the historical `t0100a`."""
 143	    vehicles = [
 144	        entry
 145	        for entry in REGISTRY_ENTRIES
 146	        if entry.component is CanonicalComponent.VEHICLES
 147	    ]
 148	    assert {entry.raw_variable for entry in vehicles} == {"v0100a"}
 149	
 150	
 151	def test_release_gate_blocks_until_2022_is_resolved():
 152	    """`fail_if_unresolved_required` raises while 2022 stays unresolved."""
 153	    with pytest.raises(
 154	        ValueError, match="Release-critical registry entries are unresolved"
 155	    ):
 156	        fail_if_unresolved_required(REGISTRY_ENTRIES)
 157	
 158	
 159	def test_training_waves_alone_pass_the_release_gate():
 160	    """The resolved pre-2022 subset clears the release gate."""
 161	    training = [entry for entry in REGISTRY_ENTRIES if entry.wave != _PREDICTION_WAVE]
 162	    fail_if_unresolved_required(training)  # no raise
```


### wealth_imputation/test_residual_model.py

```py
   1	"""Behavior of the two-part unmodelled-components residual model."""
   2	
   3	import numpy as np
   4	import pytest
   5	
   6	from soep_preparation.wealth_imputation.residual_model import ResidualModel
   7	
   8	
   9	def _two_part_data() -> tuple[np.ndarray, np.ndarray]:
  10	    """A residual that is held only by high-feature rows, growing with the feature.
  11	
  12	    Low-feature rows are non-owners with a (noisy) non-positive residual; high-feature
  13	    rows own unmodelled wealth in increasing amounts -- the concentrated, mostly-zero
  14	    shape of business and other-real-estate wealth.
  15	    """
  16	    feature = np.linspace(-2.0, 2.0, 40)
  17	    residual = np.where(feature > 0.0, 1000.0 * feature, -500.0)
  18	    return feature.reshape(-1, 1), residual
  19	
  20	
  21	def test_residual_model_predictions_are_non_negative():
  22	    """Predicted residuals never go below zero."""
  23	    features, residual = _two_part_data()
  24	    predictions = ResidualModel.fit(features, residual, seed=0).predict(features)
  25	    assert np.all(predictions >= 0.0)
  26	
  27	
  28	def test_residual_model_predicts_more_for_likely_owners():
  29	    """A likely-owner row gets a larger expected residual than an unlikely one."""
  30	    features, residual = _two_part_data()
  31	    model = ResidualModel.fit(features, residual, seed=0)
  32	    predictions = model.predict(np.array([[-1.5], [1.5]]))
  33	    assert predictions[1] > predictions[0]
  34	
  35	
  36	def test_residual_model_concentrates_mass_away_from_unlikely_owners():
  37	    """A clearly-non-owner row gets a near-zero residual, not the population average."""
  38	    features, residual = _two_part_data()
  39	    model = ResidualModel.fit(features, residual, seed=0)
  40	    assert model.predict(np.array([[-2.0]]))[0] < residual[residual > 0.0].mean()
  41	
  42	
  43	def test_residual_model_rejects_mismatched_lengths():
  44	    """A residual with a different row count than the design matrix fails closed."""
  45	    features, residual = _two_part_data()
  46	    with pytest.raises(ValueError, match="same number of rows"):
  47	        ResidualModel.fit(features, residual[:-1], seed=0)
  48	
  49	
  50	def test_residual_model_rejects_non_finite_residual():
  51	    """A non-finite residual entry fails closed."""
  52	    features, residual = _two_part_data()
  53	    residual[0] = np.nan
  54	    with pytest.raises(ValueError, match="finite"):
  55	        ResidualModel.fit(features, residual, seed=0)
```


### wealth_imputation/test_shares.py

```py
   1	import math
   2	
   3	import numpy as np
   4	import pandas as pd
   5	import pytest
   6	
   7	from soep_preparation.wealth_imputation.shares import resolve_person_amount
   8	
   9	
  10	def test_resolve_person_amount_applies_share_once():
  11	    joint = pd.Series([200_000.0, 200_000.0])
  12	    share = pd.Series([0.5, 1.0])
  13	    result = resolve_person_amount(joint, share)
  14	    pd.testing.assert_series_equal(
  15	        result, pd.Series([100_000.0, 200_000.0]), check_names=False
  16	    )
  17	
  18	
  19	def test_resolve_person_amount_missing_share_yields_na():
  20	    joint = pd.Series([200_000.0])
  21	    share = pd.Series([pd.NA], dtype="Float64")
  22	    result = resolve_person_amount(joint, share)
  23	    assert pd.isna(result.iloc[0])
  24	
  25	
  26	def test_resolve_person_amount_returns_float64():
  27	    result = resolve_person_amount(pd.Series([200_000.0]), pd.Series([0.5]))
  28	    assert result.dtype == np.float64
  29	
  30	
  31	def test_resolve_person_amount_multiplies_in_float64_after_promotion():
  32	    joint = pd.Series([3.0], dtype="float32")
  33	    share = pd.Series([0.1], dtype="float32")
  34	    result = resolve_person_amount(joint, share)
  35	    expected = np.float64(np.float32(3.0)) * np.float64(np.float32(0.1))
  36	    assert result.dtype == np.float64
  37	    assert math.isclose(result.iloc[0], expected)
  38	
  39	
  40	def test_resolve_person_amount_rejects_mismatched_index():
  41	    joint = pd.Series([200_000.0], index=[0])
  42	    share = pd.Series([0.5], index=[1])
  43	    with pytest.raises(ValueError, match="identical index"):
  44	        resolve_person_amount(joint, share)
  45	
  46	
  47	@pytest.mark.parametrize("bad_share", [-0.1, 1.5])
  48	def test_resolve_person_amount_rejects_share_outside_unit_interval(bad_share: float):
  49	    with pytest.raises(ValueError, match=r"\[0, 1\]"):
  50	        resolve_person_amount(pd.Series([200_000.0]), pd.Series([bad_share]))
  51	
  52	
  53	def test_resolve_person_amount_rejects_non_finite_amount():
  54	    with pytest.raises(ValueError, match="finite"):
  55	        resolve_person_amount(pd.Series([np.inf]), pd.Series([0.5]))
```


### wealth_imputation/test_simulate.py

```py
   1	"""Behavior of the joint-draw household-wealth simulation."""
   2	
   3	import numpy as np
   4	import pandas as pd
   5	import pytest
   6	
   7	from soep_preparation.wealth_imputation.components import CanonicalComponent
   8	from soep_preparation.wealth_imputation.simulate import (
   9	    ComponentDrawConfig,
  10	    simulate_household_totals,
  11	)
  12	
  13	
  14	def _one_person_household() -> pd.DataFrame:
  15	    return pd.DataFrame({"p_id": [1], "hh_id": [10], "survey_year": [2017]})
  16	
  17	
  18	def _financial_config() -> ComponentDrawConfig:
  19	    """A single owner whose only donor holds exactly 100."""
  20	    return ComponentDrawConfig(
  21	        component=CanonicalComponent.FINANCIAL_ASSETS,
  22	        ownership_prob=np.array([1.0]),
  23	        ownership_share=np.array([1.0]),
  24	        recipient_predicted=np.array([100.0]),
  25	        donor_predicted=np.array([100.0]),
  26	        donor_observed=np.array([100.0]),
  27	        scale=100.0,
  28	        k=1,
  29	    )
  30	
  31	
  32	def test_simulate_household_totals_point_estimate_equals_sole_donor_value():
  33	    """With one certain owner and one donor, every draw yields the donor value."""
  34	    result = simulate_household_totals(
  35	        _one_person_household(),
  36	        [_financial_config()],
  37	        n_draws=3,
  38	        rng=np.random.default_rng(seed=0),
  39	    )
  40	    np.testing.assert_allclose(result["point_estimate"].to_numpy(), [100.0], atol=1e-6)
  41	
  42	
  43	def _two_person_household() -> pd.DataFrame:
  44	    return pd.DataFrame(
  45	        {"p_id": [1, 2], "hh_id": [10, 10], "survey_year": [2017, 2017]}
  46	    )
  47	
  48	
  49	def test_simulate_household_totals_nets_assets_minus_liabilities_over_members():
  50	    """Net total = members' financial assets minus the household's consumer debt."""
  51	    financial = ComponentDrawConfig(
  52	        component=CanonicalComponent.FINANCIAL_ASSETS,
  53	        ownership_prob=np.array([1.0, 1.0]),
  54	        ownership_share=np.array([1.0, 1.0]),
  55	        recipient_predicted=np.array([100.0, 50.0]),
  56	        donor_predicted=np.array([100.0, 50.0]),
  57	        donor_observed=np.array([100.0, 50.0]),
  58	        scale=100.0,
  59	        k=1,
  60	    )
  61	    debt = ComponentDrawConfig(
  62	        component=CanonicalComponent.CONSUMER_DEBT,
  63	        ownership_prob=np.array([1.0, 0.0]),  # only person 1 holds debt
  64	        ownership_share=np.array([1.0, 1.0]),
  65	        recipient_predicted=np.array([20.0, 20.0]),
  66	        donor_predicted=np.array([20.0]),
  67	        donor_observed=np.array([20.0]),
  68	        scale=100.0,
  69	        k=1,
  70	    )
  71	    result = simulate_household_totals(
  72	        _two_person_household(),
  73	        [financial, debt],
  74	        n_draws=2,
  75	        rng=np.random.default_rng(seed=0),
  76	    )
  77	    # (100 + 50) financial - 20 consumer debt = 130.
  78	    np.testing.assert_allclose(result["point_estimate"].to_numpy(), [130.0], atol=1e-6)
  79	
  80	
  81	def test_simulate_household_totals_is_deterministic_for_a_fixed_seed():
  82	    """The same seed reproduces the interval."""
  83	    first = simulate_household_totals(
  84	        _one_person_household(),
  85	        [_financial_config()],
  86	        n_draws=4,
  87	        rng=np.random.default_rng(seed=5),
  88	    )
  89	    second = simulate_household_totals(
  90	        _one_person_household(),
  91	        [_financial_config()],
  92	        n_draws=4,
  93	        rng=np.random.default_rng(seed=5),
  94	    )
  95	    np.testing.assert_array_equal(
  96	        first["point_estimate"].to_numpy(), second["point_estimate"].to_numpy()
  97	    )
  98	
  99	
 100	def test_simulate_household_totals_rejects_config_misaligned_with_recipients():
 101	    """A config whose arrays do not match the recipient count fails closed."""
 102	    bad = ComponentDrawConfig(
 103	        component=CanonicalComponent.FINANCIAL_ASSETS,
 104	        ownership_prob=np.array([1.0, 1.0]),  # two entries for one recipient
 105	        ownership_share=np.array([1.0, 1.0]),
 106	        recipient_predicted=np.array([100.0, 100.0]),
 107	        donor_predicted=np.array([100.0]),
 108	        donor_observed=np.array([100.0]),
 109	        scale=100.0,
 110	        k=1,
 111	    )
 112	    with pytest.raises(ValueError, match="recipients"):
 113	        simulate_household_totals(
 114	            _one_person_household(),
 115	            [bad],
 116	            n_draws=1,
 117	            rng=np.random.default_rng(seed=0),
 118	        )
```


### wealth_imputation/test_training.py

```py
   1	"""Behavior of the per-component training and config-building helpers."""
   2	
   3	import numpy as np
   4	import pandas as pd
   5	
   6	from soep_preparation.wealth_imputation.components import CanonicalComponent
   7	from soep_preparation.wealth_imputation.features import (
   8	    encode_design_matrix,
   9	    select_household_heads,
  10	)
  11	from soep_preparation.wealth_imputation.simulate import ComponentDrawConfig
  12	from soep_preparation.wealth_imputation.training import (
  13	    build_component_config,
  14	    component_scale,
  15	    derive_ownership,
  16	    fit_component_models,
  17	)
  18	
  19	
  20	def test_select_household_heads_keeps_the_oldest_member_per_household():
  21	    """Each household-year is represented by its oldest member."""
  22	    frame = pd.DataFrame(
  23	        {
  24	            "p_id": [1, 2, 3],
  25	            "hh_id": [10, 10, 11],
  26	            "survey_year": [2017, 2017, 2017],
  27	            "age": [40, 38, 50],
  28	        }
  29	    )
  30	    heads = select_household_heads(frame)
  31	    assert set(heads["p_id"]) == {1, 3}
  32	
  33	
  34	def test_encode_design_matrix_fills_missing_with_the_column_median():
  35	    """Numeric encoding replaces NaN with the column median and returns float64."""
  36	    frame = pd.DataFrame({"x": [1.0, np.nan, 3.0]})
  37	    matrix = encode_design_matrix(frame, ["x"])
  38	    assert matrix.dtype == np.float64
  39	    np.testing.assert_allclose(matrix.ravel(), [1.0, 2.0, 3.0], atol=1e-6)
  40	
  41	
  42	def test_derive_ownership_flags_positive_values_as_owners():
  43	    """Ownership is 1 where the component value is positive, else 0."""
  44	    owns = derive_ownership(np.array([0.0, 100.0, 0.0, 50.0]))
  45	    np.testing.assert_array_equal(owns, [0, 1, 0, 1])
  46	
  47	
  48	def test_component_scale_is_the_median_of_positive_values():
  49	    """The asinh scale is the median of the strictly positive amounts."""
  50	    scale = component_scale(np.array([0.0, 100.0, 200.0, 300.0]))
  51	    np.testing.assert_allclose(scale, 200.0, atol=1e-6)
  52	
  53	
  54	def test_component_scale_falls_back_to_one_without_positive_values():
  55	    """An all-zero component still yields a usable positive scale."""
  56	    assert component_scale(np.array([0.0, 0.0])) == 1.0
  57	
  58	
  59	def _training_data() -> tuple[np.ndarray, np.ndarray]:
  60	    """Owners (value > 0) concentrated at high feature values."""
  61	    feature = np.linspace(-3.0, 3.0, 40)
  62	    values = np.where(feature > 0.0, 1000.0 * np.exp(feature), 0.0)
  63	    return feature.reshape(-1, 1), values
  64	
  65	
  66	def test_fit_component_models_ownership_probability_rises_with_the_feature():
  67	    """The fitted ownership model assigns higher P(owns) to higher feature values."""
  68	    features, values = _training_data()
  69	    models = fit_component_models(features, values, seed=0)
  70	    probabilities = models.ownership_model.probability(np.array([[-2.0], [2.0]]))
  71	    assert probabilities[1] > probabilities[0]
  72	
  73	
  74	def test_build_component_config_returns_aligned_config():
  75	    """The built config carries one ownership probability per recipient."""
  76	    features, values = _training_data()
  77	    models = fit_component_models(features, values, seed=0)
  78	    recipient_features = np.array([[1.0], [2.0]])
  79	    config = build_component_config(
  80	        component=CanonicalComponent.FINANCIAL_ASSETS,
  81	        models=models,
  82	        recipient_features=recipient_features,
  83	        recipient_shares=np.array([1.0, 1.0]),
  84	        donor_features=features[values > 0.0],
  85	        donor_values=values[values > 0.0],
  86	        k=5,
  87	    )
  88	    assert isinstance(config, ComponentDrawConfig)
  89	    assert config.component is CanonicalComponent.FINANCIAL_ASSETS
  90	    assert config.ownership_prob.shape == (2,)
  91	    assert config.donor_observed.shape == config.donor_predicted.shape
```


### wealth_imputation/test_transforms.py

```py
   1	import numpy as np
   2	import pandas as pd
   3	import pytest
   4	
   5	from soep_preparation.wealth_imputation.transforms import (
   6	    asinh_scaled,
   7	    inverse_asinh_scaled,
   8	)
   9	
  10	
  11	def test_asinh_scaled_round_trip_recovers_values_including_zero_and_negatives():
  12	    """Round-trip transform recovers original values with high precision."""
  13	    values = pd.Series([-50000.0, 0.0, 1234.5, 1_000_000.0])
  14	    restored = inverse_asinh_scaled(
  15	        asinh_scaled(values, scale=10_000.0), scale=10_000.0
  16	    )
  17	    np.testing.assert_allclose(restored.to_numpy(), values.to_numpy(), atol=1e-4)
  18	
  19	
  20	def test_asinh_scaled_returns_float64_for_float32_input():
  21	    """A float32 input is promoted to a float64 transformed output."""
  22	    values = pd.Series([1234.5, -50.0], dtype="float32")
  23	    assert asinh_scaled(values, scale=1000.0).dtype == np.float64
  24	
  25	
  26	def test_asinh_scaled_rejects_nonpositive_scale():
  27	    """Scale validation rejects zero and negative values."""
  28	    with pytest.raises(ValueError, match="scale must be positive"):
  29	        asinh_scaled(pd.Series([1.0]), scale=0.0)
  30	
  31	
  32	def test_asinh_scaled_rejects_non_finite_scale():
  33	    """Scale validation rejects non-finite values."""
  34	    with pytest.raises(ValueError, match="finite"):
  35	        asinh_scaled(pd.Series([1.0]), scale=float("inf"))
```


### wealth_imputation/test_value_generator.py

```py
   1	"""Behavior of the per-component sequential value generator."""
   2	
   3	import numpy as np
   4	import pytest
   5	
   6	from soep_preparation.wealth_imputation.value_generator import (
   7	    ComponentDraw,
   8	    draw_component,
   9	)
  10	
  11	
  12	def _draw(seed: int = 0) -> ComponentDraw:
  13	    return draw_component(
  14	        ownership_prob=np.array([1.0, 0.0]),
  15	        ownership_share=np.array([0.5, 0.5]),
  16	        recipient_predicted=np.array([100.0, 100.0]),
  17	        donor_predicted=np.array([100.0]),
  18	        donor_observed=np.array([80.0]),
  19	        scale=100.0,
  20	        k=1,
  21	        rng=np.random.default_rng(seed=seed),
  22	    )
  23	
  24	
  25	def test_draw_component_owner_takes_share_of_drawn_amount_nonowner_zero():
  26	    """An owner's value is share x drawn amount; a non-owner's value is zero."""
  27	    result = _draw()
  28	    np.testing.assert_allclose(result.person_value, [40.0, 0.0], atol=1e-6)
  29	
  30	
  31	def test_draw_component_probabilities_0_and_1_act_as_a_deterministic_filter():
  32	    """Probability 1 always owns and 0 never owns, regardless of seed."""
  33	    result = _draw()
  34	    np.testing.assert_array_equal(result.owns, [True, False])
  35	    np.testing.assert_allclose(result.gross_amount, [80.0, 0.0], atol=1e-6)
  36	
  37	
  38	def test_draw_component_is_deterministic_for_a_fixed_seed():
  39	    """Same seed reproduces ownership, gross amount, and person value."""
  40	    first = _draw(seed=11)
  41	    second = _draw(seed=11)
  42	    np.testing.assert_array_equal(first.owns, second.owns)
  43	    np.testing.assert_array_equal(first.person_value, second.person_value)
  44	
  45	
  46	@pytest.mark.parametrize("bad_prob", [-0.1, 1.5, np.nan])
  47	def test_draw_component_rejects_probabilities_outside_unit_interval(bad_prob: float):
  48	    """An ownership probability outside [0, 1] fails closed."""
  49	    with pytest.raises(ValueError, match="ownership_prob"):
  50	        draw_component(
  51	            ownership_prob=np.array([bad_prob]),
  52	            ownership_share=np.array([0.5]),
  53	            recipient_predicted=np.array([100.0]),
  54	            donor_predicted=np.array([100.0]),
  55	            donor_observed=np.array([80.0]),
  56	            scale=100.0,
  57	            k=1,
  58	            rng=np.random.default_rng(seed=0),
  59	        )
  60	
  61	
  62	def test_draw_component_rejects_mismatched_recipient_lengths():
  63	    """Recipient arrays of differing length fail closed."""
  64	    with pytest.raises(ValueError, match="one length"):
  65	        draw_component(
  66	            ownership_prob=np.array([1.0, 0.0]),
  67	            ownership_share=np.array([0.5]),
  68	            recipient_predicted=np.array([100.0, 100.0]),
  69	            donor_predicted=np.array([100.0]),
  70	            donor_observed=np.array([80.0]),
  71	            scale=100.0,
  72	            k=1,
  73	            rng=np.random.default_rng(seed=0),
  74	        )
```


### wealth_imputation/test_wealth_dynamics.py

```py
   1	"""Disclosure-safe wealth distribution and mobility summaries."""
   2	
   3	import numpy as np
   4	import pandas as pd
   5	import pytest
   6	
   7	from soep_preparation.wealth_imputation.wealth_dynamics import (
   8	    build_dynamics_report,
   9	    gini,
  10	    quintile_ranks,
  11	    top_share,
  12	    transition_counts,
  13	    transition_probabilities,
  14	    wave_distribution_summary,
  15	)
  16	
  17	
  18	def test_gini_is_zero_for_perfect_equality():
  19	    """An equal distribution has a Gini coefficient of zero."""
  20	    assert gini(np.array([5.0, 5.0, 5.0, 5.0])) == pytest.approx(0.0)
  21	
  22	
  23	def test_gini_for_one_holder_is_n_minus_one_over_n():
  24	    """When one of four holds everything, the Gini is (n-1)/n = 0.75."""
  25	    assert gini(np.array([0.0, 0.0, 0.0, 100.0])) == pytest.approx(0.75)
  26	
  27	
  28	def test_gini_matches_the_hand_computed_value_for_a_small_ladder():
  29	    """The Gini of 1,2,3,4 is 0.25 by the mean-absolute-difference definition."""
  30	    assert gini(np.array([1.0, 2.0, 3.0, 4.0])) == pytest.approx(0.25)
  31	
  32	
  33	def test_top_share_returns_fraction_held_by_the_top_group():
  34	    """The top 10% of 1..10 is the single value 10, i.e. 10/55 of the total."""
  35	    values = np.arange(1.0, 11.0)
  36	    assert top_share(values, top_fraction=0.1) == pytest.approx(10.0 / 55.0)
  37	
  38	
  39	def test_quintile_ranks_split_a_uniform_range_evenly():
  40	    """Ten evenly spaced values fall two-per-quintile, ranked 1..5."""
  41	    ranks = quintile_ranks(pd.Series(np.arange(1.0, 11.0)), n_groups=5)
  42	    assert ranks.tolist() == [1, 1, 2, 2, 3, 3, 4, 4, 5, 5]
  43	
  44	
  45	def test_wave_distribution_summary_reports_the_median():
  46	    """The summary's 50th percentile is the median of the values."""
  47	    summary = wave_distribution_summary(np.array([10.0, 20.0, 30.0, 40.0]))
  48	    assert summary["quantiles"]["p50"] == pytest.approx(25.0)
  49	
  50	
  51	def test_transition_counts_place_each_mover_in_its_from_to_cell():
  52	    """A mover from quintile 1 to quintile 3 lands in row 1, column 3 (zero-based)."""
  53	    counts = transition_counts(pd.Series([1, 2]), pd.Series([3, 2]), n_groups=5)
  54	    assert counts[0, 2] == 1
  55	
  56	
  57	def test_transition_probabilities_normalise_each_row_to_one():
  58	    """Each origin-quintile row of the probability matrix sums to one."""
  59	    counts = np.array([[3, 1], [0, 4]], dtype="float64")
  60	    probabilities = transition_probabilities(counts)
  61	    np.testing.assert_allclose(probabilities.sum(axis=1), [1.0, 1.0])
  62	
  63	
  64	def test_build_dynamics_report_skips_waves_without_data():
  65	    """A wave with no households is recorded and omitted, not raised on."""
  66	    households = pd.DataFrame(
  67	        {
  68	            "hh_id": [1, 2, 3, 4],
  69	            "survey_year": [2017, 2017, 2017, 2017],
  70	            "net_wealth": [10.0, 20.0, 30.0, 40.0],
  71	        }
  72	    )
  73	    roster = pd.DataFrame(
  74	        {"p_id": [1, 2, 3, 4], "hh_id": [1, 2, 3, 4], "survey_year": [2017] * 4}
  75	    )
  76	    report = build_dynamics_report(
  77	        households, roster, waves=(2012, 2017), n_groups=2, min_cell=1
  78	    )
  79	    assert report["metadata"]["waves_without_data"] == [2012]
  80	
  81	
  82	def test_build_dynamics_report_covers_every_wave_and_horizon():
  83	    """The report carries one distribution per wave and one transition per horizon."""
  84	    waves = (2012, 2017)
  85	    households = pd.DataFrame(
  86	        {
  87	            "hh_id": [1, 2, 3, 4, 1, 2, 3, 4],
  88	            "survey_year": [2012] * 4 + [2017] * 4,
  89	            "net_wealth": [10.0, 20.0, 30.0, 40.0, 15.0, 25.0, 35.0, 45.0],
  90	        }
  91	    )
  92	    roster = pd.DataFrame(
  93	        {
  94	            "p_id": [1, 2, 3, 4, 1, 2, 3, 4],
  95	            "hh_id": [1, 2, 3, 4, 1, 2, 3, 4],
  96	            "survey_year": [2012] * 4 + [2017] * 4,
  97	        }
  98	    )
  99	    report = build_dynamics_report(
 100	        households, roster, waves=waves, n_groups=2, min_cell=1
 101	    )
 102	    assert set(report["distribution"]) == {"2012", "2017"}
 103	    assert set(report["transitions"]) == {"2012->2017"}
```
