# Provisional 2022 SOEP household-wealth imputation — method & empirics for outside review

## 0. What this is and what it is not

A **provisional, donor-based proxy** for 2022 household net wealth in the German
Socio-Economic Panel (SOEP), built as a stopgap until the DIW releases the officially
imputed 2022 wealth module. It produces, for each 2022 household, a point estimate and a
central interval for net overall wealth.

It is **explicitly not** the official DIW product and **not** a valid multiple-imputation
(MI) inference: it uses a single wealth implicate, applies no SOEP survey weights, and
its intervals reflect donor/draw spread, not a proper posterior. The review should judge
it as a *predictive proxy with uncertainty bands*, and tell us where its construction is
statistically unsound, where the code diverges from the description below, and which of
the listed approximations are first-order threats to the headline results.

`@pro: Given the stated goal (a usable 2022 proxy, not MI), which of the approximations in §9 are first-order and which are second-order? Rank them.`

## 1. Data

SOEP-Core, version V41. The SOEP wealth module is fielded every five years; we use waves
**2002, 2007, 2012, 2017** as the training waves and impute **2022** (the wealth module
for 2022 is not yet released in imputed form).

V41 ships a **reduced** household wealth file (`hwealth`) and person wealth file
(`pwealth`). The separable wealth components present are: owner-occupied property (gross
and net of mortgage), financial assets, private insurances, vehicles, consumer debt.
**Business assets and other real estate are not separable** — they exist only inside the
official net-wealth totals.

Two official total columns matter:

- `hh_net_overall_wealth_a` (SOEP `w011h`): net overall wealth, populated in **every**
  wealth wave 2002–2017.
- `hh_net_overall_wealth_including_vehicles_and_student_loans_a` (SOEP `n011h`): an
  augmented total (adds vehicles and student loans), populated **only from 2017**.

The imputation **targets `n011h`** (vehicle-inclusive, because vehicles are a modelled
component). The descriptive distribution/mobility analysis **ranks on `w011h`** (the only
cross-wave-consistent total). The imputed 2022 leg of the analysis is on the `n011h`
concept; the difference (vehicles + student loans) is treated as negligible for ranking.

`@pro: The imputation total (n011h) exists only in 2017 among training waves, so the residual model (§7) is fit on a single wave. Is anything about the residual fit or its 2017→2022 extrapolation invalid because of this single-wave support?`

## 2. Components and their bias-free construction

Five components are modelled, with this sign convention for the net total (assets `+`,
liabilities `−`):

| component | source | sign |
|---|---|---|
| owner-occupied property (net of mortgage) | household `hwealth` | + |
| financial assets | household `hwealth` | + |
| vehicles | household `hwealth` | + |
| private pension / insurances | summed over members from person `pwealth` | + |
| consumer debt | summed over members from person `pwealth` | − |

The three **joint** components (property, financial, vehicles) are taken from the
DIW-aggregated **household** file, which already resolves ownership shares correctly.
This avoids a bias we hit earlier: the person-level wealth variables repeat the *full*
joint value on each co-owner's row, so summing person rows double-counts couples. The two
**person-direct** components (insurances, consumer debt) have no ownership share, so a
plain sum over household members is unbiased — these are summed from person `pwealth`.

`@pro: Verify the claim that summing person-direct components (insurances, consumer debt) over members is unbiased while joint components would be double-counted. Is the asymmetry correctly reflected in the code (impute.py _household_person_direct vs the hwealth columns)?`

## 3. Feature matrix

Per household head (the oldest member, `select_household_heads`):

- ~18 covariates: age, gender, household size, children, federal state, income after
  tax, education, employment/occupation/marital status, self-employment, retirement,
  gross labour income, tenure, migration background, dwelling ownership, living space,
  building year.
- Continuous covariates enter directly; categoricals are **one-hot encoded** with a
  `CategoricalEncoder` fit on the training waves and applied to recipients.
- **Lagged wealth**: each head's own prior-wave person wealth (5 `pwealth` implicate-`a`
  columns) is merged on `p_id` and added as continuous predictors.

## 4. Per-component model (two-part) and the draw

For each component, on the training waves:

1. **Ownership** — `OwnershipModel`: `sklearn` `LogisticRegression` on the design matrix
   predicting `P(value > 0)`.
2. **Amount** — `AmountModel`: `LinearRegression` on `asinh(y / s)` where `s` is the
   median strictly-positive amount (`component_scale`); `predict` inverts the asinh to
   return euros. This variance-stabilises the heavy right tail.
3. **Donor deflation** — cross-wave donors are scaled to 2022 by an asset-class index:
   MSCI World → financial, BIS house-price index → property, REX bond index → pension.
   Vehicles and consumer debt are **not** deflated (depreciating / nominal).
4. **Draw** — `value_generator.draw_component`: draw ownership ~ Bernoulli(`P(owns)`);
   if owner, draw an amount by **predictive mean matching** (PMM): find the `k` donors
   whose *predicted* amount is nearest the recipient's predicted amount, draw one
   donor's *observed* value uniformly. Ownership share = 1 for these household-level
   components.

`@pro: PMM matches on the asinh-amount prediction but draws the observed euro donor value. With donors deflated by an asset index (step 3), is the match metric (predicted) consistent with the drawn quantity (deflated observed)? Could the deflation distort the neighbour set?`

## 5. Joint simulation and intervals

`simulate_household_totals` performs `n_draws` (=200) complete joint draws. Within a
single draw, every component is drawn for every recipient and the **signed sum** gives
that draw's household net total. Across draws, `household_total_intervals` returns the
median as the point estimate and the central `level` (=0.9) quantiles as the interval
bounds. Component interval endpoints are **never** summed — intervals are formed on the
household-total draw distribution directly, to preserve cross-component dependence within
a draw.

`@pro: Each draw redraws ownership and PMM independently per component with no modelled cross-component correlation (beyond shared covariates). Does forming the interval on the summed total nonetheless understate or misstate joint uncertainty? Is 200 draws adequate for stable 5th/95th percentiles?`

## 6. Settings

`n_draws = 200`, `seed = 0`, `k = 10` (PMM neighbours, clipped to a component's owner
count), `level = 0.9`.

## 7. The residual to the official total (two-part — current code)

The five components do not sum to the official total; the gap is **business + other real
estate** (absent from V41 as separable variables) plus fit/measurement noise. We model it
as a residual:

```
residual_h = official_total_h − Σ_c sign_c · modelled_component_{c,h}
```

over training households that have an official total. Construction (`impute.py
_training_residual`, `residual_model.py`):

1. **Deflate** each training residual from its wave to 2022 by `RESIDUAL_INDEX` — an
   equal-weight blend of the BIS house-price and MSCI World indices, each rebased to a
   common base year (other real estate ≈ property, business ≈ equity).
2. **Two-part allocator** (`ResidualModel`): a logistic incidence model for
   `P(residual > 0)` (does the household hold any unmodelled wealth) times an
   asinh-scaled `AmountModel` fit on the **positive residuals only**. The expected
   residual `P(owns) · amount` is **clipped at zero**.
3. The per-recipient expected residual is **added to the point estimate and both
   interval bounds** (a deterministic level shift; it does not widen the interval).
4. Fallback: if owners and non-owners are not both present, a flat training-mean shift.

This **replaced an earlier OLS** on the raw signed residual. The OLS smeared a highly
concentrated, mostly-zero quantity (business/other-RE) across all households, which
inflated the median, compressed measured inequality, and manufactured negative net
wealth (see §10). The two-part form is meant to keep the mass concentrated.

`@pro: Is "expected residual = P(owns)·amount(asinh-predicted), clipped at 0, added to point and both bounds" a coherent estimator of the unmodelled-wealth contribution? The amount model's asinh prediction is a conditional median-ish quantity, not a mean — is P·amount a defensible plug-in for E[residual | x]? Does clipping at 0 bias the level?`

`@pro: The residual deflation (50/50 property/equity blend) and the component deflation both bring donors to 2022. Is there any double-counting of asset-price growth between the deflated components and the deflated residual?`

## 8. Distribution and mobility analysis (`wealth_dynamics.py`)

Disclosure-safe aggregates only (no row-level value leaves the secure environment):

- **Per-wave distribution** over households on `w011h` (imputed point estimate for 2022):
  count, mean, quantile grid (p1…p99), Gini, top-10% and top-1% shares, negative- and
  zero-wealth shares. Gini uses the mean-absolute-difference (sorted-rank) formula and
  can exceed 1 with negative net wealth.
- **Quintile transitions** over persons across consecutive 5-year horizons. The unit is
  the **person** (`p_id`, stable across waves), assigned their household's net wealth;
  quintile ranks are formed on the full person cross-section of each wave; persons present
  in both waves of a horizon are cross-tabulated. Cells below 30 movers are suppressed.

`@pro: Mobility is person-level (each person carries household wealth) while the cross-sectional distribution is household-level. Is mixing the two units defensible, and does the person-level ranking (which weights large households more) bias the transition matrices?`

## 9. Key assumptions and known approximations (review hit-list)

1. **Single wealth implicate** ("a") — SOEP multiply-imputes wealth; we use one
   implicate, so we ignore SOEP's own item-imputation uncertainty.
2. **No survey weights** anywhere — models, distribution, and mobility are all
   unweighted, so population-level statements are biased by the SOEP sample design and
   refresh samples.
3. **Residual fit on a single wave (2017)** — because `n011h` exists only from 2017.
4. **Residual deflation blend (50/50 property/equity)** — a rough default; business
   growth is proxied by world equities.
5. **Intervals from draw spread only** — the residual is a deterministic shift; SOEP
   imputation uncertainty and model uncertainty are not propagated.
6. **PMM on asinh-predicted amounts with asset-deflated donors.**
7. **Household property is net of mortgage; vehicles/consumer-debt donors not deflated.**
8. **2022 mobility leg uses the imputed proxy**, so the 2017→2022 transition is
   attenuated by imputation regression-to-the-mean.

`@pro: Are intervals that omit (1) the SOEP item-imputation variance, (2) model/parameter uncertainty, and (3) any residual uncertainty likely to be badly under-covered? Roughly how much, and what is the cheapest fix that would make them honest?`

## 10. Empirical results

### 10.1 Distribution over time (household net overall wealth `w011h`; 2022 imputed)

| wave | n | mean (€) | median (€) | Gini | top-10% | top-1% | neg. share |
|---|---|---|---|---|---|---|---|
| 2002 | 12,692 | 197,406 | 60,000 | 0.752 | 0.568 | 0.228 | 0.064 |
| 2007 | 11,689 | 192,393 | 60,492 | 0.750 | 0.566 | 0.217 | 0.077 |
| 2012 | 14,982 | 166,656 | 45,600 | 0.768 | 0.567 | 0.200 | 0.103 |
| 2017 | 15,891 | 197,236 | 52,200 | 0.759 | 0.566 | 0.212 | 0.091 |
| **2022\*** | 30,003 | 274,922 | 109,716 | 0.719 | 0.540 | 0.172 | 0.144 |

\* Imputed, under the **earlier OLS residual** specification (see version note §11).

The four actual waves are internally consistent and match known SOEP wealth facts (high
Gini ~0.75, stable top shares, 2012 euro-crisis trough). The imputed 2022 row shows three
distortions versus the actual trend: median roughly doubles, measured inequality falls
(Gini and top shares down), and the negative-wealth share jumps to 14.4%.

### 10.2 Imputation run summary (OLS residual specification)

```
n_recipients=30003, n_training_heads=70813, components_used=5 (none skipped),
residual_model="ols", mean_residual=122560, n_draws=200, k=10, level=0.9
```

### 10.3 Transition matrices, row % (origin quintile → destination quintile)

Actual horizons (real data):

```
2002→2007            2007→2012            2012→2017
   Q1 Q2 Q3 Q4 Q5       Q1 Q2 Q3 Q4 Q5       Q1 Q2 Q3 Q4 Q5
Q1 59 27 10  3  2    Q1 59 28 10  3  -    Q1 60 24 11  4  1
Q2 24 45 22  6  2    Q2 21 38 32  7  2    Q2 31 39 22  6  1
Q3  8 15 44 27  6    Q3  6 10 46 31  7    Q3  7 12 48 27  6
Q4  4  5 18 50 24    Q4  2  4 11 52 31    Q4  2  3 18 51 26
Q5  3  4  6 17 71    Q5  1  3  3 14 78    Q5  1  2  3 16 78
```

Imputed horizon (2017 actual → 2022 imputed, OLS residual):

```
   Q1 Q2 Q3 Q4 Q5
Q1 26 33 20 16  5
Q2 21 31 22 20  6
Q3  7 19 16 36 22
Q4  3 17 10 27 44
Q5  3 11  7 12 67
```

The actual horizons show strong, stable diagonal persistence (textbook wealth mobility).
The imputed horizon's diagonal collapses in the bottom and middle quintiles — consistent
with imputation regression-to-the-mean rather than genuine mobility.

`@pro: Is the contrast between the three actual transition matrices and the imputed one a fair internal validity check? What additional disclosure-safe diagnostic would best quantify how much the imputed mobility is an artefact?`

## 11. Version note (code vs empirics)

The **bundled code** implements the **two-part residual model** (§7). The **empirics in
§10** were produced by the **previous OLS residual** specification; they are included
because they are the diagnostic that motivated the two-part change, and because the
actual-data results (2002–2017) are specification-independent. A re-run under the two-part
code is pending; it is expected to reduce the imputed-2022 median, restore measured
inequality toward the actual trend, and remove the spurious negatives. Please review the
two-part code on its merits and treat the §10 imputed-2022 numbers as the "before" state.

`@pro: Independent of the rerun, does the two-part code in residual_model.py + impute.py plausibly fix the three §10 distortions, or could it over-correct (e.g. concentrate too aggressively, or the clip-at-0 truncate genuine variation)?`
